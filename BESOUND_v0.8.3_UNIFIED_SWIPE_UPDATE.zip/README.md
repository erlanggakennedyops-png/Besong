# BESOUND v0.8.3 – Unified Swipe Up Update

## Changes
- Now Playing opens Lyrics with an upward swipe on the dedicated hint area below the player controls.
- Fullscreen Lyrics returns to Now Playing with an upward swipe on the dedicated footer hint area.
- Album cover and playback controls no longer carry the navigation gesture.
- Lyrics body remains independently vertically scrollable.
- App identity (`applicationId: com.bei.music`) and Room database (`bei_music.db`) are unchanged.
- Version name 0.8.3, version code 17.

## Existing user data
This is an in-place app update, not a data reset. Do not uninstall the installed app or clear its storage. Android normally preserves app-private Room data and persisted document permissions during an update when the package ID and signing certificate match. The signing certificate must match the currently installed app for Android to accept an in-place update.

## Build
The repository workflow expects this ZIP at the repository root as `BESOUND_v0.8.3_UNIFIED_SWIPE_UPDATE.zip`. Replace `.github/workflows/android.yml` with the matching workflow and commit both files.
