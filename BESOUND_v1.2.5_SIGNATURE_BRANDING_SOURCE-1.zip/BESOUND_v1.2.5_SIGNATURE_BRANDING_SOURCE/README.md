# BESOUND v1.2.0

Android source project for package `com.bei.besound`.

## Version
- versionCode: 15
- versionName: 1.1.4
- Room database schema: version 2 (unchanged; no destructive migration)

## Changes in 1.1.2
- Cache decoded cover artwork by its persisted private URI, avoiding repeated image decoding during playback updates.
- Read `file://` cover images directly from the app-private file path and continue supporting content URIs.
- Publish MediaSession artwork metadata only when track metadata or duration changes.
- Separate frequent playback-position/state updates from artwork metadata updates.
- Refresh active-track metadata after editing a song, including a newly selected cover.
- Keep Media3 ExoPlayer, PlayerNotificationManager, MediaSessionCompat, package ID, database, stored songs, launcher icon, and release signing configuration.

## Important verification note
The source archive and workflow include structural checks. A signed APK is only considered verified after GitHub Actions completes the Gradle build, signature check, and package/version check successfully.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change `applicationId` or release keystore for updates.

## Changes in 1.1.4
- Resolve the active track's selected cover from the Room database first for notification and lock-screen artwork.
- Treat a known track with an empty coverUri as intentionally having no custom cover, so BESOUND default artwork is used instead of stale player metadata.
- Refresh media artwork when Room emits updated song records and immediately after the active song is edited.
- Keep the existing database schema (version 2), package ID, and release signing configuration unchanged.

## Verification
- Source archive integrity and PNG artwork decoding were checked.
- Kotlin source changes were inspected, but a signed APK has not been built or device-tested yet. GitHub Actions must pass before installation.


## v1.1.8 — Home refresh

- Home now uses a dedicated **NOW** player card with shuffle, previous, play/pause, next, repeat, and seek controls.
- Added animated audio visualizer bars that animate during playback and settle when paused.
- Replaced the four small Home shortcuts with two large image cards: **BEI SONG** and **GLOBAL MUSIC**.
- BEI SONG uses the supplied masked-artist reference photo; GLOBAL MUSIC uses the approved cinematic city image.
- Removed the old Featured Today label and mood shelf from the Home layout.
- Recently Played is shown as compact vertical rows.
- Bottom navigation is now Home, Playlist, Library, Profile.
- BEI SONG and GLOBAL MUSIC are opened from their Home cards, not from bottom navigation.
- The mini-player is hidden on Home (NOW already has full controls) and appears on other app pages when a track is active.
- Package ID remains `com.bei.besound`; versionCode 20; versionName 1.1.9.

The Playlist destination is a placeholder screen because persistent playlist creation/storage is not part of this UI refresh. Existing Room library, player, notification, MediaSession, and artwork code are retained.


## v1.1.9 — Kotlin compile fixes
- Corrected AudioVisualizer animation spec to use an infinite Float animation and a paused visual height.
- Added the missing @Composable annotation to NowPlayingScreen.
- Removed the duplicate formatTime(Long) overload that caused conflicting overload resolution.
- Package ID, Room schema, existing player, notification, artwork and signing configuration are retained.


## v1.2.0 — Large Now Playing artwork and header menu
- Increased the Now Playing artwork to use nearly the full available screen width and a larger height.
- Tapping the Home NOW card opens the dedicated Now Playing screen; playback continues without interruption.
- On Now Playing only, removed Search and Theme controls from the header and replaced them with one three-dot menu.
- Three-dot menu actions: Share (Android Sharesheet) and Add to Playlist (opens the Playlist destination).
- Added a centered upward arrow above “SWIPE UP FOR LYRICS”, with an Indonesian helper label.
- Kept the four bottom destinations: Home, Playlist, Library, Profile; Home remains highlighted while Now Playing is open.
- Existing Audio Visualizer, ExoPlayer, Room database, MediaSession, notification artwork, package ID and signing setup are retained.
- Playlist creation/storage is still a placeholder; Add to Playlist currently opens the Playlist destination and does not persist a playlist entry.


## v1.2.1 — Animated BE.i mascot
- Removed the Discover sunset banner from Home.
- Added a centered BESOUND wordmark above the NOW card, flanked by the existing animated waveform.
- Added a new small 3D BE.i robot mascot in a black hoodie and orange headphones, overlapping the top-left edge of the NOW card.
- Mascot uses lightweight Compose transforms: continuous idle bob, gentle head tilt, and faster rhythmic sway/scale while music is playing. The raised hand in the mascot artwork provides the waving pose.
- Existing BEI SONG and GLOBAL MUSIC image resources are untouched. Album artwork, player, database, notification artwork, package ID and signing configuration are preserved.


## v1.2.2 — BE.i Dance Walk
- Replaced the previous stationary/bobbing mascot with a transparent walking-pose BE.i mascot.
- While music is playing, BE.i walks from left to right, turns to face left, and walks back left-to-right in a continuous patrol loop. The horizontal flip changes its facing direction, so it does not appear to moonwalk.
- Added a gentle head/body sway and small hop while moving.
- Added floating ♪ and ♫ particles that rise and fade above the mascot while playback is active.
- When playback is paused, the mascot stops walking and rests near the center with a subtle idle sway.
- The mascot occupies a dedicated 88dp strip above the NOW card; it no longer overlaps the album artwork, progress bar, or playback controls.
- Existing BEI SONG and GLOBAL MUSIC artwork, song artwork, player controls, database, notification artwork, package ID, and signing configuration are retained.
- Version code 23, version name 1.2.2.


## v1.2.3 — Dynamic Cover Glow & Mascot Layout Fix
- Fixed the mascot/card overlap: the mascot now occupies its own 92dp layout row above the NOW player card, instead of sharing a stacking Box with the card.
- Removed the oversized empty top spacer and made the mascot fully visible in its own row.
- Added sampled cover-color extraction from the currently selected song artwork. The sampled color drives a subtle radial/gradient glow behind the NOW card and a tinted NOW label chip.
- Color transitions smoothly when the current song cover changes.
- Preserved the existing BEI SONG and GLOBAL MUSIC artwork, track artwork, playback controls, local database, media notification artwork, package ID, and signing configuration.
- Version code 24, version name 1.2.3.


## v1.2.4 — Stationary BE.i Mascot
- Replaced the horizontal walking animation with a larger, stationary smiling BE.i mascot.
- The mascot remains centered in a dedicated 126dp area above the NOW player card.
- Added a gentle alternating head-like tilt and tiny vertical bob; motion is slower when playback is paused and slightly livelier while music plays.
- Removed walking, horizontal flipping, hopping, and floating music-note particles to match the simplified mascot direction.
- Uses the existing smiling hoodie-and-orange-headphones mascot artwork (`bei_mascot_robot.png`).
- Retains Dynamic Cover Glow, player controls, BEI SONG and GLOBAL MUSIC images, track artwork, database, notifications, package ID, and signing configuration.
- Version code 25, version name 1.2.4.


## v1.2.5 — BESOUND Signature Branding
- Replaced the plain BESOUND title row with a dedicated rounded signature branding panel.
- Panel uses a dark espresso-to-brown gradient, thin orange/golden outline, subtle ambient glow, headphones icon, animated audio visualizers, BESOUND wordmark, and MUSIC PLAYER subtitle.
- Kept the larger stationary BE.i mascot with gentle head-like sway and small vertical bob below the branding panel.
- Retained Dynamic Cover Glow, NOW playback card, BEI SONG and GLOBAL MUSIC artwork, song artwork, database, notification/lockscreen behavior, package ID, and signing configuration.
- Version code 26, version name 1.2.5.
