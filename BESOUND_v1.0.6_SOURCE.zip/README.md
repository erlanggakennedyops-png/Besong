# BESOUND v1.0.6

Android source project for package `com.bei.besound`.

## Version
- versionCode: 7
- versionName: 1.0.6
- Database: Room schema version 2 (no destructive migration)

## Changes in 1.0.6
- Save metadata edits through Room and read the row back before closing the editor.
- Show a success or failure message after the database operation.
- Display full track titles in My Library using natural wrapping instead of a one-line ellipsis.
- Reduce Library action-button footprint to give titles more horizontal room.
- Keep existing cover art, delete-from-library behavior, playback, package ID, and database schema.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change applicationId or release keystore for updates.
