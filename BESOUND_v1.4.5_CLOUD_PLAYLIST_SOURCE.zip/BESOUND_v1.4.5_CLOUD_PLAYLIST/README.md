# BESOUND v1.4.5 - Cloud Playlist

Android project for `com.bei.besound`.

## Release
- versionName: `1.4.5`
- versionCode: `46`
- minSdk 26 / targetSdk 35

## Playlist features
- Supabase Auth email/password login and account registration from the Playlist tab.
- Session refresh and local session persistence for repeat visits.
- Private-by-default playlists scoped to `auth.uid()`.
- Two-column grid and compact Daily Mix banner using the existing Be.i mask artwork.
- Create, edit, delete playlists; select JPG/PNG/WEBP cover up to 5 MB.
- Add songs from the BEI SONG cloud catalogue and play through the existing ExoPlayer path.
- Private playlist cover storage in `playlist-covers` bucket.
- Share links are unlisted bearer links; only people with BESOUND installed can open `besound://playlist/share?...`.
- Owners can revoke every outstanding share link for a playlist from its menu.

## Supabase objects
The connected project has already been provisioned with:
- `public.user_playlists`
- `public.user_playlist_tracks`
- `public.playlist_shares`
- private Storage bucket `playlist-covers`
- RPC `public.get_shared_playlist(text)`

RLS policies restrict playlist rows, track rows, and cover objects to the authenticated owner. The share RPC returns only the selected playlist and its track metadata when a valid high-entropy share token is supplied. Share links are private-by-default exceptions: anyone possessing a generated link can view that specific playlist. Revoke links from the playlist menu to disable existing links.

The SQL migration is included at `supabase/migrations/20261122090000_cloud_playlists.sql`. The schema has already been applied to the connected Supabase project; do not re-run the migration against that same project because it is a first-install migration.

## Build
Upload `BESOUND_v1.4.5_CLOUD_PLAYLIST_SOURCE.zip` to the repository root and use `.github/workflows/android.yml`. The workflow expects the matching ZIP filename exactly. Existing signing secrets and package ID are preserved.

## Testing note
ZIP integrity and AndroidManifest XML are checked. A local Gradle/Android SDK build has not been run in this environment; run GitHub Actions before installing the APK. Verify sign-up/login, playlist CRUD, cover upload, adding a BEI SONG track, and share-link open/revoke on two devices.
