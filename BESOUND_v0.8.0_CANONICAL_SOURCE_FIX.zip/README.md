# BESOUND v0.8.0 — Golden Dusk

Canonical single-root Android project.

## Build
GitHub Actions workflow: `.github/workflows/android.yml`
The workflow builds the repository root directly. It does not extract an older ZIP archive.

## Player gestures
- Swipe down on Now Playing: open fullscreen Lyrics.
- Swipe up on fullscreen Lyrics: return to Now Playing.
- No lyrics icon or button is shown.

## Version
- versionName: 0.8.0
- versionCode: 14

Build status must be confirmed in GitHub Actions; this source archive is not itself a tested APK.
