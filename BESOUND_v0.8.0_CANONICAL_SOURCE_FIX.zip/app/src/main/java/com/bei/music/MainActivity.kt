package com.bei.music

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private var Cream by mutableStateOf(Color(0xFF17120F))
private var CreamCard by mutableStateOf(Color(0xFF2A1C16))
private var Orange by mutableStateOf(Color(0xFFFF8A32))
private var Golden by mutableStateOf(Color(0xFFFFC15A))
private var Ink by mutableStateOf(Color(0xFFFFE8CE))
private var Muted by mutableStateOf(Color(0xFFB99B80))
private var NavSurface by mutableStateOf(Color(0xFF211711))
private var DividerTone by mutableStateOf(Color(0xFF493123))

private fun applyPalette(name: String) {
    when (name) {
        "Cream Light" -> {
            Cream = Color(0xFFFFF8ED); CreamCard = Color(0xFFFFE8CC)
            Orange = Color(0xFFE58B3A); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFF33291F); Muted = Color(0xFF8B7866)
            NavSurface = Color(0xFFFFF1DE); DividerTone = Color(0xFFEFE2D2)
        }
        "Midnight" -> {
            Cream = Color(0xFF10131B); CreamCard = Color(0xFF202633)
            Orange = Color(0xFFFF8B45); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFFF5F0E9); Muted = Color(0xFFA6A9B4)
            NavSurface = Color(0xFF191E29); DividerTone = Color(0xFF343B49)
        }
        else -> {
            Cream = Color(0xFF17120F); CreamCard = Color(0xFF2A1C16)
            Orange = Color(0xFFFF8A32); Golden = Color(0xFFFFC15A)
            Ink = Color(0xFFFFE8CE); Muted = Color(0xFFB99B80)
            NavSurface = Color(0xFF211711); DividerTone = Color(0xFF493123)
        }
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
        }

        val dao = MusicDatabase.get(this).songDao()

        setContent {
            val scope = rememberCoroutineScope()
            val songs by dao.observeAll().collectAsState(initial = emptyList())

            var currentUri by remember { mutableStateOf<String?>(null) }
            var isPlaying by remember { mutableStateOf(false) }
            var positionMs by remember { mutableLongStateOf(0L) }
            var durationMs by remember { mutableLongStateOf(0L) }
            var shuffleEnabled by remember { mutableStateOf(false) }
            var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
            var selectedTab by remember { mutableIntStateOf(0) }
            var searchText by remember { mutableStateOf("") }
            var showLyrics by remember { mutableStateOf(false) }
            var showEditor by remember { mutableStateOf(false) }
            var editingSong by remember { mutableStateOf<SongEntity?>(null) }
            var editTitle by remember { mutableStateOf("") }
            var editArtist by remember { mutableStateOf("") }
            var editAlbum by remember { mutableStateOf("") }
            var editLyrics by remember { mutableStateOf("") }
            var themeName by remember { mutableStateOf(getPreferences(MODE_PRIVATE).getString("besound_theme", "Golden Dusk") ?: "Golden Dusk") }
            var showThemeMenu by remember { mutableStateOf(false) }
            SideEffect { applyPalette(themeName) }
            LaunchedEffect(themeName) { getPreferences(MODE_PRIVATE).edit().putString("besound_theme", themeName).apply() }

            val currentSong = songs.firstOrNull { it.uri == currentUri }

            // Repair legacy placeholder titles such as "msf:114295" using the actual file name.
            LaunchedEffect(songs) {
                songs.filter {
                    it.title.isBlank() || it.title.startsWith("msf:", ignoreCase = true) ||
                        it.title.equals("Untitled", ignoreCase = true)
                }.forEach { song ->
                    val recoveredTitle = displayNameFor(Uri.parse(song.uri))
                    if (recoveredTitle.isNotBlank() && recoveredTitle != song.title) {
                        dao.upsert(song.copy(title = recoveredTitle))
                    }
                }
            }

            val filteredSongs = remember(songs, searchText) {
                if (searchText.isBlank()) songs
                else songs.filter {
                    it.title.contains(searchText, true) ||
                        it.artist.contains(searchText, true) ||
                        it.album.contains(searchText, true)
                }
            }

            val audioPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenMultipleDocuments()
            ) { uris ->
                uris.forEach { uri ->
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                    val metadata = readMetadata(uri)
                    val fallbackTitle = displayNameFor(uri)
                    scope.launch {
                        dao.upsert(
                            SongEntity(
                                uri = uri.toString(),
                                title = metadata.first.ifBlank { fallbackTitle },
                                artist = metadata.second.ifBlank { "Unknown artist" },
                                album = metadata.third.ifBlank { "Unknown album" }
                            )
                        )
                    }
                }
            }

            fun playSong(song: SongEntity) {
                val index = songs.indexOfFirst { it.uri == song.uri }
                if (index >= 0) {
                    currentUri = song.uri
                    player.setMediaItems(songs.map { MediaItem.fromUri(Uri.parse(it.uri)) }, index, 0L)
                    player.prepare()
                    player.play()
                    isPlaying = true
                    selectedTab = 5
                }
            }

            fun openEditor(song: SongEntity) {
                editingSong = song
                editTitle = song.title
                editArtist = song.artist
                editAlbum = song.album
                editLyrics = song.lyrics
                showEditor = true
            }

            LaunchedEffect(Unit) {
                while (true) {
                    isPlaying = player.isPlaying
                    positionMs = player.currentPosition.coerceAtLeast(0L)
                    durationMs = player.duration.takeIf { it > 0L } ?: 0L
                    val index = player.currentMediaItemIndex
                    if (index in songs.indices) currentUri = songs[index].uri
                    delay(400)
                }
            }

            DisposableEffect(player) {
                val listener = object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) {
                        isPlaying = playing
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        val index = player.currentMediaItemIndex
                        if (index in songs.indices) currentUri = songs[index].uri
                    }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        durationMs = player.duration.takeIf { it > 0L } ?: 0L
                    }
                }
                player.addListener(listener)
                onDispose { player.removeListener(listener) }
            }

            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Orange,
                    onPrimary = Color.White,
                    secondary = Golden,
                    background = Cream,
                    surface = Cream,
                    onBackground = Ink,
                    onSurface = Ink,
                    onSurfaceVariant = Muted,
                    surfaceVariant = CreamCard,
                    secondaryContainer = CreamCard,
                    onSecondaryContainer = Ink
                )
            ) {
                Scaffold(
                    containerColor = Cream,
                    bottomBar = {
                        if (!showLyrics) NavigationBar(containerColor = NavSurface) {
                            val navItems = listOf(
                                Triple("Home", Icons.Default.Home, 0),
                                Triple("Bei Song", Icons.Default.MusicNote, 1),
                                Triple("Global Music", Icons.Default.Public, 2),
                                Triple("Library", Icons.Default.LibraryMusic, 3),
                                Triple("Profile", Icons.Default.Person, 4)
                            )
                            navItems.forEach { item ->
                                NavigationBarItem(
                                    selected = selectedTab == item.third,
                                    onClick = { selectedTab = item.third },
                                    icon = { Icon(item.second, contentDescription = item.first) },
                                    label = { Text(item.first, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Orange,
                                        selectedTextColor = Ink,
                                        indicatorColor = CreamCard,
                                        unselectedIconColor = Muted,
                                        unselectedTextColor = Muted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    Column(
                        Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                    ) {
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "BESOUND",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Ink,
                                    letterSpacing = (-0.8).sp
                                )
                                Text(
                                    "Your music. Your lyrics. Your world.",
                                    color = Muted,
                                    fontSize = 12.sp
                                )
                            }
                            Box {
                                IconButton(onClick = { showThemeMenu = true }) {
                                    Icon(Icons.Default.Palette, "Ganti tema", tint = Orange, modifier = Modifier.size(30.dp))
                                }
                                DropdownMenu(
                                    expanded = showThemeMenu,
                                    onDismissRequest = { showThemeMenu = false },
                                    containerColor = CreamCard,
                                    tonalElevation = 8.dp,
                                    shadowElevation = 8.dp
                                ) {
                                    listOf("Golden Dusk", "Cream Light", "Midnight").forEach { option ->
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        option,
                                                        color = Ink,
                                                        fontWeight = if (themeName == option) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                    if (themeName == option) {
                                                        Spacer(Modifier.width(12.dp))
                                                        Icon(Icons.Default.Check, contentDescription = "Tema aktif", tint = Orange)
                                                    }
                                                }
                                            },
                                            onClick = { themeName = option; showThemeMenu = false }
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))

                        if (selectedTab == 0) {
                            Text("DISCOVER", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Find your sound.", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink)
                            Text("Your music. Your lyrics. Your world.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().clickable { selectedTab = 1 }) {
                                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Orange, Golden))), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) { Text("BEI SONG", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text("Original music by Bei", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Katalog resmi karya kamu", color = Muted, fontSize = 12.sp) }
                                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().clickable { selectedTab = 2 }) {
                                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Golden, Orange))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Public, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) { Text("EXPLORE THE WORLD", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text("Global Music", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Discover artists around the world", color = Muted, fontSize = 12.sp) }
                                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("Your local collection", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("${songs.size} lagu di Library", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = { selectedTab = 3 }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.LibraryMusic, null); Spacer(Modifier.width(8.dp)); Text("Buka Library") }
                        } else if (selectedTab == 1 || selectedTab == 2) {
                            val isBeiSong = selectedTab == 1
                            Text(if (isBeiSong) "BEI SONG" else "GLOBAL MUSIC", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(if (isBeiSong) "Music by Bei" else "Music from around the world", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(18.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Icon(if (isBeiSong) Icons.Default.MusicNote else Icons.Default.Public, null, tint = Orange, modifier = Modifier.size(36.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text(if (isBeiSong) "Katalog Bei Song" else "Global Music", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                    Text(if (isBeiSong) "Lagu resmi karya Bei akan ditampilkan di sini dan dapat didengarkan semua pengguna setelah layanan cloud diaktifkan." else "Katalog musik global akan terhubung melalui sumber musik yang memiliki izin distribusi.", color = Muted, fontSize = 13.sp)
                                    Spacer(Modifier.height(10.dp))
                                    Text("COMING IN CLOUD RELEASE", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else if (selectedTab == 4) {
                            Text("PROFILE", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Your BESOUND account", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(16.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Icon(Icons.Default.AccountCircle, null, tint = Orange, modifier = Modifier.size(48.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("Guest user", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("Login dan sinkronisasi akun akan hadir saat backend cloud tersedia.", color = Muted, fontSize = 13.sp)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = { showThemeMenu = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Palette, null); Spacer(Modifier.width(8.dp)); Text("Ganti tema") }
                        } else if (selectedTab == 3) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CreamCard),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("YOUR LIBRARY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("${songs.size} lagu tersimpan", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                                    Spacer(Modifier.height(12.dp))
                                    Button(
                                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Orange),
                                        shape = RoundedCornerShape(28.dp)
                                    ) {
                                        Icon(Icons.Default.Upload, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Upload musik")
                                    }
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            OutlinedTextField(
                                value = searchText,
                                onValueChange = { searchText = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("Cari lagu, artis, atau album...") },
                                leadingIcon = { Icon(Icons.Default.Search, null, tint = Orange) },
                                shape = RoundedCornerShape(18.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Ink,
                                    unfocusedTextColor = Ink,
                                    cursorColor = Orange,
                                    focusedPlaceholderColor = Muted,
                                    unfocusedPlaceholderColor = Muted,
                                    focusedLeadingIconColor = Orange,
                                    unfocusedLeadingIconColor = Orange,
                                    focusedBorderColor = Orange,
                                    unfocusedBorderColor = DividerTone,
                                    focusedContainerColor = Cream,
                                    unfocusedContainerColor = Cream
                                )
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("My Library", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                                Text("LOCAL", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            if (filteredSongs.isEmpty()) {
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.LibraryMusic, null, tint = Orange, modifier = Modifier.size(48.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text(if (songs.isEmpty()) "Belum ada lagu" else "Lagu tidak ditemukan", fontWeight = FontWeight.Bold, color = Ink)
                                        Text("Upload MP3 atau audio dari HP kamu.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            } else {
                                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                                    items(filteredSongs, key = { it.uri }) { song ->
                                        ListItem(
                                            modifier = Modifier.clickable { playSong(song) },
                                            headlineContent = {
                                                Text(song.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            },
                                            supportingContent = {
                                                Text("${song.artist} • ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted)
                                            },
                                            leadingContent = {
                                                Box(
                                                    Modifier.size(48.dp).clip(RoundedCornerShape(13.dp))
                                                        .background(Brush.linearGradient(listOf(Orange, Golden))),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(26.dp))
                                                }
                                            },
                                            trailingContent = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(onClick = { openEditor(song) }) {
                                                        Icon(Icons.Default.Edit, "Edit lagu", tint = Ink)
                                                    }
                                                    IconButton(onClick = { playSong(song) }) {
                                                        Icon(Icons.Default.PlayArrow, "Putar", tint = Orange)
                                                    }
                                                }
                                            },
                                            colors = ListItemDefaults.colors(containerColor = Cream)
                                        )
                                        HorizontalDivider(color = DividerTone)
                                    }
                                }
                            }
                        } else {
                            if (showLyrics) {
                                FullscreenLyricsScreen(
                                    song = currentSong,
                                    onClose = { showLyrics = false }
                                )
                            } else NowPlayingScreen(
                                song = currentSong,
                                isPlaying = isPlaying,
                                positionMs = positionMs,
                                durationMs = durationMs,
                                shuffleEnabled = shuffleEnabled,
                                repeatMode = repeatMode,
                                onPlayPause = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.currentMediaItem != null) player.play()
                                    isPlaying = player.isPlaying
                                },
                                onPrevious = {
                                    if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                    else if (player.currentMediaItem != null) player.seekTo(0)
                                },
                                onNext = {
                                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                },
                                onSeek = { player.seekTo(it) },
                                onLyrics = { showLyrics = true },
                                onShuffle = {
                                    shuffleEnabled = !shuffleEnabled
                                    player.shuffleModeEnabled = shuffleEnabled
                                },
                                onRepeat = {
                                    repeatMode = when (repeatMode) {
                                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                        else -> Player.REPEAT_MODE_OFF
                                    }
                                    player.repeatMode = repeatMode
                                }
                            )
                        }

                        if (selectedTab != 5) {
                            MiniPlayer(
                                song = currentSong,
                                isPlaying = isPlaying,
                                onPlayPause = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.currentMediaItem != null) player.play()
                                },
                                onPrevious = {
                                    if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                    else if (player.currentMediaItem != null) player.seekTo(0)
                                },
                                onNext = {
                                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                },
                                onOpen = { selectedTab = 5 }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "v0.8.0 • Golden Dusk • Vertical swipe",
                            color = Muted,
                            fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp)
                        )
                    }
                }
            }

            if (showEditor && editingSong != null) {
                AlertDialog(
                    onDismissRequest = { showEditor = false; showLyrics = false },
                    title = { Text(if (showLyrics) "Lyrics Studio" else "Edit lagu & lirik") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!showLyrics) {
                                OutlinedTextField(editTitle, { editTitle = it }, label = { Text("Judul lagu") }, singleLine = true)
                                OutlinedTextField(editArtist, { editArtist = it }, label = { Text("Artis") }, singleLine = true)
                                OutlinedTextField(editAlbum, { editAlbum = it }, label = { Text("Album") }, singleLine = true)
                            }
                            OutlinedTextField(
                                editLyrics,
                                { editLyrics = it },
                                label = { Text("Lirik lagu") },
                                minLines = 5,
                                maxLines = 9
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            editingSong?.let { old ->
                                scope.launch {
                                    dao.upsert(old.copy(
                                        title = editTitle.ifBlank { "Untitled" },
                                        artist = editArtist.ifBlank { "Unknown artist" },
                                        album = editAlbum.ifBlank { "Unknown album" },
                                        lyrics = editLyrics
                                    ))
                                }
                            }
                            showEditor = false
                            showLyrics = false
                        }) { Text("Simpan") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditor = false; showLyrics = false }) { Text("Tutup") }
                    }
                )
            }
        }
    }

    private fun displayNameFor(uri: Uri): String {
        var displayName = ""
        runCatching {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (column >= 0) displayName = cursor.getString(column).orEmpty()
                }
            }
        }
        if (displayName.isBlank()) {
            displayName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':').orEmpty()
        }
        val withoutExtension = displayName.substringBeforeLast('.', displayName).trim()
        return withoutExtension.ifBlank { "Untitled" }
    }

    private fun readMetadata(uri: Uri): Triple<String, String, String> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            Triple(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
            )
        } catch (_: Exception) {
            Triple("", "", "")
        } finally {
            runCatching { retriever.release() }
        }
    }

    override fun onDestroy() {
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

/**
 * Detect vertical swipes in the Initial pointer pass so nested controls (notably
 * Slider and the lyrics scroll column) cannot consume the gesture first.
 * Horizontal gestures are deliberately ignored.
 */
private fun Modifier.verticalSwipeGesture(
    onSwipeDown: () -> Unit,
    onSwipeUp: () -> Unit
): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(
            requireUnconsumed = false,
            pass = PointerEventPass.Initial
        )
        var previousY = down.position.y
        var totalY = 0f
        var completed = false
        val threshold = viewConfiguration.touchSlop * 1.5f

        while (!completed) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val change = event.changes.firstOrNull { it.id == down.id }
            if (change == null || !change.pressed) {
                completed = true
            } else {
                val deltaY = change.position.y - previousY
                val deltaX = change.position.x - down.position.x
                previousY = change.position.y
                totalY = change.position.y - down.position.y
                if (abs(totalY) >= threshold && abs(totalY) > abs(deltaX) * 1.2f) {
                    change.consume()
                    if (totalY > 0f) onSwipeDown() else onSwipeUp()
                    completed = true
                }
            }
        }
    }
}

@Composable
private fun ColumnScope.NowPlayingScreen(
    song: SongEntity?, isPlaying: Boolean, positionMs: Long, durationMs: Long,
    shuffleEnabled: Boolean, repeatMode: Int, onPlayPause: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit,
    onShuffle: () -> Unit, onRepeat: () -> Unit, onLyrics: () -> Unit
) {
    BoxWithConstraints(
        Modifier.fillMaxWidth().weight(1f).verticalSwipeGesture(
            onSwipeDown = onLyrics,
            onSwipeUp = {}
        )
    ) {
        val coverSize = minOf(maxWidth * 0.84f, maxHeight * 0.40f, 320.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly) {
            Text("NOW PLAYING", color = Orange, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Box(Modifier.size(coverSize).clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Orange, Golden, Color(0xFFFFE2B7))),
                    RoundedCornerShape(26.dp)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Headphones, null, tint = Color.White,
                        modifier = Modifier.size((coverSize.value * 0.25f).dp))
                    Text("BESOUND", color = Color.White, fontSize = 22.sp,
                        fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(song?.title ?: "Belum ada lagu dipilih", color = Ink, fontSize = 21.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artist ?: "Pilih lagu dari Library", color = Muted, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Slider(value = positionMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1L).toFloat()),
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(), enabled = durationMs > 0L,
                colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange,
                    inactiveTrackColor = DividerTone))
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(positionMs), color = Muted, fontSize = 11.sp)
                Text(formatTime(durationMs), color = Muted, fontSize = 11.sp)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton(onClick = onShuffle, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffleEnabled) Orange else Muted,
                        modifier = Modifier.size(26.dp))
                }
                IconButton(onClick = onPrevious, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = Ink, modifier = Modifier.size(35.dp))
                }
                FilledIconButton(onClick = onPlayPause, enabled = song != null,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Orange,
                        contentColor = Color.White, disabledContainerColor = DividerTone,
                        disabledContentColor = Muted)) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play atau pause", modifier = Modifier.size(42.dp))
                }
                IconButton(onClick = onNext, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = Ink, modifier = Modifier.size(35.dp))
                }
                IconButton(onClick = onRepeat, modifier = Modifier.size(48.dp)) {
                    Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "Repeat", tint = if (repeatMode == Player.REPEAT_MODE_OFF) Muted else Orange,
                        modifier = Modifier.size(26.dp))
                }
            }
        }
    }
}

@Composable
private fun FullscreenLyricsScreen(song: SongEntity?, onClose: () -> Unit) {
    Column(Modifier.fillMaxWidth().fillMaxHeight().verticalSwipeGesture(
        onSwipeDown = {},
        onSwipeUp = onClose
    ).padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.SpaceBetween) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onClose) {
                Icon(Icons.Default.KeyboardArrowDown, "Kembali ke player", tint = Orange,
                    modifier = Modifier.size(32.dp))
            }
            Text("LYRICS", color = Orange, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.size(48.dp))
        }
        val lines = song?.lyrics.orEmpty().lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Belum ada lirik untuk lagu ini", color = Muted, fontSize = 18.sp)
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center) {
                lines.forEachIndexed { index, line ->
                    Text(line, color = if (index == 0) Ink else Muted,
                        fontSize = if (index == 0) 25.sp else 20.sp,
                        fontWeight = if (index == 0) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(vertical = 12.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(song?.title ?: "BESOUND", color = Ink, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artist ?: "", color = Muted, fontSize = 12.sp)
            }
            IconButton(onClick = onClose) {
                Icon(Icons.Default.KeyboardArrowUp, "Kembali ke player", tint = Orange,
                    modifier = Modifier.size(32.dp))
            }
        }
    }
}

@Composable
private fun MusicVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = Orange,
    barCount: Int = 7,
    maxBarHeight: androidx.compose.ui.unit.Dp = 30.dp
) {
    val transition = rememberInfiniteTransition(label = "besound_equalizer")
    Row(
        modifier = modifier.height(maxBarHeight),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(barCount) { index ->
            val animatedHeight by transition.animateFloat(
                initialValue = 0.18f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 360 + (index % 4) * 115,
                        delayMillis = index * 65,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "equalizer_bar_$index"
            )
            val barFraction = if (isPlaying) animatedHeight else 0.18f
            Box(
                Modifier
                    .width(4.dp)
                    .height(maxBarHeight * barFraction.coerceIn(0.12f, 1f))
                    .clip(CircleShape)
                    .background(barColor)
            )
        }
    }
}

@Composable
private fun MiniPlayer(
    song: SongEntity?,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onOpen: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CreamCard),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(enabled = song != null) { onOpen() }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(Orange, Golden))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song?.title ?: "Belum ada lagu diputar",
                    color = Ink,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    song?.artist ?: "Pilih lagu dari Library",
                    color = Muted,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (song != null) {
                IconButton(onClick = onPrevious, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Lagu sebelumnya", tint = Ink, modifier = Modifier.size(25.dp))
                }
                IconButton(onClick = onPlayPause, modifier = Modifier.size(42.dp)) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play atau pause", tint = Orange, modifier = Modifier.size(30.dp)
                    )
                }
                IconButton(onClick = onNext, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Default.SkipNext, "Lagu berikutnya", tint = Ink, modifier = Modifier.size(25.dp))
                }
            } else {
                Text("Pilih lagu", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0L) / 1000L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
