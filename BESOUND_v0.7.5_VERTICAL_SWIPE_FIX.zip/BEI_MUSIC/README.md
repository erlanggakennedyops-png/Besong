# BESOUND v0.7.0 – Golden Dusk Swipe Lyrics

Player layout update:
- Larger responsive album-art placeholder while keeping transport controls in the same screen.
- Swipe down on Now Playing to open a full-screen lyrics view.
- Swipe up or use the chevron to return to Now Playing.
- Lyrics are displayed from the song's saved lyrics text.

Note: This release provides a full-screen lyrics reading view. Word/line timestamp synchronization and album-cover image picking are not implemented yet.
