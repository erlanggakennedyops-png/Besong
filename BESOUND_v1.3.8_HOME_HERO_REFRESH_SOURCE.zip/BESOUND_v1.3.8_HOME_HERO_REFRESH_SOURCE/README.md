# BESOUND v1.3.8 — Home Hero Refresh

Android source project for package `com.bei.besound`.

## Version
- versionCode: 39
- versionName: 1.3.8

## Home update
- Added a cinematic sunset hero panel at the top of Home to fill the unused upper area.
- Warm dark overlay, orange/gold outline, short welcome copy, and animated audio visualizer.
- Preserves the current Home player, mascot, BEI SONG/Global Music cards, Recently Played history, mini-player rules, Room database, and signing configuration.

## Build status
Source archive integrity checked. Android Gradle compilation has not yet been run.
