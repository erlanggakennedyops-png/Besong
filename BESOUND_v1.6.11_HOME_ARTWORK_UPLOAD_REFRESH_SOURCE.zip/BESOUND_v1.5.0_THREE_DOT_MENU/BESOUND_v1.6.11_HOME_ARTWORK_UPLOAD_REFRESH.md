# BESOUND v1.6.11 – Home Artwork & Admin Upload Refresh

- Home player now uses the current track artwork as a brighter, softly blurred ambient background with a dark readability overlay.
- Home player controls are balanced into left and right groups around a truly centered play/pause button.
- Admin upload form is simplified into clear title, audio file, optional cover, and upload controls.
- Upload flow stores the Supabase refresh token at admin login and refreshes the session before uploading, addressing expired JWT `exp` claim failures.
- Audio uploads preserve common source MIME types and file extensions (MP3, M4A, WAV, OGG).
- Upload status and lyrics editor now use the Golden Dusk palette for readable contrast.

Build: versionCode 64, versionName 1.6.11.
