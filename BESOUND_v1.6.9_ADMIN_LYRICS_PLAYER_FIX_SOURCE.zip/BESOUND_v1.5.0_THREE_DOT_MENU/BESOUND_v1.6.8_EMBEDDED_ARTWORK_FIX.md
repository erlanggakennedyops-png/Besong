# BESOUND v1.6.8 — Embedded Artwork Fix

- Extract embedded album artwork from selected audio documents with `MediaMetadataRetriever`.
- Persist extracted covers in BESOUND private storage so they remain readable after picker URI access changes.
- Backfill embedded artwork for existing library tracks that do not already have a manually selected cover.
- Preserve manually selected covers, lyrics, and track metadata when a track is imported again.
- Decode private `file://` artwork URIs directly for Library, Now Playing, and mini-player artwork.

Package: `com.bei.besound`
Version code: `61`
Version name: `1.6.8`
