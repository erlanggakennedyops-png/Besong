package com.bei.besound

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

internal object BeiSongCloud {
    const val BASE = "https://awgmpmitmicvovxkucwa.supabase.co"
    const val API_KEY = "sb_publishable_wfhyIDcvbzBSeDh6cJxb_w_h9eGUxxL"
    const val ADMIN_EMAIL = "galangkennedy10@gmail.com"
    const val RECOVERY_REDIRECT = "besound://auth/reset-password"
    var recoveryToken by mutableStateOf<String?>(null)
    private const val ADMIN_PREFS = "besound_admin_session"
    fun savedAdminToken(context: Context): String? = context.getSharedPreferences(ADMIN_PREFS, Context.MODE_PRIVATE).getString("access", null)
    fun saveAdminToken(context: Context, token: String) { context.getSharedPreferences(ADMIN_PREFS, Context.MODE_PRIVATE).edit().putString("access", token).apply() }
    fun clearAdminToken(context: Context) { context.getSharedPreferences(ADMIN_PREFS, Context.MODE_PRIVATE).edit().clear().apply() }

    fun handleRecoveryIntent(intent: android.content.Intent?) {
        val raw = intent?.dataString ?: return
        val fragment = raw.substringAfter('#', "")
        val params = fragment.split('&').mapNotNull { part ->
            val bits = part.split('=', limit = 2)
            if (bits.size == 2) java.net.URLDecoder.decode(bits[0], "UTF-8") to
                java.net.URLDecoder.decode(bits[1], "UTF-8") else null
        }.toMap()
        if (params["type"] == "recovery" && !params["access_token"].isNullOrBlank()) {
            recoveryToken = params["access_token"]
        }
    }

    data class Song(val id: Long, val title: String, val artist: String, val audioUrl: String, val coverUrl: String?, val lyrics: String?)

    private fun request(path: String, method: String = "GET", token: String? = null, body: ByteArray? = null, contentType: String? = null): String {
        val c = (URL("$BASE$path").openConnection() as HttpURLConnection)
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("apikey", API_KEY)
        if (!token.isNullOrBlank()) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", contentType ?: "application/json")
            c.setRequestProperty("Content-Length", body.size.toString())
            c.outputStream.use { it.write(body) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val result = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) error("Server $code: $result")
        return result
    }

    suspend fun list(): List<Song> = withContext(Dispatchers.IO) {
        val arr = JSONArray(request("/rest/v1/songs?select=id,title,artist,audio_url,cover_url,lyrics&order=created_at.desc"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Song(o.optLong("id"), o.optString("title"), o.optString("artist", "Erlangga"),
                o.optString("audio_url"), o.optString("cover_url").takeIf { it.isNotBlank() && it != "null" },
                o.optString("lyrics").takeIf { it.isNotBlank() && it != "null" })
        }
    }

    suspend fun requestPasswordRecovery(email: String) = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).toString().toByteArray()
        val redirect = java.net.URLEncoder.encode(RECOVERY_REDIRECT, "UTF-8")
        request("/auth/v1/recover?redirect_to=$redirect", "POST", body = body)
    }

    suspend fun updatePassword(token: String, password: String) = withContext(Dispatchers.IO) {
        val body = JSONObject().put("password", password).toString().toByteArray()
        request("/auth/v1/user", "PUT", token = token, body = body)
    }

    suspend fun login(email: String, password: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password).toString().toByteArray()
        val o = JSONObject(request("/auth/v1/token?grant_type=password", "POST", body = body))
        if (o.optJSONObject("user")?.optString("email") != ADMIN_EMAIL) error("Akun ini bukan akun admin BEI SONG.")
        o.getString("access_token")
    }

    suspend fun upload(context: Context, token: String, title: String, uri: Uri, coverUri: Uri?) = withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("File tidak dapat dibaca")
        val path = "audio/${UUID.randomUUID()}.mp3"
        request("/storage/v1/object/music/$path", "POST", token, bytes, "audio/mpeg")
        val audio = "$BASE/storage/v1/object/public/music/$path"
        val row = JSONObject().put("title", title).put("artist", "Be.i").put("audio_url", audio)
        if (coverUri != null) {
            val coverBytes = context.contentResolver.openInputStream(coverUri)?.use { it.readBytes() }
                ?: error("File cover tidak dapat dibaca")
            val mime = context.contentResolver.getType(coverUri) ?: "image/jpeg"
            val ext = when (mime.lowercase()) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
            val coverPath = "covers/${UUID.randomUUID()}.$ext"
            request("/storage/v1/object/music/$coverPath", "POST", token, coverBytes, mime)
            row.put("cover_url", "$BASE/storage/v1/object/public/music/$coverPath")
        }
        request("/rest/v1/songs", "POST", token, row.toString().toByteArray(), "application/json")
    }

    fun download(context: Context, song: Song) {
        val safeName = song.title.replace(Regex("[^A-Za-z0-9 _-]"), "").trim().ifBlank { "BESOUND" }
        val request = DownloadManager.Request(Uri.parse(song.audioUrl))
            .setTitle(song.title)
            .setDescription("BESOUND BEI SONG download")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "BESOUND/$safeName.mp3")
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
    }

    suspend fun updateLyrics(token: String, id: Long, lyrics: String) = withContext(Dispatchers.IO) {
        val body = JSONObject().put("lyrics", lyrics).toString().toByteArray()
        request("/rest/v1/songs?id=eq.$id", "PATCH", token, body, "application/json")
    }

    suspend fun delete(token: String, id: Long) = withContext(Dispatchers.IO) {
        request("/rest/v1/songs?id=eq.$id", "DELETE", token)
    }
}

@Composable
private fun CloudSongArtwork(song: BeiSongCloud.Song, modifier: Modifier = Modifier) {
    val bitmap by produceState<Bitmap?>(initialValue = null, song.coverUrl) {
        value = null
        val url = song.coverUrl
        if (!url.isNullOrBlank()) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val connection = URL(url).openConnection().apply { connectTimeout = 12000; readTimeout = 15000 }
                    connection.getInputStream().use { BitmapFactory.decodeStream(it) }
                }.getOrNull()
            }
        }
    }
    Box(
        modifier = modifier.background(Brush.linearGradient(listOf(Orange, Golden, Color(0xFFFFE2B7))), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(bitmap!!.asImageBitmap(), contentDescription = "Cover ${song.title}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Icon(Icons.Default.MusicNote, contentDescription = "Artwork default", tint = Color(0xFF3A2115), modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
internal fun BeiSongCloudScreen(
    onPlaySong: (BeiSongCloud.Song, List<BeiSongCloud.Song>) -> Unit,
    currentUri: String? = null,
    isPlaying: Boolean = false,
    adminPage: Boolean = false
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var songs by remember { mutableStateOf<List<BeiSongCloud.Song>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Memuat katalog...") }
    var adminToken by remember { mutableStateOf(BeiSongCloud.savedAdminToken(context)) }
    var recoveryEmail by remember { mutableStateOf(BeiSongCloud.ADMIN_EMAIL) }
    var newPassword by remember { mutableStateOf("") }
    var confirmNewPassword by remember { mutableStateOf("") }
    var showForgotPassword by remember { mutableStateOf(false) }
    val recoveryToken = BeiSongCloud.recoveryToken
    var title by remember { mutableStateOf("") }
    var selectedFile by remember { mutableStateOf<Uri?>(null) }
    var selectedCover by remember { mutableStateOf<Uri?>(null) }
    var editingLyricsSong by remember { mutableStateOf<BeiSongCloud.Song?>(null) }
    var lyricsDraft by remember { mutableStateOf("") }

    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { selectedFile = it }
    val coverPicker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { selectedCover = it }

    fun refresh() {
        scope.launch {
            loading = true
            try { songs = BeiSongCloud.list(); message = if (songs.isEmpty()) "Belum ada lagu di katalog cloud." else "" }
            catch (e: Exception) { message = "Gagal memuat katalog: ${e.message}" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("BEI SONG", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("All Songs Created Be'i", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("OFFICIAL MUSIC CATALOG", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
            }
            IconButton(onClick = { refresh() }, enabled = !loading) { Icon(Icons.Default.Refresh, "Refresh", tint = Orange) }
        }
        Spacer(Modifier.height(14.dp))
        if (adminPage && adminToken != null) {
            Text("KELOLA KATALOG", color = Golden, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Card(
                colors = CardDefaults.cardColors(containerColor = CreamCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        "ADMIN MODE",
                        color = Golden,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        letterSpacing = 0.8.sp
                    )
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Judul lagu", fontSize = 11.sp) },
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
                        modifier = Modifier.fillMaxWidth().height(54.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { picker.launch(arrayOf("audio/mpeg", "audio/mp3", "audio/*")) },
                            modifier = Modifier.height(38.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                        ) {
                            Text(
                                if (selectedFile == null) "Pilih MP3" else "MP3 dipilih",
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                        OutlinedButton(
                            onClick = { coverPicker.launch(arrayOf("image/*")) },
                            modifier = Modifier.height(38.dp),
                            contentPadding = PaddingValues(horizontal = 11.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(17.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(
                                if (selectedCover == null) "Cover" else "Cover dipilih",
                                fontSize = 12.sp,
                                maxLines = 1
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            enabled = title.isNotBlank() && selectedFile != null && !loading,
                            onClick = {
                                val file = selectedFile!!
                                val cover = selectedCover
                                scope.launch {
                                    loading = true
                                    try {
                                        BeiSongCloud.upload(context, adminToken!!, title.trim(), file, cover)
                                        title = ""
                                        selectedFile = null
                                        selectedCover = null
                                        message = "Lagu berhasil diunggah."
                                        refresh()
                                    } catch (e: Exception) {
                                        message = "Upload gagal: ${e.message}"
                                    }
                                    loading = false
                                }
                            },
                            modifier = Modifier.height(38.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Default.Upload, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(5.dp))
                            Text(if (loading) "Mengunggah..." else "Upload", fontSize = 12.sp)
                        }
                        TextButton(
                            onClick = {
                                adminToken = null
                                BeiSongCloud.clearAdminToken(context)
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                        ) {
                            Text("Keluar dari Admin", color = Orange, fontSize = 12.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Orange)
        if (message.isNotBlank()) Text(message, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            items(songs, key = { it.id }) { song ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { onPlaySong(song, songs) },
                    colors = CardDefaults.cardColors(containerColor = CreamCard),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        CloudSongArtwork(song, Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)))
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(song.title, color = Ink, fontWeight = FontWeight.Bold, maxLines = 2, lineHeight = 19.sp, overflow = TextOverflow.Ellipsis)
                            Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { onPlaySong(song, songs) }) {
                            val active = currentUri == song.audioUrl
                            Icon(
                                if (active && isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                if (active && isPlaying) "Jeda ${song.title}" else "Putar ${song.title}",
                                tint = Orange
                            )
                        }
                        if (adminPage && adminToken != null) {
                            var showSongOptions by remember(song.id) { mutableStateOf(false) }
                            Box {
                                IconButton(
                                    onClick = { showSongOptions = true },
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Icon(
                                        Icons.Default.MoreVert,
                                        contentDescription = "Opsi ${song.title}",
                                        tint = Muted,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                DropdownMenu(
                                    expanded = showSongOptions,
                                    onDismissRequest = { showSongOptions = false },
                                    modifier = Modifier.background(CreamCard)
                                ) {
                                    DropdownMenuItem(
                                        text = { Text(if (song.lyrics.isNullOrBlank()) "Tambah lirik" else "Edit lirik", color = Ink) },
                                        leadingIcon = { Icon(Icons.Default.EditNote, null, tint = Golden) },
                                        onClick = {
                                            showSongOptions = false
                                            editingLyricsSong = song
                                            lyricsDraft = song.lyrics.orEmpty()
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Unduh", color = Ink) },
                                        leadingIcon = { Icon(Icons.Default.CloudDownload, null, tint = Golden) },
                                        onClick = {
                                            showSongOptions = false
                                            BeiSongCloud.download(context, song)
                                        }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Hapus", color = Color(0xFFE05A45)) },
                                        leadingIcon = { Icon(Icons.Default.Delete, null, tint = Color(0xFFE05A45)) },
                                        onClick = {
                                            showSongOptions = false
                                            scope.launch {
                                                loading = true
                                                try {
                                                    BeiSongCloud.delete(adminToken!!, song.id)
                                                    message = "Lagu dihapus."
                                                    refresh()
                                                } catch (e: Exception) {
                                                    message = "Hapus gagal: ${e.message}"
                                                }
                                                loading = false
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (editingLyricsSong != null && adminPage && adminToken != null) {
        AlertDialog(
            onDismissRequest = { editingLyricsSong = null },
            title = { Text(if (editingLyricsSong?.lyrics.isNullOrBlank()) "Tambah lirik lagu" else "Edit lirik lagu") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(editingLyricsSong?.title.orEmpty(), color = Muted, fontSize = 13.sp)
                    OutlinedTextField(
                        value = lyricsDraft,
                        onValueChange = { lyricsDraft = it },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 8,
                        maxLines = 14,
                        placeholder = { Text("Tempel atau tulis lirik lagu di sini") },
                        label = { Text("Lirik") }
                    )
                }
            },
            confirmButton = {
                TextButton(enabled = !loading, onClick = {
                    val target = editingLyricsSong ?: return@TextButton
                    val token = adminToken ?: return@TextButton
                    scope.launch {
                        loading = true
                        try {
                            BeiSongCloud.updateLyrics(token, target.id, lyricsDraft.trim())
                            songs = songs.map { if (it.id == target.id) it.copy(lyrics = lyricsDraft.trim()) else it }
                            message = "Lirik ${target.title} berhasil disimpan."
                            editingLyricsSong = null
                        } catch (e: Exception) {
                            message = "Gagal menyimpan lirik: ${e.message}"
                        } finally { loading = false }
                    }
                }) { Text("Simpan lirik") }
            },
            dismissButton = { TextButton(onClick = { editingLyricsSong = null }) { Text("Batal") } }
        )
    }

    if (showForgotPassword) AlertDialog(
        onDismissRequest = { showForgotPassword = false },
        title = { Text("Reset Password BEI SONG") },
        text = {
            Column {
                Text("Kami akan mengirim tautan pemulihan ke email akun admin.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(recoveryEmail, { recoveryEmail = it }, label = { Text("Email akun") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = recoveryEmail.contains("@") && !loading, onClick = {
                showForgotPassword = false
                scope.launch {
                    loading = true
                    try {
                        BeiSongCloud.requestPasswordRecovery(recoveryEmail.trim())
                        message = "Jika akun terdaftar, email reset password akan dikirim. Periksa Inbox dan Spam."
                    } catch (e: Exception) { message = "Gagal meminta reset: ${e.message}" }
                    loading = false
                }
            }) { Text("Kirim Email") }
        },
        dismissButton = { TextButton(onClick = { showForgotPassword = false }) { Text("Batal") } }
    )

    if (recoveryToken != null) AlertDialog(
        onDismissRequest = { BeiSongCloud.recoveryToken = null; newPassword = ""; confirmNewPassword = "" },
        title = { Text("Buat Password Baru") },
        text = {
            Column {
                Text("Masukkan password baru untuk akun admin BESOUND.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(newPassword, { newPassword = it }, label = { Text("Password baru") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
                OutlinedTextField(confirmNewPassword, { confirmNewPassword = it }, label = { Text("Ulangi password baru") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
            }
        },
        confirmButton = {
            TextButton(enabled = newPassword.length >= 8 && newPassword == confirmNewPassword && !loading, onClick = {
                val token = recoveryToken ?: return@TextButton
                scope.launch {
                    loading = true
                    try {
                        BeiSongCloud.updatePassword(token, newPassword)
                        BeiSongCloud.recoveryToken = null
                        newPassword = ""; confirmNewPassword = ""
                        message = "Password berhasil diperbarui. Silakan login menggunakan password baru."
                    } catch (e: Exception) { message = "Gagal memperbarui password: ${e.message}" }
                    loading = false
                }
            }) { Text("Simpan Password") }
        },
        dismissButton = { TextButton(onClick = { BeiSongCloud.recoveryToken = null }) { Text("Batal") } }
    )
}
