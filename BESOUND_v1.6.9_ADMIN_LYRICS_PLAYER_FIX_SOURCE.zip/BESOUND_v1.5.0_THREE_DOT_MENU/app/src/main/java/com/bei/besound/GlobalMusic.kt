package com.bei.besound

import android.net.Uri
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.ResolvingDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Audius read-only catalog integration.
 *
 * Search results are converted to BESOUND SongEntity objects so the existing
 * Media3 queue, notification, lock-screen and mini-player can play them.
 */
data class AudiusTrack(
    val id: String,
    val title: String,
    val artist: String,
    val artworkUrl: String?,
    val durationSeconds: Long,
    val permalink: String?
) {
    fun toSongEntity(): SongEntity = SongEntity(
        uri = AudiusApi.streamUrl(id),
        title = title,
        artist = artist,
        album = "GLOBAL MUSIC • Audius",
        coverUri = artworkUrl
    )
}

object AudiusApi {
    private const val BASE_URL = "https://api.audius.co/v1"

    suspend fun searchTracks(query: String, apiKey: String = ""): List<AudiusTrack> =
        withContext(Dispatchers.IO) {
            require(query.isNotBlank()) { "Masukkan judul lagu atau nama artis." }

            val encodedQuery = URLEncoder.encode(query.trim(), "UTF-8")
            val endpoint = URL("$BASE_URL/tracks/search?query=$encodedQuery&limit=30")
            val connection = (endpoint.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 20000
                setRequestProperty("Accept", "application/json")
                if (apiKey.isNotBlank()) setRequestProperty("x-api-key", apiKey)
                setRequestProperty("User-Agent", "BESOUND-Android/1.6.3")
            }

            try {
                val status = connection.responseCode
                val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader()
                    ?.use { it.readText() }
                    .orEmpty()

                if (status !in 200..299) {
                    val message = runCatching {
                        JSONObject(body).optString("message").takeIf { it.isNotBlank() }
                    }.getOrNull()
                    throw IllegalStateException(
                        message ?: "Audius gagal merespons (HTTP $status). Coba lagi nanti."
                    )
                }

                val root = JSONObject(body)
                val data = root.optJSONArray("data") ?: return@withContext emptyList()
                buildList {
                    for (index in 0 until data.length()) {
                        val item = data.optJSONObject(index) ?: continue
                        val id = item.optString("id").takeIf { it.isNotBlank() && it != "null" } ?: continue
                        val title = item.optString("title").takeIf { it.isNotBlank() && it != "null" }
                            ?: "Untitled"
                        val user = item.optJSONObject("user")
                        val artist = user?.optString("name")
                            ?.takeIf { it.isNotBlank() && it != "null" } ?: "Unknown artist"
                        val streamable = item.optBoolean("is_streamable", true)
                        val streamGated = item.optBoolean("is_stream_gated", false)
                        if (!streamable || streamGated) continue

                        val artwork = item.optJSONObject("artwork")
                        val artworkUrl = artwork?.optString("480x480")
                            ?.takeIf { it.isNotBlank() && it != "null" }
                            ?: artwork?.optString("150x150")
                                ?.takeIf { it.isNotBlank() && it != "null" }
                        add(
                            AudiusTrack(
                                id = id,
                                title = title,
                                artist = artist,
                                artworkUrl = artworkUrl,
                                durationSeconds = item.optLong("duration", 0L),
                                permalink = item.optString("permalink").takeIf { it.isNotBlank() && it != "null" }
                            )
                        )
                    }
                }
            } finally {
                connection.disconnect()
            }
        }

    fun streamUrl(trackId: String): String =
        "$BASE_URL/tracks/${Uri.encode(trackId)}/stream"
}

/**
 * Attach the Audius API key only to Audius hosts. The key is not forwarded to
 * unrelated audio URLs used by local files or cloud playlists.
 */
@OptIn(androidx.media3.common.util.UnstableApi::class)
fun createAudiusDataSourceFactory(
    context: android.content.Context,
    apiKey: String
): ResolvingDataSource.Factory {
    // DefaultDataSource routes content://, file:// and asset:// to Android's local
    // data sources, while forwarding https:// streams (including Audius) to HTTP.
    // Using DefaultHttpDataSource directly breaks every audio file selected from
    // Android's document picker with MalformedURLException.
    val http = DefaultHttpDataSource.Factory()
    val upstream = DefaultDataSource.Factory(context.applicationContext, http)
    val resolver = object : ResolvingDataSource.Resolver {
        override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
            val host = dataSpec.uri.host.orEmpty().lowercase()
            return if (apiKey.isNotBlank() && (host == "audius.co" || host.endsWith(".audius.co"))) {
                dataSpec.withRequestHeaders(mapOf("x-api-key" to apiKey))
            } else {
                dataSpec
            }
        }
    }
    return ResolvingDataSource.Factory(upstream, resolver)
}
