# BESOUND v1.6.9

- BEI SONG public catalog no longer displays admin upload controls.
- Admin upload, download, delete, and lyrics management are available only from Profile > Mode Admin.
- Admin can add or edit cloud lyrics for each BEI SONG track.
- Playing a BEI SONG track stays on the catalog screen and updates the play/pause icon.
- BEI SONG playback loads the catalog queue so Previous/Next work in the large player.
- Previous/Next wrap around at queue boundaries.

Build has not been run in this environment; confirm the GitHub Actions result before installing.
