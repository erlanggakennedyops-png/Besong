# BESOUND v1.6.7 – Local Audio Playback Fix

- Fixes local audio playback for files selected from Android storage (`content://` document URIs).
- Replaces the HTTP-only upstream with Media3 `DefaultDataSource.Factory`, routing `content://`, `file://`, and asset URIs to Android local data sources while retaining HTTP streaming for Audius Global Music.
- Keeps the Audius API-key resolver scoped to Audius hosts.
- Preserves Library multi-select, upload consolidation, Room database, package ID, cloud integrations, notifications, queue, lyrics, and player UI.

Version code: 60. Version name: 1.6.7.
