# BESOUND Android v0.4.1 — Golden Dusk

Kotlin + Jetpack Compose + Media3 ExoPlayer + Room.

## v0.4.1 updates
- Theme dropdown now uses the active palette surface and readable on-surface text in all themes.
- Larger Shuffle, Previous, Play/Pause, Next, and Repeat touch targets and icons.
- Animated equalizer bars on Now Playing while audio is playing; bars settle when paused.
- Compact animated equalizer in the Library mini-player.
- Preserves the v0.4.0 local library, metadata editing, lyrics, playback engine, and manual theme selection.

## Build from an Android phone with the existing GitHub Actions workflow
1. Upload this ZIP to the root of your GitHub repository using the exact filename `BESOUND_v0.4_Golden_Dusk_FIXED.zip` (replace the previous archive).
2. Commit the upload to `main`. The repository workflow extracts this archive and builds the debug APK.
3. Open **Actions** and wait for **Build BESOUND Android APK** to finish.
4. Open the successful run and download the artifact **BESOUND-v0.4.1-APK**.

If your repository's workflow does not contain the step that extracts `BESOUND_v0.4_Golden_Dusk_FIXED.zip`, replace `.github/workflows/android.yml` with the workflow included in this archive before triggering the build.

Package: `com.bei.music`  
Version: `0.4.1`  
Minimum Android: `8.0` (API 26)
