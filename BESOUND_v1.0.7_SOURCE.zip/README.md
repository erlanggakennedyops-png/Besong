# BESOUND v1.0.7

Android source project for package `com.bei.besound`.

## Version
- versionCode: 8
- versionName: 1.0.7
- Database: Room schema version 2 (unchanged; no destructive migration)

## Changes in 1.0.7
- Synchronize the My Library row Play/Pause icon with the single ExoPlayer state and active media ID.
- Tapping the active track row action toggles pause/resume; tapping another track starts that track.
- Increase Library list bottom content padding so the final tracks can scroll clear of the mini-player area.
- Preserve existing metadata editing, cover art, delete behavior, playback notification, package ID, database, and signing identity.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change applicationId or release keystore for updates.
