# BESOUND v0.5.0 – Golden Dusk

Pembaruan tahap pertama: struktur navigasi dan halaman Discover.

## Navigasi
- Home: pintasan menuju katalog Bei Song, Global Music, dan Library.
- Bei Song: ruang katalog resmi karya Bei (perlu backend cloud untuk publikasi lintas pengguna).
- Global Music: ruang katalog global melalui sumber yang memiliki izin distribusi.
- Library: koleksi audio lokal di perangkat, tetap memakai database Room yang sudah ada.
- Profile: halaman akun placeholder; login/cloud belum diaktifkan.

## Catatan
Versi ini adalah pembaruan antarmuka. Bei Song dan Global Music belum melakukan streaming publik karena integrasi backend dan lisensi/sumber katalog belum dibuat. Musik lokal yang tersimpan di Room tidak dihapus oleh perubahan ini.

## Build APK
GitHub Actions menjalankan `gradle assembleDebug` langsung dari source repository. Buka tab Actions, jalankan workflow **Build BESOUND Android APK**, lalu unduh artifact `BESOUND-v0.5.0-APK`.
