# BESOUND Android v0.4

Native Android music player built with Kotlin, Jetpack Compose, Room and Media3 ExoPlayer.

## v0.4 updates
- Golden Dusk is the default theme.
- Manual theme switcher: Golden Dusk, Cream Light, and Midnight. The selected theme is saved on the device.
- Local audio import, searchable library, mini player, full player, shuffle, repeat, seek, and editable lyrics are retained from v0.3.
- BESOUND refreshed icon and branding.

## Build
Open the `BEI_MUSIC` folder in Android Studio, or push the project to GitHub and run the included GitHub Actions workflow.

APK output: `app/build/outputs/apk/debug/app-debug.apk`
