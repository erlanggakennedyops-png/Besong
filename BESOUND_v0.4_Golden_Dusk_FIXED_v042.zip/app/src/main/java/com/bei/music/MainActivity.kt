package com.bei.music

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private var Cream by mutableStateOf(Color(0xFF17120F))
private var CreamCard by mutableStateOf(Color(0xFF2A1C16))
private var Orange by mutableStateOf(Color(0xFFFF8A32))
private var Golden by mutableStateOf(Color(0xFFFFC15A))
private var Ink by mutableStateOf(Color(0xFFFFE8CE))
private var Muted by mutableStateOf(Color(0xFFB99B80))
private var NavSurface by mutableStateOf(Color(0xFF211711))
private var DividerTone by mutableStateOf(Color(0xFF493123))

private fun applyPalette(name: String) {
    when (name) {
        "Cream Light" -> {
            Cream = Color(0xFFFFF8ED); CreamCard = Color(0xFFFFE8CC)
            Orange = Color(0xFFE58B3A); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFF33291F); Muted = Color(0xFF8B7866)
            NavSurface = Color(0xFFFFF1DE); DividerTone = Color(0xFFEFE2D2)
        }
        "Midnight" -> {
            Cream = Color(0xFF10131B); CreamCard = Color(0xFF202633)
            Orange = Color(0xFFFF8B45); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFFF5F0E9); Muted = Color(0xFFA6A9B4)
            NavSurface = Color(0xFF191E29); DividerTone = Color(0xFF343B49)
        }
        else -> {
            Cream = Color(0xFF17120F); CreamCard = Color(0xFF2A1C16)
            Orange = Color(0xFFFF8A32); Golden = Color(0xFFFFC15A)
            Ink = Color(0xFFFFE8CE); Muted = Color(0xFFB99B80)
            NavSurface = Color(0xFF211711); DividerTone = Color(0xFF493123)
        }
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
        }

        val dao = MusicDatabase.get(this).songDao()

        setContent {
            val scope = rememberCoroutineScope()
            val songs by dao.observeAll().collectAsState(initial = emptyList())

            var currentUri by remember { mutableStateOf<String?>(null) }
            var isPlaying by remember { mutableStateOf(false) }
            var positionMs by remember { mutableLongStateOf(0L) }
            var durationMs by remember { mutableLongStateOf(0L) }
            var shuffleEnabled by remember { mutableStateOf(false) }
            var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
            var selectedTab by remember { mutableIntStateOf(0) }
            var searchText by remember { mutableStateOf("") }
            var showLyrics by remember { mutableStateOf(false) }
            var showEditor by remember { mutableStateOf(false) }
            var editingSong by remember { mutableStateOf<SongEntity?>(null) }
            var editTitle by remember { mutableStateOf("") }
            var editArtist by remember { mutableStateOf("") }
            var editAlbum by remember { mutableStateOf("") }
            var editLyrics by remember { mutableStateOf("") }
            var themeName by remember { mutableStateOf(getPreferences(MODE_PRIVATE).getString("besound_theme", "Golden Dusk") ?: "Golden Dusk") }
            var showThemeMenu by remember { mutableStateOf(false) }
            SideEffect { applyPalette(themeName) }
            LaunchedEffect(themeName) { getPreferences(MODE_PRIVATE).edit().putString("besound_theme", themeName).apply() }

            val currentSong = songs.firstOrNull { it.uri == currentUri }

            // Repair legacy placeholder titles such as "msf:114295" using the actual file name.
            LaunchedEffect(songs) {
                songs.filter {
                    it.title.isBlank() || it.title.startsWith("msf:", ignoreCase = true) ||
                        it.title.equals("Untitled", ignoreCase = true)
                }.forEach { song ->
                    val recoveredTitle = displayNameFor(Uri.parse(song.uri))
                    if (recoveredTitle.isNotBlank() && recoveredTitle != song.title) {
                        dao.upsert(song.copy(title = recoveredTitle))
                    }
                }
            }

            val filteredSongs = remember(songs, searchText) {
                if (searchText.isBlank()) songs
                else songs.filter {
                    it.title.contains(searchText, true) ||
                        it.artist.contains(searchText, true) ||
                        it.album.contains(searchText, true)
                }
            }

            val audioPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenMultipleDocuments()
            ) { uris ->
                uris.forEach { uri ->
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                    val metadata = readMetadata(uri)
                    val fallbackTitle = displayNameFor(uri)
                    scope.launch {
                        dao.upsert(
                            SongEntity(
                                uri = uri.toString(),
                                title = metadata.first.ifBlank { fallbackTitle },
                                artist = metadata.second.ifBlank { "Unknown artist" },
                                album = metadata.third.ifBlank { "Unknown album" }
                            )
                        )
                    }
                }
            }

            fun playSong(song: SongEntity) {
                val index = songs.indexOfFirst { it.uri == song.uri }
                if (index >= 0) {
                    currentUri = song.uri
                    player.setMediaItems(songs.map { MediaItem.fromUri(Uri.parse(it.uri)) }, index, 0L)
                    player.prepare()
                    player.play()
                    isPlaying = true
                    selectedTab = 1
                }
            }

            fun openEditor(song: SongEntity) {
                editingSong = song
                editTitle = song.title
                editArtist = song.artist
                editAlbum = song.album
                editLyrics = song.lyrics
                showEditor = true
            }

            LaunchedEffect(Unit) {
                while (true) {
                    isPlaying = player.isPlaying
                    positionMs = player.currentPosition.coerceAtLeast(0L)
                    durationMs = player.duration.takeIf { it > 0L } ?: 0L
                    val index = player.currentMediaItemIndex
                    if (index in songs.indices) currentUri = songs[index].uri
                    delay(400)
                }
            }

            DisposableEffect(player) {
                val listener = object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) {
                        isPlaying = playing
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        val index = player.currentMediaItemIndex
                        if (index in songs.indices) currentUri = songs[index].uri
                    }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        durationMs = player.duration.takeIf { it > 0L } ?: 0L
                    }
                }
                player.addListener(listener)
                onDispose { player.removeListener(listener) }
            }

            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Orange,
                    onPrimary = Color.White,
                    secondary = Golden,
                    background = Cream,
                    surface = Cream,
                    onBackground = Ink,
                    onSurface = Ink,
                    onSurfaceVariant = Muted,
                    surfaceVariant = CreamCard,
                    secondaryContainer = CreamCard,
                    onSecondaryContainer = Ink
                )
            ) {
                Scaffold(
                    containerColor = Cream,
                    bottomBar = {
                        NavigationBar(containerColor = NavSurface) {
                            NavigationBarItem(
                                selected = selectedTab == 0,
                                onClick = { selectedTab = 0 },
                                icon = { Icon(Icons.Default.LibraryMusic, null) },
                                label = { Text("Library") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Orange,
                                    selectedTextColor = Ink,
                                    indicatorColor = CreamCard,
                                    unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                            NavigationBarItem(
                                selected = selectedTab == 1,
                                onClick = { selectedTab = 1 },
                                icon = { Icon(Icons.Default.GraphicEq, null) },
                                label = { Text("Now Playing") },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = Orange,
                                    selectedTextColor = Ink,
                                    indicatorColor = CreamCard,
                                    unselectedIconColor = Muted,
                                    unselectedTextColor = Muted
                                )
                            )
                        }
                    }
                ) { padding ->
                    Column(
                        Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                    ) {
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "BESOUND",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Ink,
                                    letterSpacing = (-0.8).sp
                                )
                                Text(
                                    "Your music. Your lyrics. Your world.",
                                    color = Muted,
                                    fontSize = 12.sp
                                )
                            }
                            Box {
                                IconButton(onClick = { showThemeMenu = true }) {
                                    Icon(Icons.Default.Palette, "Ganti tema", tint = Orange, modifier = Modifier.size(30.dp))
                                }
                                DropdownMenu(
                                    expanded = showThemeMenu,
                                    onDismissRequest = { showThemeMenu = false },
                                    containerColor = CreamCard,
                                    tonalElevation = 8.dp,
                                    shadowElevation = 8.dp
                                ) {
                                    listOf("Golden Dusk", "Cream Light", "Midnight").forEach { option ->
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        option,
                                                        color = Ink,
                                                        fontWeight = if (themeName == option) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                    if (themeName == option) {
                                                        Spacer(Modifier.width(12.dp))
                                                        Icon(Icons.Default.Check, contentDescription = "Tema aktif", tint = Orange)
                                                    }
                                                }
                                            },
                                            onClick = { themeName = option; showThemeMenu = false }
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))

                        if (selectedTab == 0) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CreamCard),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("YOUR LIBRARY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("${songs.size} lagu tersimpan", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                                    Spacer(Modifier.height(12.dp))
                                    Button(
                                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Orange),
                                        shape = RoundedCornerShape(28.dp)
                                    ) {
                                        Icon(Icons.Default.Upload, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Upload musik")
                                    }
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            OutlinedTextField(
                                value = searchText,
                                onValueChange = { searchText = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("Cari lagu, artis, atau album...") },
                                leadingIcon = { Icon(Icons.Default.Search, null, tint = Orange) },
                                shape = RoundedCornerShape(18.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Ink,
                                    unfocusedTextColor = Ink,
                                    cursorColor = Orange,
                                    focusedPlaceholderColor = Muted,
                                    unfocusedPlaceholderColor = Muted,
                                    focusedLeadingIconColor = Orange,
                                    unfocusedLeadingIconColor = Orange,
                                    focusedBorderColor = Orange,
                                    unfocusedBorderColor = DividerTone,
                                    focusedContainerColor = Cream,
                                    unfocusedContainerColor = Cream
                                )
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("My Library", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                                Text("LOCAL", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            if (filteredSongs.isEmpty()) {
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.LibraryMusic, null, tint = Orange, modifier = Modifier.size(48.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text(if (songs.isEmpty()) "Belum ada lagu" else "Lagu tidak ditemukan", fontWeight = FontWeight.Bold, color = Ink)
                                        Text("Upload MP3 atau audio dari HP kamu.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            } else {
                                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
                                    items(filteredSongs, key = { it.uri }) { song ->
                                        ListItem(
                                            modifier = Modifier.clickable { playSong(song) },
                                            headlineContent = {
                                                Text(song.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            },
                                            supportingContent = {
                                                Text("${song.artist} • ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted)
                                            },
                                            leadingContent = {
                                                Box(
                                                    Modifier.size(48.dp).clip(RoundedCornerShape(13.dp))
                                                        .background(Brush.linearGradient(listOf(Orange, Golden))),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(26.dp))
                                                }
                                            },
                                            trailingContent = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(onClick = { openEditor(song) }) {
                                                        Icon(Icons.Default.Edit, "Edit lagu", tint = Ink)
                                                    }
                                                    IconButton(onClick = { playSong(song) }) {
                                                        Icon(Icons.Default.PlayArrow, "Putar", tint = Orange)
                                                    }
                                                }
                                            },
                                            colors = ListItemDefaults.colors(containerColor = Cream)
                                        )
                                        HorizontalDivider(color = DividerTone)
                                    }
                                }
                            }
                        } else {
                            NowPlayingScreen(
                                song = currentSong,
                                isPlaying = isPlaying,
                                positionMs = positionMs,
                                durationMs = durationMs,
                                shuffleEnabled = shuffleEnabled,
                                repeatMode = repeatMode,
                                onPlayPause = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.currentMediaItem != null) player.play()
                                    isPlaying = player.isPlaying
                                },
                                onPrevious = {
                                    if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                    else if (player.currentMediaItem != null) player.seekTo(0)
                                },
                                onNext = {
                                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                },
                                onSeek = { player.seekTo(it) },
                                onShuffle = {
                                    shuffleEnabled = !shuffleEnabled
                                    player.shuffleModeEnabled = shuffleEnabled
                                },
                                onRepeat = {
                                    repeatMode = when (repeatMode) {
                                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                        else -> Player.REPEAT_MODE_OFF
                                    }
                                    player.repeatMode = repeatMode
                                },
                                onLyrics = { currentSong?.let { openEditor(it); showLyrics = true } }
                            )
                        }

                        if (selectedTab == 0) {
                            MiniPlayer(
                                song = currentSong,
                                isPlaying = isPlaying,
                                onPlayPause = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.currentMediaItem != null) player.play()
                                },
                                onOpen = { selectedTab = 1 },
                                onLyrics = { currentSong?.let { openEditor(it); showLyrics = true } }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "v0.4.2 • Golden Dusk • Player polish",
                            color = Muted,
                            fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp)
                        )
                    }
                }
            }

            if (showEditor && editingSong != null) {
                AlertDialog(
                    onDismissRequest = { showEditor = false; showLyrics = false },
                    title = { Text(if (showLyrics) "Lyrics Studio" else "Edit lagu & lirik") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (!showLyrics) {
                                OutlinedTextField(editTitle, { editTitle = it }, label = { Text("Judul lagu") }, singleLine = true)
                                OutlinedTextField(editArtist, { editArtist = it }, label = { Text("Artis") }, singleLine = true)
                                OutlinedTextField(editAlbum, { editAlbum = it }, label = { Text("Album") }, singleLine = true)
                            }
                            OutlinedTextField(
                                editLyrics,
                                { editLyrics = it },
                                label = { Text("Lirik lagu") },
                                minLines = 5,
                                maxLines = 9
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            editingSong?.let { old ->
                                scope.launch {
                                    dao.upsert(old.copy(
                                        title = editTitle.ifBlank { "Untitled" },
                                        artist = editArtist.ifBlank { "Unknown artist" },
                                        album = editAlbum.ifBlank { "Unknown album" },
                                        lyrics = editLyrics
                                    ))
                                }
                            }
                            showEditor = false
                            showLyrics = false
                        }) { Text("Simpan") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditor = false; showLyrics = false }) { Text("Tutup") }
                    }
                )
            }
        }
    }

    private fun displayNameFor(uri: Uri): String {
        var displayName = ""
        runCatching {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (column >= 0) displayName = cursor.getString(column).orEmpty()
                }
            }
        }
        if (displayName.isBlank()) {
            displayName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':').orEmpty()
        }
        val withoutExtension = displayName.substringBeforeLast('.', displayName).trim()
        return withoutExtension.ifBlank { "Untitled" }
    }

    private fun readMetadata(uri: Uri): Triple<String, String, String> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            Triple(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
            )
        } catch (_: Exception) {
            Triple("", "", "")
        } finally {
            runCatching { retriever.release() }
        }
    }

    override fun onDestroy() {
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

@Composable
private fun ColumnScope.NowPlayingScreen(
    song: SongEntity?,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    shuffleEnabled: Boolean,
    repeatMode: Int,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onLyrics: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "NOW PLAYING",
            color = Orange,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        Spacer(Modifier.height(12.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 270.dp)
                .aspectRatio(1f)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(Orange, Golden, Color(0xFFFFE2B7))),
                    RoundedCornerShape(28.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.Headphones,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(76.dp)
                )
                Text(
                    "BESOUND",
                    color = Color.White,
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(
            song?.title ?: "Belum ada lagu dipilih",
            color = Ink,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            song?.artist ?: "Pilih lagu dari Library",
            color = Muted,
            fontSize = 14.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        MusicVisualizer(
            isPlaying = isPlaying,
            modifier = Modifier.padding(top = 9.dp),
            barColor = Orange,
            barCount = 11,
            maxBarHeight = 34.dp
        )
        Spacer(Modifier.height(4.dp))
        Slider(
            value = positionMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1L).toFloat()),
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(),
            enabled = durationMs > 0L,
            colors = SliderDefaults.colors(
                thumbColor = Orange,
                activeTrackColor = Orange,
                inactiveTrackColor = DividerTone
            )
        )
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(formatTime(positionMs), color = Muted, fontSize = 11.sp)
            Text(formatTime(durationMs), color = Muted, fontSize = 11.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 0.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = onShuffle, modifier = Modifier.size(56.dp)) {
                Icon(
                    Icons.Default.Shuffle,
                    "Shuffle",
                    tint = if (shuffleEnabled) Orange else Muted,
                    modifier = Modifier.size(29.dp)
                )
            }
            IconButton(onClick = onPrevious, modifier = Modifier.size(62.dp)) {
                Icon(Icons.Default.SkipPrevious, "Previous", tint = Ink, modifier = Modifier.size(39.dp))
            }
            FilledIconButton(
                onClick = onPlayPause,
                enabled = song != null,
                modifier = Modifier.size(76.dp),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = Orange,
                    contentColor = Color.White,
                    disabledContainerColor = DividerTone,
                    disabledContentColor = Muted
                )
            ) {
                Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    "Play atau pause",
                    tint = Color.White,
                    modifier = Modifier.size(44.dp)
                )
            }
            IconButton(onClick = onNext, modifier = Modifier.size(62.dp)) {
                Icon(Icons.Default.SkipNext, "Next", tint = Ink, modifier = Modifier.size(39.dp))
            }
            IconButton(onClick = onRepeat, modifier = Modifier.size(56.dp)) {
                Icon(
                    if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                    "Repeat",
                    tint = if (repeatMode == Player.REPEAT_MODE_OFF) Muted else Orange,
                    modifier = Modifier.size(29.dp)
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = onLyrics,
            enabled = song != null,
            border = ButtonDefaults.outlinedButtonBorder.copy(
                brush = Brush.linearGradient(listOf(Orange, Golden))
            ),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink)
        ) {
            Icon(Icons.Default.Lyrics, null, tint = Orange)
            Spacer(Modifier.width(8.dp))
            Text("Lihat / edit lirik")
        }
    }
}

@Composable
private fun MusicVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = Orange,
    barCount: Int = 7,
    maxBarHeight: androidx.compose.ui.unit.Dp = 30.dp
) {
    val transition = rememberInfiniteTransition(label = "besound_equalizer")
    Row(
        modifier = modifier.height(maxBarHeight),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(barCount) { index ->
            val animatedHeight by transition.animateFloat(
                initialValue = 0.18f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 360 + (index % 4) * 115,
                        delayMillis = index * 65,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "equalizer_bar_$index"
            )
            val barFraction = if (isPlaying) animatedHeight else 0.18f
            Box(
                Modifier
                    .width(4.dp)
                    .height(maxBarHeight * barFraction.coerceIn(0.12f, 1f))
                    .clip(CircleShape)
                    .background(barColor)
            )
        }
    }
}

@Composable
private fun MiniPlayer(
    song: SongEntity?,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onOpen: () -> Unit,
    onLyrics: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CreamCard),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { onOpen() }
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(Orange, Golden))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(27.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song?.title ?: "Pilih lagu untuk diputar",
                    color = Ink,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    song?.artist ?: "BESOUND PLAYER",
                    color = Muted,
                    fontSize = 11.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            MusicVisualizer(
                isPlaying = isPlaying,
                modifier = Modifier.padding(horizontal = 4.dp),
                barColor = Orange,
                barCount = 5,
                maxBarHeight = 25.dp
            )
            IconButton(
                onClick = onPlayPause,
                enabled = song != null,
                modifier = Modifier.size(52.dp)
            ) {
                Icon(
                    if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    "Play atau pause",
                    tint = Orange,
                    modifier = Modifier.size(34.dp)
                )
            }
            IconButton(
                onClick = onLyrics,
                enabled = song != null,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.Lyrics, "Lirik", tint = Ink, modifier = Modifier.size(26.dp))
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0L) / 1000L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
