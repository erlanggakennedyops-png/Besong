# BESOUND v0.8.2 – Lyrics Scroll Fix

## Changes
- Corrected vertical gesture direction: finger moving down opens Lyrics from Now Playing; finger moving up is the return gesture.
- Removed the fullscreen Lyrics parent-level swipe detector so it no longer competes with vertical lyric scrolling.
- Restricted the swipe-up-to-player gesture to the bottom `SWIPE UP TO PLAYER` hint area.
- Version name 0.8.2, version code 16.

## Build
The repository workflow expects this source archive at the repository root as `BESOUND_v0.8.2_LYRICS_SCROLL_FIX.zip`. Replace `.github/workflows/android.yml` with the matching workflow included in this archive, then commit both files.

Build verification is performed by GitHub Actions. No successful APK build is claimed by this source package alone.
