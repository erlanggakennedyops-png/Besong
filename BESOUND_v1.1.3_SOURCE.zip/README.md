# BESOUND v1.1.3

Package `com.bei.besound`, versionCode 14, versionName 1.1.3. Database schema unchanged (v2).

## Fix: cover lagu tidak muncul di notifikasi & lockscreen
- Notifikasi/lockscreen sekarang membaca cover, judul, dan artis langsung dari database (Room), bukan dari MediaItem di playlist yang bisa basi.
- Cache cover tidak lagi menyimpan hasil gagal (null), jadi cover yang gagal load akan dicoba lagi.
- Bitmap untuk MediaSession diperkecil (maks 400px) dan memakai instance yang sama untuk ART / ALBUM_ART / DISPLAY_ICON.
- Edit cover lagu yang sedang diputar tidak lagi mengganti MediaItem (tidak mereset lagu), cukup refresh metadata sesi + notifikasi.
- Perubahan database (cover baru) otomatis disinkronkan ke notifikasi.

Belum dikompilasi/dites di perangkat di lingkungan ini; build lewat GitHub Actions.
