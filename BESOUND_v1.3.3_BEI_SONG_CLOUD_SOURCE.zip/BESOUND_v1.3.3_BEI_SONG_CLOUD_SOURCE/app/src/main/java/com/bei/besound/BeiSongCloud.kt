package com.bei.besound

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.DataOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

private object BeiSongCloud {
    const val BASE = "https://awgmpmitmicvovxkucwa.supabase.co"
    const val API_KEY = "sb_publishable_wfhyIDcvbzBSeDh6cJxb_w_h9eGUxxL"
    const val ADMIN_EMAIL = "galangkennedy10@gmail.com"

    data class Song(val id: Long, val title: String, val artist: String, val audioUrl: String, val coverUrl: String?, val lyrics: String?)

    private fun request(path: String, method: String = "GET", token: String? = null, body: ByteArray? = null, contentType: String? = null): String {
        val c = (URL("$BASE$path").openConnection() as HttpURLConnection)
        c.requestMethod = method
        c.connectTimeout = 20000
        c.readTimeout = 30000
        c.setRequestProperty("apikey", API_KEY)
        if (!token.isNullOrBlank()) c.setRequestProperty("Authorization", "Bearer $token")
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", contentType ?: "application/json")
            c.setRequestProperty("Content-Length", body.size.toString())
            c.outputStream.use { it.write(body) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val result = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        c.disconnect()
        if (code !in 200..299) error("Server $code: $result")
        return result
    }

    suspend fun list(): List<Song> = withContext(Dispatchers.IO) {
        val arr = JSONArray(request("/rest/v1/songs?select=id,title,artist,audio_url,cover_url,lyrics&order=created_at.desc"))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Song(o.optLong("id"), o.optString("title"), o.optString("artist", "Erlangga"),
                o.optString("audio_url"), o.optString("cover_url").takeIf { it.isNotBlank() && it != "null" },
                o.optString("lyrics").takeIf { it.isNotBlank() && it != "null" })
        }
    }

    suspend fun login(email: String, password: String): String = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email).put("password", password).toString().toByteArray()
        val o = JSONObject(request("/auth/v1/token?grant_type=password", "POST", body = body))
        if (o.optJSONObject("user")?.optString("email") != ADMIN_EMAIL) error("Akun ini bukan akun admin BEI SONG.")
        o.getString("access_token")
    }

    suspend fun upload(context: Context, token: String, title: String, uri: Uri) = withContext(Dispatchers.IO) {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("File tidak dapat dibaca")
        val path = "audio/${UUID.randomUUID()}.mp3"
        request("/storage/v1/object/music/$path", "POST", token, bytes, "audio/mpeg")
        val audio = "$BASE/storage/v1/object/public/music/$path"
        val row = JSONObject().put("title", title).put("artist", "Erlangga").put("audio_url", audio)
        request("/rest/v1/songs", "POST", token, row.toString().toByteArray(), "application/json")
    }

    suspend fun delete(token: String, id: Long) = withContext(Dispatchers.IO) {
        request("/rest/v1/songs?id=eq.$id", "DELETE", token)
    }
}

@Composable
fun BeiSongCloudScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var songs by remember { mutableStateOf<List<BeiSongCloud.Song>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Memuat katalog...") }
    var adminToken by remember { mutableStateOf<String?>(null) }
    var showLogin by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf(BeiSongCloud.ADMIN_EMAIL) }
    var password by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var selectedFile by remember { mutableStateOf<Uri?>(null) }

    val picker = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { selectedFile = it }

    fun refresh() {
        scope.launch {
            loading = true
            try { songs = BeiSongCloud.list(); message = if (songs.isEmpty()) "Belum ada lagu di katalog cloud." else "" }
            catch (e: Exception) { message = "Gagal memuat katalog: ${e.message}" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { refresh() }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("BEI SONG", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("All Songs Created Be'i", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
                Text("OFFICIAL MUSIC CATALOG", color = Muted, fontSize = 10.sp, letterSpacing = 1.4.sp)
            }
            IconButton(onClick = { refresh() }, enabled = !loading) { Icon(Icons.Default.Refresh, "Refresh", tint = Orange) }
            IconButton(onClick = { showLogin = true }) { Icon(Icons.Default.Lock, "Admin", tint = Golden) }
        }
        Spacer(Modifier.height(14.dp))
        if (adminToken != null) {
            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Text("ADMIN MODE", color = Golden, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Judul lagu") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { picker.launch(arrayOf("audio/mpeg", "audio/mp3", "audio/*")) }) { Text(if (selectedFile == null) "Pilih MP3" else "MP3 dipilih") }
                        Spacer(Modifier.width(8.dp))
                        Button(enabled = title.isNotBlank() && selectedFile != null && !loading, onClick = {
                            val file = selectedFile!!
                            scope.launch {
                                loading = true
                                try { BeiSongCloud.upload(context, adminToken!!, title.trim(), file); title = ""; selectedFile = null; message = "Lagu berhasil diunggah."; refresh() }
                                catch (e: Exception) { message = "Upload gagal: ${e.message}" }
                                loading = false
                            }
                        }) { Icon(Icons.Default.Upload, null); Text(" Upload") }
                    }
                    TextButton(onClick = { adminToken = null }) { Text("Keluar dari Admin") }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Orange)
        if (message.isNotBlank()) Text(message, color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 28.dp)) {
            items(songs, key = { it.id }) { song ->
                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, null, tint = Orange, modifier = Modifier.size(34.dp))
                        Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                            Text(song.title, color = Ink, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text(song.artist, color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = {
                            player.setMediaItem(MediaItem.fromUri(song.audioUrl)); player.prepare(); player.play()
                        }) { Icon(Icons.Default.PlayArrow, "Putar", tint = Orange) }
                        IconButton(onClick = {
                            val req = DownloadManager.Request(Uri.parse(song.audioUrl))
                                .setTitle(song.title).setDescription("BESOUND offline download")
                                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "BESOUND/${song.title.replace(Regex("[^A-Za-z0-9 _-]"), "")}.mp3")
                            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                        }) { Icon(Icons.Default.CloudDownload, "Download", tint = Golden) }
                        if (adminToken != null) TextButton(onClick = {
                            scope.launch {
                                loading = true
                                try { BeiSongCloud.delete(adminToken!!, song.id); message = "Lagu dihapus."; refresh() }
                                catch (e: Exception) { message = "Hapus gagal: ${e.message}" }
                                loading = false
                            }
                        }) { Text("Hapus", color = MaterialTheme.colorScheme.error, fontSize = 11.sp) }
                    }
                }
            }
        }
    }

    if (showLogin) AlertDialog(
        onDismissRequest = { showLogin = false },
        title = { Text("Admin BEI SONG") },
        text = {
            Column {
                OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true)
                OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                showLogin = false
                scope.launch {
                    loading = true
                    try { adminToken = BeiSongCloud.login(email.trim(), password); password = ""; message = "Login admin berhasil." }
                    catch (e: Exception) { message = "Login gagal: ${e.message}" }
                    loading = false
                }
            }) { Text("Login") }
        },
        dismissButton = { TextButton(onClick = { showLogin = false }) { Text("Batal") } }
    )
}
