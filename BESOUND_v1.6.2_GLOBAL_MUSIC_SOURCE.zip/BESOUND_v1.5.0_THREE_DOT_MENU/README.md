# BESOUND v1.6.2 - Global Music Full Playback

Android project for `com.bei.besound`.

## Release identity
- `versionName`: `1.6.2`
- `versionCode`: `55`
- `minSdk`: 26
- `targetSdk`: 35

## Included updates
- Profile reorganized as the account and settings hub.
- Application settings for Audio & Equalizer, Storage & Cache, Notifications, Network & Data, Privacy & Security, and About BESOUND.
- Android audio-session Equalizer with ten visible frequency controls, presets, Bass Boost, Virtualizer, and Loudness Enhancement where supported.
- Persistent Mini Player above bottom navigation while a track is selected.
- Full-width home search field.
- Unified Golden Dusk, Cream Light, and Midnight color palettes across primary screens.

## Build with GitHub Actions
1. Upload `BESOUND_v1.6.2_GLOBAL_MUSIC_SOURCE.zip` to the repository root, replacing the previous source archive.
2. Put the updated workflow file at `.github/workflows/android.yml`.
3. Configure the Android signing secrets used by the workflow.
4. Run **Build BESOUND Android APK** from the Actions tab, or push a change to either the source ZIP or workflow on `main`.
5. Download the `BESOUND-v1.6.2-Release` artifact after a successful run.

The workflow checks the ZIP structure, application ID, version code/name, and APK signature before uploading the release artifact.

## Signing secrets
The workflow accepts `BESOUND_KEYSTORE_BASE64` (or the supported legacy aliases), `BESOUND_KEY_ALIAS`, `BESOUND_STORE_PASSWORD`, and `BESOUND_KEY_PASSWORD`. Keep these values in GitHub Actions Secrets; never put keystores or passwords in the repository.

## Audio note
Audio effects attach to the active ExoPlayer audio session. Availability depends on the Android device. The ten on-screen EQ controls are mapped to the nearest frequency bands exposed by the device's native Equalizer implementation.

## Validation note
The source ZIP structure and workflow configuration were checked when this package was prepared. A full Android build and device-level playback test still need to run in GitHub Actions and on an Android device.


## Global Music full playback (v1.6.2)
- Global Music search uses the Audius read-only REST API.
- Eligible Audius tracks stream directly through BESOUND's existing Media3 ExoPlayer.
- Search results enter the same queue and use the existing player, notification and lock-screen controls.
- Add the GitHub Actions secret `AUDIUS_API_KEY` before building. Obtain a free developer key at https://api.audius.co/plans.
- The API key is injected at build time through `BuildConfig`; do not paste it into Kotlin source or commit it to the repository.
- Only tracks marked streamable and not stream-gated are shown. Audius does not contain every commercial release.
