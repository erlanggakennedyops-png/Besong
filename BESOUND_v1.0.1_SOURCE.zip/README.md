# BESOUND v1.0.1 — Golden Dusk

Package: `com.bei.besound` (kept unchanged for in-place updates).
Version code: 2. Version name: 1.0.1.

Changes from v1.0.0:
- Adds Android media playback notification with Play/Pause, Previous and Next controls.
- Adds media session metadata for the current title and artist.
- Requests Android 13+ notification permission when needed.
- Keeps the existing Golden Dusk UI, Room library database, upload flow and unified swipe-up lyrics gesture.

Build/signing remains configured through GitHub Actions repository secrets. Never commit a keystore or its passwords.
