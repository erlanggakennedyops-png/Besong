# BESOUND v0.7.7 – Golden Dusk Vertical Swipe Fix

## Player gestures
- Swipe down anywhere on Now Playing to open the full-screen Lyrics view.
- Swipe up anywhere on the Lyrics view to return to Now Playing.
- Gesture detection runs in the Initial pointer event pass so nested controls such as the seek slider and lyrics scrolling do not intercept vertical swipes first.
- Horizontal gestures are ignored.
- No lyrics icon or lyrics button is shown.

## Build
GitHub Actions workflow: `.github/workflows/android.yml`
Artifact: `BESOUND-v0.7.7-APK`
Gradle task: `assembleDebug`

The ZIP has not been built or tested as an APK in this environment. Run the GitHub Actions workflow and install the generated artifact to verify behavior on-device.
