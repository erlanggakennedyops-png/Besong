# BESOUND v1.0.2 — Golden Dusk

Package: `com.bei.besound` (unchanged; intended as an in-place update).
Version code: 3. Version name: 1.0.2.

Changes from v1.0.1:
- Keeps the existing ExoPlayer and PlayerNotificationManager architecture.
- Synchronizes MediaSessionCompat metadata (title, artist, album and duration) with the active ExoPlayer item.
- Publishes playback state, position and supported transport actions to the media session so Android media controls have current state information.
- Updates session metadata on item transitions, playback state changes, play/pause changes and seek discontinuities, with a periodic refresh while the UI is active.
- Keeps the existing UI, Room database, upload flow, package ID and signing configuration.

Important limitation: this is a targeted media-session metadata/state fix, not yet the planned MediaSessionService migration. The player is still owned by MainActivity, so background-process resilience is not fully solved in this version. Test background playback on the target phone before wider release.

Build/signing remains configured through GitHub Actions repository secrets. Do not commit a keystore or its passwords. Keep using the same release keystore as v1.0.1 for in-place updates.
