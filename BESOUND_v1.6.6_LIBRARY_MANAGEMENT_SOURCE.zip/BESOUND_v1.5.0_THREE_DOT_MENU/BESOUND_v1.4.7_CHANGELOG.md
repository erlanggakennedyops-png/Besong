# BESOUND v1.4.7 — Playlist and account fixes

- Moved regular cloud account login/sign-up entry point to Profile. Playlist screen now directs signed-out users to Profile instead of rendering its own login form.
- Moved BEI SONG admin login entry point to Profile; admin access token is stored in app-private preferences and can be revoked from Profile. BEI SONG no longer displays its own lock/login dialog.
- Made playlist screen content vertically scrollable, including playlist detail and long track lists.
- Replaced grid lazy container nested inside a scrolling page with two-column rows to avoid nested-scroll clipping.
- Playlist playback now loads the selected playlist as a dedicated Media3 queue. Next/Previous therefore stay within that playlist.
- Player state tracks external playlist media IDs and metadata across queue transitions, keeping Now Playing and mini-player metadata in sync.
- Add-song picker filters out tracks already in the selected playlist; API layer also checks for an existing audio URL before inserting.
- Playlist overflow menu now has an explicit dark background and high-contrast cream text; destructive action is red.
- Version: 1.4.7 (versionCode 48); package remains com.bei.besound.

Build status: source-level edits and ZIP integrity checked. Gradle compilation has not been run in this environment.
- Logout is also centralized in Profile; Playlist no longer exposes a separate logout control.
