# BESOUND v1.6.0 — Home Redesign

- Redesigned Home with a playable featured track from the local library.
- Added working Trending (ranked by actual play counts) and New Releases feed shortcuts.
- Added horizontal song cards with persistent Favorites.
- Added editable per-track mood tags and working mood filters (Room migration v3→v4).
- Added Favorites screen backed by SharedPreferences.
- Added Daily Mix and Fresh Mix using real local playback queues.
- Added Playlist and History shortcuts to existing screens.
- Removed the Home search icon; search remains a plain text field.
- Added playback queue dialog to Now Playing with select, reorder, and remove actions.
- Added `addedAt` Room column with a v2→v3 migration for newest-first local imports.
- Preserved existing Room songs, playback, playlist cloud, and media notification behavior.

Build/test status: source changes and archive integrity checks only. Run the Android Gradle workflow and test on a physical device before release.
