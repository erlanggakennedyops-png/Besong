# BESOUND v1.6.2 – Global Music Full Playback

- Replaced the Global Music placeholder with live Audius track search.
- Displays playable search results with artist names and album artwork.
- Streams eligible Audius tracks directly inside BESOUND using the existing Media3 ExoPlayer.
- Global Music results use the existing BESOUND queue, full player, mini player, Android media notification and lock-screen controls.
- Audius API key is read from the AUDIUS_API_KEY environment variable at build time and is never hardcoded in the source.
- Gated or non-streamable tracks are excluded from results.

## Required setup
Create a free Audius developer API key at https://api.audius.co/plans and add it to GitHub Actions Secrets as `AUDIUS_API_KEY`.

This integration searches and streams eligible tracks available in Audius. It does not provide access to every commercial or mainstream music catalog, and availability depends on each track's streaming permissions.
