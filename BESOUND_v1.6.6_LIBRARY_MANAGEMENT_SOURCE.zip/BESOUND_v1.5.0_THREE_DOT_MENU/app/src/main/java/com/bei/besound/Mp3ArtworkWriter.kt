package com.bei.besound

import android.content.Context
import android.net.Uri
import com.mpatric.mp3agic.ID3v2
import com.mpatric.mp3agic.ID3v24Tag
import com.mpatric.mp3agic.Mp3File
import java.io.File
import java.io.InputStream
import java.io.OutputStream

/**
 * Embeds selected cover art into an MP3's ID3v2 APIC front-cover frame.
 *
 * The original document is copied to cache first, modified in a separate file,
 * and verified before attempting to replace the selected document. A backup is
 * retained for best-effort restoration if the document provider fails mid-write.
 */
internal object Mp3ArtworkWriter {

    fun embed(
        context: Context,
        audioUri: Uri,
        coverUri: Uri?,
        title: String,
        artist: String,
        album: String
    ) {
        val original = File.createTempFile("besound-original-", ".mp3", context.cacheDir)
        val modified = File.createTempFile("besound-tagged-", ".mp3", context.cacheDir)
        val backup = File.createTempFile("besound-backup-", ".mp3", context.cacheDir)

        try {
            openInput(context, audioUri).use { input ->
                original.outputStream().use { output -> input.copyTo(output) }
            }
            check(original.length() > 0L) { "File MP3 kosong atau tidak bisa dibaca." }
            original.copyTo(backup, overwrite = true)

            val mp3 = try {
                Mp3File(original.absolutePath)
            } catch (error: Exception) {
                throw IllegalArgumentException(
                    "File yang dipilih bukan MP3 yang valid atau tidak didukung.",
                    error
                )
            }

            val tag: ID3v2 = if (mp3.hasId3v2Tag()) {
                mp3.id3v2Tag
            } else {
                ID3v24Tag().also { mp3.setId3v2Tag(it) }
            }

            tag.setTitle(title)
            tag.setArtist(artist)
            tag.setAlbum(album)

            if (coverUri != null) {
                val imageBytes = openInput(context, coverUri).use { it.readBytes() }
                check(imageBytes.isNotEmpty()) { "File cover kosong." }
                val mimeType = context.contentResolver.getType(coverUri)
                    ?: when (coverUri.lastPathSegment.orEmpty().substringAfterLast('.', "").lowercase()) {
                        "png" -> "image/png"
                        "webp" -> "image/webp"
                        else -> "image/jpeg"
                    }
                // mp3agic's ID3v2.setAlbumImage(byte[], String) writes the
                // standard album-picture frame used by compatible MP3 players.
                tag.setAlbumImage(imageBytes, mimeType)
            } else {
                tag.clearFrameSet("APIC")
            }

            mp3.save(modified.absolutePath)
            check(modified.length() > 0L) { "Gagal membuat MP3 dengan metadata baru." }

            // Verify the new ID3 artwork before writing anything back to the source URI.
            val verified = Mp3File(modified.absolutePath)
            if (coverUri != null) {
                check(verified.hasId3v2Tag() && verified.id3v2Tag.albumImage != null) {
                    "Cover gagal tertanam ke metadata MP3."
                }
            }

            try {
                openOutput(context, audioUri).use { output ->
                    modified.inputStream().use { input -> input.copyTo(output) }
                    output.flush()
                }
            } catch (writeError: Exception) {
                // Restore the original bytes if the provider allowed a partial write.
                runCatching {
                    openOutput(context, audioUri).use { output ->
                        backup.inputStream().use { input -> input.copyTo(output) }
                        output.flush()
                    }
                }
                throw IllegalStateException(
                    "Tidak bisa menulis MP3 asli. Pilih ulang file melalui Upload musik agar BESOUND mendapat izin edit. Detail: ${writeError.message}",
                    writeError
                )
            }
        } finally {
            original.delete()
            modified.delete()
            backup.delete()
        }
    }

    private fun openInput(context: Context, uri: Uri): InputStream {
        return if (uri.scheme == "file") {
            File(requireNotNull(uri.path)).inputStream()
        } else {
            context.contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Tidak bisa membaca file: $uri")
        }
    }

    private fun openOutput(context: Context, uri: Uri): OutputStream {
        return if (uri.scheme == "file") {
            File(requireNotNull(uri.path)).outputStream()
        } else {
            runCatching { context.contentResolver.openOutputStream(uri, "wt") }.getOrNull()
                ?: context.contentResolver.openOutputStream(uri, "w")
                ?: throw IllegalStateException(
                    "Penyedia file tidak memberi akses tulis ke MP3 ini."
                )
        }
    }
}
