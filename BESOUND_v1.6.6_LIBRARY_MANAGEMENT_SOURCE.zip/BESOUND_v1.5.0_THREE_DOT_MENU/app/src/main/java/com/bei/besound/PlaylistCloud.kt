package com.bei.besound

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Image as ImageIcon
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.security.SecureRandom
import java.security.MessageDigest
import android.util.Base64

internal object PlaylistCloud {
    private const val BASE = BeiSongCloud.BASE
    private const val API_KEY = BeiSongCloud.API_KEY
    private const val PREFS = "besound_cloud_account"

    data class Session(val access: String, val refresh: String, val userId: String, val email: String)
    data class Playlist(val id: String, val name: String, val description: String, val coverPath: String?, val coverUrl: String?, val updatedAt: String)
    data class Track(val id: String, val playlistId: String, val title: String, val artist: String, val audioUrl: String, val coverUrl: String?)
    data class SharedPlaylist(val name: String, val description: String, val tracks: List<Track>)
    var sharedToken by mutableStateOf<String?>(null)

    fun handleShareIntent(intent: Intent?) {
        val data = intent?.data ?: return
        if (data.scheme == "besound" && data.host == "playlist" && data.path == "/share") {
            sharedToken = data.getQueryParameter("token")?.takeIf { it.length >= 32 }
        }
    }

    private fun call(path: String, method: String = "GET", token: String? = null, body: ByteArray? = null, contentType: String = "application/json", prefer: String? = null): String {
        val conn = (URL("$BASE$path").openConnection() as HttpURLConnection)
        conn.requestMethod = method
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.setRequestProperty("apikey", API_KEY)
        if (!token.isNullOrBlank()) conn.setRequestProperty("Authorization", "Bearer $token")
        if (prefer != null) conn.setRequestProperty("Prefer", prefer)
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", contentType)
            conn.outputStream.use { it.write(body) }
        }
        val status = conn.responseCode
        val stream = if (status in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
        conn.disconnect()
        if (status !in 200..299) {
            val message = runCatching { JSONObject(text).optString("message").ifBlank { JSONObject(text).optString("msg") } }.getOrDefault(text)
            error("Server $status: ${message.ifBlank { text }}")
        }
        return text
    }

    private fun saveSession(context: Context, session: Session) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("access", session.access).putString("refresh", session.refresh)
            .putString("uid", session.userId).putString("email", session.email).apply()
    }
    fun clearSession(context: Context) { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply() }
    fun cachedSession(context: Context): Session? {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val a = p.getString("access", null) ?: return null
        val r = p.getString("refresh", null) ?: return null
        val id = p.getString("uid", null) ?: return null
        return Session(a, r, id, p.getString("email", "") ?: "")
    }

    suspend fun signIn(context: Context, email: String, password: String): Session = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email.trim()).put("password", password).toString().toByteArray()
        val obj = JSONObject(call("/auth/v1/token?grant_type=password", "POST", body = body))
        val user = obj.getJSONObject("user")
        Session(obj.getString("access_token"), obj.getString("refresh_token"), user.getString("id"), user.optString("email", email)).also { saveSession(context, it) }
    }

    suspend fun signUp(context: Context, email: String, password: String): Boolean = withContext(Dispatchers.IO) {
        val body = JSONObject().put("email", email.trim()).put("password", password).toString().toByteArray()
        val obj = JSONObject(call("/auth/v1/signup", "POST", body = body))
        val access = obj.optString("access_token")
        if (access.isNotBlank()) {
            val user = obj.getJSONObject("user")
            saveSession(context, Session(access, obj.getString("refresh_token"), user.getString("id"), user.optString("email", email)))
            true
        } else false
    }

    suspend fun refreshSession(context: Context): Session? = withContext(Dispatchers.IO) {
        val old = cachedSession(context) ?: return@withContext null
        runCatching {
            val body = JSONObject().put("refresh_token", old.refresh).toString().toByteArray()
            val obj = JSONObject(call("/auth/v1/token?grant_type=refresh_token", "POST", body = body))
            val user = obj.getJSONObject("user")
            Session(obj.getString("access_token"), obj.getString("refresh_token"), user.getString("id"), user.optString("email", old.email)).also { saveSession(context, it) }
        }.getOrNull()
    }

    private suspend fun validSession(context: Context): Session {
        val current = cachedSession(context) ?: error("Login diperlukan untuk sinkronisasi playlist.")
        val checked = runCatching { withContext(Dispatchers.IO) { call("/auth/v1/user", token = current.access) } }.getOrNull()
        if (checked != null) return current
        return refreshSession(context) ?: run { clearSession(context); error("Sesi berakhir. Silakan login kembali.") }
    }

    suspend fun list(context: Context): List<Playlist> = withContext(Dispatchers.IO) {
        val s = validSession(context)
        val arr = JSONArray(call("/rest/v1/user_playlists?select=id,name,description,cover_path,updated_at&order=updated_at.desc", token = s.access))
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i); val path = o.optString("cover_path").takeIf { it.isNotBlank() && it != "null" }
            Playlist(o.getString("id"), o.getString("name"), o.optString("description"), path, path?.let { signedCover(s.access, it) }, o.optString("updated_at"))
        }
    }

    private fun signedCover(token: String, path: String): String? = runCatching {
        val encoded = path.split('/').joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8") }
        val body = JSONObject().put("expiresIn", 3600).toString().toByteArray()
        val o = JSONObject(call("/storage/v1/object/sign/playlist-covers/$encoded", "POST", token, body))
        val signed = o.optString("signedURL").ifBlank { o.optString("signedUrl") }
        if (signed.startsWith("http")) signed else if (signed.startsWith("/object/")) "$BASE/storage/v1$signed" else "$BASE$signed"
    }.getOrNull()

    suspend fun create(context: Context, name: String, description: String, cover: Uri?): Playlist = withContext(Dispatchers.IO) {
        val s = validSession(context)
        val path = cover?.let { uploadCover(context, s, it) }
        val row = JSONObject().put("owner_id", s.userId).put("name", name.trim()).put("description", description.trim())
        if (path != null) row.put("cover_path", path)
        val result = JSONArray(call("/rest/v1/user_playlists?select=id,name,description,cover_path,updated_at", "POST", s.access, row.toString().toByteArray(), prefer = "return=representation"))
        val o = result.getJSONObject(0)
        Playlist(o.getString("id"), o.getString("name"), o.optString("description"), o.optString("cover_path").takeIf { it.isNotBlank() }, path?.let { signedCover(s.access, it) }, o.optString("updated_at"))
    }

    suspend fun update(context: Context, playlist: Playlist, name: String, description: String, cover: Uri?): Playlist = withContext(Dispatchers.IO) {
        val s = validSession(context)
        val path = cover?.let { uploadCover(context, s, it) } ?: playlist.coverPath
        val row = JSONObject().put("name", name.trim()).put("description", description.trim()).put("cover_path", path ?: JSONObject.NULL)
        call("/rest/v1/user_playlists?id=eq.${playlist.id}", "PATCH", s.access, row.toString().toByteArray())
        Playlist(playlist.id, name.trim(), description.trim(), path, path?.let { signedCover(s.access, it) }, "")
    }

    private fun uploadCover(context: Context, session: Session, uri: Uri): String {
        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: error("Cover tidak dapat dibaca")
        require(bytes.size <= 5 * 1024 * 1024) { "Ukuran cover maksimal 5 MB." }
        val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
        require(mime in listOf("image/jpeg", "image/png", "image/webp")) { "Format cover harus JPG, PNG, atau WEBP." }
        val ext = when (mime) { "image/png" -> "png"; "image/webp" -> "webp"; else -> "jpg" }
        val path = "${session.userId}/${UUID.randomUUID()}.$ext"
        call("/storage/v1/object/playlist-covers/$path", "POST", session.access, bytes, mime)
        return path
    }

    suspend fun delete(context: Context, playlist: Playlist) = withContext(Dispatchers.IO) {
        val s = validSession(context)
        call("/rest/v1/user_playlists?id=eq.${playlist.id}", "DELETE", s.access)
        playlist.coverPath?.let { path -> runCatching { call("/storage/v1/object/playlist-covers/${path.split('/').joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8") }}", "DELETE", s.access) } }
    }

    suspend fun tracks(context: Context, playlistId: String): List<Track> = withContext(Dispatchers.IO) {
        val s = validSession(context)
        val arr = JSONArray(call("/rest/v1/user_playlist_tracks?select=id,playlist_id,title,artist,audio_url,cover_url&playlist_id=eq.$playlistId&order=position.asc,added_at.asc", token = s.access))
        (0 until arr.length()).map { i -> val o = arr.getJSONObject(i); Track(o.getString("id"), o.getString("playlist_id"), o.getString("title"), o.getString("artist"), o.getString("audio_url"), o.optString("cover_url").takeIf { it.isNotBlank() && it != "null" }) }
    }

    suspend fun addTrack(context: Context, playlistId: String, song: BeiSongCloud.Song) = withContext(Dispatchers.IO) {
        val s = validSession(context)
        val encodedUrl = java.net.URLEncoder.encode(song.audioUrl, "UTF-8")
        val existing = JSONArray(call("/rest/v1/user_playlist_tracks?select=id&playlist_id=eq.$playlistId&audio_url=eq.$encodedUrl", token = s.access))
        if (existing.length() > 0) return@withContext
        val row = JSONObject().put("playlist_id", playlistId).put("owner_id", s.userId).put("song_id", song.id)
            .put("title", song.title).put("artist", song.artist).put("audio_url", song.audioUrl)
        if (song.coverUrl != null) row.put("cover_url", song.coverUrl)
        call("/rest/v1/user_playlist_tracks", "POST", s.access, row.toString().toByteArray())
    }

    suspend fun removeTrack(context: Context, id: String) = withContext(Dispatchers.IO) {
        val s = validSession(context); call("/rest/v1/user_playlist_tracks?id=eq.$id", "DELETE", s.access)
    }

    suspend fun createShareLink(context: Context, playlist: Playlist): String = withContext(Dispatchers.IO) {
        val s = validSession(context)
        val bytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val token = Base64.encodeToString(bytes, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
        val hash = MessageDigest.getInstance("SHA-256").digest(token.toByteArray()).joinToString("") { "%02x".format(it) }
        val row = JSONObject().put("playlist_id", playlist.id).put("owner_id", s.userId).put("token_hash", hash)
        call("/rest/v1/playlist_shares", "POST", s.access, row.toString().toByteArray())
        "besound://playlist/share?token=$token"
    }

    suspend fun revokeShareLinks(context: Context, playlist: Playlist) = withContext(Dispatchers.IO) {
        val s = validSession(context)
        call("/rest/v1/playlist_shares?playlist_id=eq.${playlist.id}", "DELETE", s.access)
    }

    suspend fun getSharedPlaylist(token: String): SharedPlaylist? = withContext(Dispatchers.IO) {
        val body = JSONObject().put("p_token", token).toString().toByteArray()
        val result = call("/rest/v1/rpc/get_shared_playlist", "POST", body = body)
        if (result.isBlank() || result == "null") return@withContext null
        val root = JSONObject(result)
        val p = root.optJSONObject("playlist") ?: return@withContext null
        val arr = root.optJSONArray("tracks") ?: JSONArray()
        val items = (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Track("shared-$i", p.optString("id"), o.optString("title"), o.optString("artist"), o.optString("audio_url"), o.optString("cover_url").takeIf { it.isNotBlank() && it != "null" })
        }
        SharedPlaylist(p.optString("name"), p.optString("description"), items)
    }
}

@Composable
internal fun PlaylistCloudScreen(onPlay: (List<PlaylistCloud.Track>, Int) -> Unit, onRequestLogin: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var session by remember { mutableStateOf(PlaylistCloud.cachedSession(context)) }
    var playlists by remember { mutableStateOf<List<PlaylistCloud.Playlist>>(emptyList()) }
    var selected by remember { mutableStateOf<PlaylistCloud.Playlist?>(null) }
    var sharedPlaylist by remember { mutableStateOf<PlaylistCloud.SharedPlaylist?>(null) }
    var tracks by remember { mutableStateOf<List<PlaylistCloud.Track>>(emptyList()) }
    var cloudSongs by remember { mutableStateOf<List<BeiSongCloud.Song>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var signupMode by remember { mutableStateOf(false) }
    var showCreate by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<PlaylistCloud.Playlist?>(null) }
    var name by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var cover by remember { mutableStateOf<Uri?>(null) }
    var showAddSongs by remember { mutableStateOf(false) }
    var menuFor by remember { mutableStateOf<String?>(null) }
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { cover = it }

    fun refresh() {
        scope.launch {
            loading = true
            try { session = PlaylistCloud.cachedSession(context); playlists = PlaylistCloud.list(context); message = "" }
            catch (e: Exception) { message = e.message ?: "Gagal memuat playlist" }
            loading = false
        }
    }
    LaunchedEffect(Unit) { if (session != null) refresh() }
    LaunchedEffect(PlaylistCloud.sharedToken) {
        val token = PlaylistCloud.sharedToken ?: return@LaunchedEffect
        loading = true
        try { sharedPlaylist = PlaylistCloud.getSharedPlaylist(token); message = if (sharedPlaylist == null) "Link playlist tidak valid atau sudah dicabut." else "" }
        catch (e: Exception) { message = e.message ?: "Gagal membuka playlist bersama" }
        loading = false
    }
    LaunchedEffect(selected?.id) {
        val item = selected ?: return@LaunchedEffect
        loading = true
        try { tracks = PlaylistCloud.tracks(context, item.id); cloudSongs = BeiSongCloud.list(); message = "" }
        catch (e: Exception) { message = e.message ?: "Gagal memuat lagu" }
        loading = false
    }

    Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()).padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text("PLAYLIST", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(if (selected == null) "Your playlists" else selected!!.name, color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (selected != null) IconButton(onClick = { selected = null }) { Icon(Icons.Default.ArrowBack, "Kembali", tint = Ink) }
            else if (session != null) IconButton(onClick = { showCreate = true; editing = null; name = ""; description = ""; cover = null }) { Icon(Icons.Default.Add, "Buat playlist", tint = Orange) }
        }
        Spacer(Modifier.height(8.dp))
        if (PlaylistCloud.sharedToken != null) {
            val shared = sharedPlaylist
            if (shared != null) {
                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Share, null, tint = Golden, modifier = Modifier.size(32.dp))
                        Text(shared.name, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Playlist dibagikan melalui link", color = Muted, fontSize = 12.sp)
                    }
                }
                shared.tracks.forEach { t ->
                    Row(Modifier.fillMaxWidth().clickable { onPlay(shared.tracks, shared.tracks.indexOf(t)) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        PlaylistCover(t.coverUrl, Modifier.size(46.dp).clip(RoundedCornerShape(8.dp)))
                        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(t.title, color = Ink, fontWeight = FontWeight.SemiBold); Text(t.artist, color = Muted, fontSize = 11.sp) }
                        Icon(Icons.Default.PlayArrow, null, tint = Orange)
                    }
                }
                TextButton(onClick = { PlaylistCloud.sharedToken = null; sharedPlaylist = null }) { Text("Kembali ke Playlist", color = Orange) }
            } else if (loading) Text("Membuka playlist bersama...", color = Muted)
        } else if (session == null) {
            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.Lock, null, tint = Golden, modifier = Modifier.size(30.dp))
                    Text("Playlist tersinkron per akun", color = Ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Login atau buat akun melalui halaman Profile. Setelah login, kembali ke sini untuk membuat playlist privat yang bisa dibuka di HP lain.", color = Muted, fontSize = 13.sp)
                    Button(onClick = onRequestLogin, modifier = Modifier.fillMaxWidth()) { Text("Buka Profile untuk Login") }
                }
            }
        } else if (selected == null) {
            Text("Akun: ${session?.email}", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.height(104.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).padding(start = 14.dp, top = 10.dp, bottom = 10.dp)) {
                        Text("Create your Daily Mix", color = Ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Kumpulkan lagu favoritmu dalam satu playlist.", color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                    }
                    Image(painterResource(R.drawable.bei_song_mask), contentDescription = "Be.i Daily Mix", modifier = Modifier.width(112.dp).fillMaxHeight().clip(RoundedCornerShape(topEnd = 18.dp, bottomEnd = 18.dp)), contentScale = ContentScale.Crop)
                }
            }
            Spacer(Modifier.height(12.dp))
            if (playlists.isEmpty() && !loading) Text("Belum ada playlist. Buat koleksi pertamamu!", color = Muted, fontSize = 13.sp)
            playlists.chunked(2).forEach { rowItems ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    rowItems.forEach { p ->
                        Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(16.dp), modifier = Modifier.weight(1f)) {
                            Column {
                                Box(Modifier.fillMaxWidth().height(132.dp).clickable { selected = p }, contentAlignment = Alignment.Center) {
                                    PlaylistCover(p.coverUrl, Modifier.fillMaxSize())
                                    IconButton(onClick = { menuFor = p.id }, modifier = Modifier.align(Alignment.TopEnd)) { Icon(Icons.Default.MoreVert, "Menu playlist", tint = Cream) }
                                    DropdownMenu(expanded = menuFor == p.id, onDismissRequest = { menuFor = null }, modifier = Modifier.background(CreamCard)) {
                                        DropdownMenuItem(text = { Text("Edit", color = Ink) }, onClick = { menuFor = null; editing = p; name = p.name; description = p.description; cover = null; showCreate = true })
                                        DropdownMenuItem(text = { Text("Bagikan link", color = Ink) }, onClick = {
                                            menuFor = null
                                            scope.launch { runCatching {
                                                val link = PlaylistCloud.createShareLink(context, p)
                                                val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Dengarkan playlist ${p.name} di BESOUND: $link") }
                                                context.startActivity(Intent.createChooser(send, "Bagikan playlist"))
                                            }.onFailure { message = it.message ?: "Gagal membuat link" } }
                                        })
                                        DropdownMenuItem(text = { Text("Cabut semua link", color = Ink) }, onClick = {
                                            menuFor = null
                                            scope.launch { runCatching { PlaylistCloud.revokeShareLinks(context, p); message = "Semua link berbagi sudah dicabut." }.onFailure { message = it.message ?: "Gagal mencabut link" } }
                                        })
                                        DropdownMenuItem(text = { Text("Hapus", color = androidx.compose.ui.graphics.Color(0xFFFF7777)) }, onClick = { menuFor = null; scope.launch { runCatching { PlaylistCloud.delete(context, p); refresh() }.onFailure { message = it.message ?: "Gagal menghapus" } } })
                                    }
                                }
                                Column(Modifier.fillMaxWidth().clickable { selected = p }.padding(10.dp)) {
                                    Text(p.name, color = Ink, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(p.description.ifBlank { "Playlist privat" }, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                    if (rowItems.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        } else {
            val p = selected!!
            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    PlaylistCover(p.coverUrl, Modifier.size(150.dp).clip(RoundedCornerShape(16.dp)))
                    Spacer(Modifier.height(8.dp)); Text(p.name, color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text(p.description.ifBlank { "Playlist privat" }, color = Muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { if (tracks.isNotEmpty()) onPlay(tracks, 0) }, enabled = tracks.isNotEmpty()) { Icon(Icons.Default.PlayArrow, null); Text("Putar") }
                        OutlinedButton(onClick = { showAddSongs = true }) { Icon(Icons.Default.Add, null); Text("Tambah lagu") }
                        IconButton(onClick = { editing = p; name = p.name; description = p.description; cover = null; showCreate = true }) { Icon(Icons.Default.Edit, "Edit", tint = Orange) }
                        IconButton(onClick = {
                            scope.launch {
                                runCatching {
                                    val link = PlaylistCloud.createShareLink(context, p)
                                    val send = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Dengarkan playlist ${p.name} di BESOUND: $link") }
                                    context.startActivity(Intent.createChooser(send, "Bagikan playlist"))
                                }.onFailure { message = it.message ?: "Gagal membuat link" }
                            }
                        }) { Icon(Icons.Default.Share, "Bagikan link", tint = Orange) }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            tracks.forEach { t ->
                Row(Modifier.fillMaxWidth().clickable { onPlay(tracks, tracks.indexOf(t)) }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    PlaylistCover(t.coverUrl, Modifier.size(48.dp).clip(RoundedCornerShape(9.dp)))
                    Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text(t.title, color = Ink, fontWeight = FontWeight.SemiBold, maxLines = 1); Text(t.artist, color = Muted, fontSize = 11.sp) }
                    IconButton(onClick = { scope.launch { runCatching { PlaylistCloud.removeTrack(context, t.id); tracks = PlaylistCloud.tracks(context, p.id) }.onFailure { message = it.message ?: "Gagal menghapus lagu" } } }) { Icon(Icons.Default.Delete, "Hapus dari playlist", tint = Muted) }
                }
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth(), color = Orange)
        if (message.isNotBlank()) Text(message, color = Golden, fontSize = 11.sp, modifier = Modifier.padding(vertical = 4.dp))
    }

    if (showCreate) AlertDialog(
        onDismissRequest = { showCreate = false }, containerColor = CreamCard,
        title = { Text(if (editing == null) "Buat Playlist" else "Edit Playlist", color = Ink) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(12.dp)).background(Brush.linearGradient(listOf(Orange, Golden))).clickable { coverPicker.launch(arrayOf("image/jpeg", "image/png", "image/webp")) }, contentAlignment = Alignment.Center) {
                    if (cover != null) Text("Cover dipilih", color = Cream) else Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.ImageIcon, null, tint = Cream); Text("Pilih cover dari galeri", color = Cream, fontSize = 12.sp) }
                }
                OutlinedTextField(name, { name = it }, label = { Text("Nama playlist") }, singleLine = true)
                OutlinedTextField(description, { description = it }, label = { Text("Deskripsi (opsional)") }, minLines = 2)
                Row(verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Lock, null, tint = Golden); Spacer(Modifier.width(6.dp)); Text("Privat • hanya terlihat oleh akunmu", color = Muted, fontSize = 11.sp) }
            }
        },
        confirmButton = { TextButton(onClick = {
            scope.launch {
                loading = true
                try {
                    require(name.isNotBlank()) { "Nama playlist wajib diisi." }
                    if (editing == null) PlaylistCloud.create(context, name, description, cover)
                    else {
                        val updated = PlaylistCloud.update(context, editing!!, name, description, cover)
                        if (selected?.id == updated.id) selected = updated
                    }
                    showCreate = false; refresh()
                } catch (e: Exception) { message = e.message ?: "Gagal menyimpan playlist" }
                loading = false
            }
        }, enabled = name.isNotBlank() && !loading) { Text("Simpan", color = Orange) } },
        dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Batal", color = Muted) } }
    )

    if (showAddSongs && selected != null) AlertDialog(
        onDismissRequest = { showAddSongs = false }, containerColor = CreamCard,
        title = { Text("Tambah lagu BEI SONG", color = Ink) },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(androidx.compose.foundation.rememberScrollState())) {
                val availableSongs = cloudSongs.filterNot { song -> tracks.any { it.audioUrl == song.audioUrl } }
                if (availableSongs.isEmpty()) Text("Semua lagu yang tersedia sudah ada di playlist ini.", color = Muted)
                availableSongs.forEach { song ->
                    Row(Modifier.fillMaxWidth().clickable {
                        scope.launch { runCatching { PlaylistCloud.addTrack(context, selected!!.id, song); tracks = PlaylistCloud.tracks(context, selected!!.id); message = "Lagu ditambahkan." }.onFailure { message = it.message ?: "Gagal menambahkan lagu" } }
                    }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(song.title, color = Ink, fontWeight = FontWeight.SemiBold); Text(song.artist, color = Muted, fontSize = 11.sp) }
                        Icon(Icons.Default.Add, null, tint = Orange)
                    }
                }
            }
        }, confirmButton = { TextButton(onClick = { showAddSongs = false }) { Text("Selesai", color = Orange) } }
    )
}

@Composable
private fun PlaylistCover(url: String?, modifier: Modifier = Modifier) {
    val bitmap by produceState<Bitmap?>(null, url) {
        value = null
        if (!url.isNullOrBlank()) value = withContext(Dispatchers.IO) { runCatching { URL(url).openConnection().getInputStream().use { BitmapFactory.decodeStream(it) } }.getOrNull() }
    }
    Box(modifier.background(Brush.linearGradient(listOf(CreamCard, Golden.copy(alpha = .65f)))), contentAlignment = Alignment.Center) {
        if (bitmap != null) Image(bitmap!!.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Icon(Icons.Default.MusicNote, null, tint = Ink, modifier = Modifier.size(34.dp))
    }
}
