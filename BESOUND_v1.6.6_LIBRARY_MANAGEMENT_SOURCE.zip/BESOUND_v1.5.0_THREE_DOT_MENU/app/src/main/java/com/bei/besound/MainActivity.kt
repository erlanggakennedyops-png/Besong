package com.bei.besound

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.Context
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.media.MediaMetadataRetriever
import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer
import android.media.audiofx.LoudnessEnhancer
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import java.io.File
import java.util.UUID
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContract
import androidx.core.content.ContextCompat
import androidx.media3.ui.PlayerNotificationManager
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.support.v4.media.MediaMetadataCompat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.*
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

var Cream by mutableStateOf(Color(0xFF17120F))
var CreamCard by mutableStateOf(Color(0xFF2A1C16))
var Orange by mutableStateOf(Color(0xFFFF8A32))
var Golden by mutableStateOf(Color(0xFFFFC15A))
var Ink by mutableStateOf(Color(0xFFFFE8CE))
var Muted by mutableStateOf(Color(0xFFB99B80))
private var NavSurface by mutableStateOf(Color(0xFF211711))
private var DividerTone by mutableStateOf(Color(0xFF493123))

private fun applyPalette(name: String) {
    when (name) {
        "Cream Light" -> {
            Cream = Color(0xFFFFF8ED); CreamCard = Color(0xFFFFE8CC)
            Orange = Color(0xFFE58B3A); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFF33291F); Muted = Color(0xFF8B7866)
            NavSurface = Color(0xFFFFF1DE); DividerTone = Color(0xFFEFE2D2)
        }
        "Midnight" -> {
            Cream = Color(0xFF10131B); CreamCard = Color(0xFF202633)
            Orange = Color(0xFFFF8B45); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFFF5F0E9); Muted = Color(0xFFA6A9B4)
            NavSurface = Color(0xFF191E29); DividerTone = Color(0xFF343B49)
        }
        else -> {
            Cream = Color(0xFF17120F); CreamCard = Color(0xFF2A1C16)
            Orange = Color(0xFFFF8A32); Golden = Color(0xFFFFC15A)
            Ink = Color(0xFFFFE8CE); Muted = Color(0xFFB99B80)
            NavSurface = Color(0xFF211711); DividerTone = Color(0xFF493123)
        }
    }
}



/**
 * Opens audio documents with read + write grants so BESOUND can update ID3 tags
 * (including embedded album artwork) in the selected MP3 file.
 */
private class OpenMultipleAudioDocuments : ActivityResultContract<Array<String>, List<Uri>>() {
    override fun createIntent(context: Context, input: Array<String>): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = input.firstOrNull() ?: "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
    }

    override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
        if (resultCode != android.app.Activity.RESULT_OK || intent == null) return emptyList()
        val result = mutableListOf<Uri>()
        intent.clipData?.let { clip ->
            for (index in 0 until clip.itemCount) {
                clip.getItemAt(index).uri?.let(result::add)
            }
        }
        intent.data?.let { if (it !in result) result.add(it) }
        return result.distinct()
    }
}

@OptIn(UnstableApi::class, ExperimentalFoundationApi::class)
class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSessionCompat
    private lateinit var notificationManager: PlayerNotificationManager
    private val notificationChannelId = "besound_playback"
    private val notificationId = 4101
    // Cache artwork by its private persisted URI. Never decode a full cover on every UI tick.
    private var cachedArtworkUri: String? = null
    private var cachedArtworkBitmap: android.graphics.Bitmap? = null
    // Cache artwork embedded in the active MP3 for Android media surfaces.
    private var cachedEmbeddedArtworkKey: String? = null
    private var cachedEmbeddedArtworkBitmap: android.graphics.Bitmap? = null
    // Room is the source of truth for covers selected in the in-app editor.
    // A known track with a null cover must use the BESOUND fallback, not stale player metadata.
    @Volatile private var trackArtworkUris: Map<String, String?> = emptyMap()
    private var lastCompatMetadataKey: String? = null

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        BeiSongCloud.handleRecoveryIntent(intent)
        PlaylistCloud.handleShareIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BeiSongCloud.handleRecoveryIntent(intent)
        PlaylistCloud.handleShareIntent(intent)

        val audiusDataSourceFactory = createAudiusDataSourceFactory(BuildConfig.AUDIUS_API_KEY)
        player = ExoPlayer.Builder(this)
            .setMediaSourceFactory(DefaultMediaSourceFactory(audiusDataSourceFactory))
            .build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
        }

        createPlaybackNotificationChannel()
        mediaSession = MediaSessionCompat(this, "BESOUND").apply {
            setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                    MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
            )
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { player.play() }
                override fun onPause() { player.pause() }
                override fun onSkipToNext() { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }
                override fun onSkipToPrevious() { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() }
                override fun onSeekTo(pos: Long) { player.seekTo(pos) }
                override fun onStop() { player.pause(); player.seekTo(0L) }
            })
            isActive = true
        }
        notificationManager = PlayerNotificationManager.Builder(
            this, notificationId, notificationChannelId
        )
            .setMediaDescriptionAdapter(object : PlayerNotificationManager.MediaDescriptionAdapter {
                override fun getCurrentContentTitle(player: Player): CharSequence {
                    return player.mediaMetadata.title ?: "BESOUND"
                }
                override fun createCurrentContentIntent(player: Player): PendingIntent? {
                    val intent = Intent(this@MainActivity, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    return PendingIntent.getActivity(
                        this@MainActivity, 0, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                }
                override fun getCurrentContentText(player: Player): CharSequence? {
                    return player.mediaMetadata.artist
                }
                override fun getCurrentLargeIcon(
                    player: Player,
                    callback: PlayerNotificationManager.BitmapCallback
                ): android.graphics.Bitmap? {
                    // Use each track's selected cover when available. If a track has
                    // no cover (or its file cannot be decoded), use BESOUND artwork.
                    return loadEmbeddedArtworkBitmap(player)
                        ?: resolveCurrentArtworkUri(player)?.let { loadArtworkBitmapCached(it) }
                        ?: loadDefaultArtworkBitmap()
                }
            })
            .setNotificationListener(object : PlayerNotificationManager.NotificationListener {})
            .build()
            .apply {
                setMediaSessionToken(mediaSession.sessionToken)
                setUseNextAction(true)
                setUsePreviousAction(true)
                setUsePlayPauseActions(true)
                setPlayer(player)
            }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4102)
        }

        val dao = MusicDatabase.get(this).songDao()

        setContent {
            val scope = rememberCoroutineScope()
            val songs by dao.observeAll().collectAsState(initial = emptyList())
            var activeAudioSessionId by remember { mutableIntStateOf(player.audioSessionId) }
            val audioEffects = remember(activeAudioSessionId) {
                if (activeAudioSessionId > 0) runCatching { BesoundAudioEffects(activeAudioSessionId) }.getOrNull() else null
            }
            DisposableEffect(audioEffects) { onDispose { audioEffects?.release() } }

            var currentUri by remember { mutableStateOf<String?>(null) }
            var externalSong by remember { mutableStateOf<SongEntity?>(null) }
            var isPlaying by remember { mutableStateOf(false) }
            var positionMs by remember { mutableLongStateOf(0L) }
            var durationMs by remember { mutableLongStateOf(0L) }
            var shuffleEnabled by remember { mutableStateOf(false) }
            var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
            var selectedTab by remember { mutableIntStateOf(if (BeiSongCloud.recoveryToken != null) 1 else if (PlaylistCloud.sharedToken != null) 6 else 0) }
            LaunchedEffect(BeiSongCloud.recoveryToken) {
                if (BeiSongCloud.recoveryToken != null) selectedTab = 1
            }
            LaunchedEffect(PlaylistCloud.sharedToken) {
                if (PlaylistCloud.sharedToken != null) selectedTab = 6
            }
            var previousTab by remember { mutableIntStateOf(0) }
            var showExitDialog by remember { mutableStateOf(false) }
            var searchText by remember { mutableStateOf("") }
            var searchCategory by remember { mutableStateOf("All Song") }
            var globalSearchQuery by remember { mutableStateOf("") }
            var globalSearchResults by remember { mutableStateOf<List<SongEntity>>(emptyList()) }
            var globalSearchLoading by remember { mutableStateOf(false) }
            var globalSearchError by remember { mutableStateOf("") }
            var librarySelectionMode by remember { mutableStateOf(false) }
            var selectedLibraryUris by remember { mutableStateOf<Set<String>>(emptySet()) }
            var bulkDeletingSongs by remember { mutableStateOf<List<SongEntity>>(emptyList()) }
            var downloadedFiles by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
            var downloadingUri by remember { mutableStateOf<String?>(null) }
            var showLyrics by remember { mutableStateOf(false) }
            var showEditor by remember { mutableStateOf(false) }
            var editingSong by remember { mutableStateOf<SongEntity?>(null) }
            var editTitle by remember { mutableStateOf("") }
            var editArtist by remember { mutableStateOf("") }
            var editAlbum by remember { mutableStateOf("") }
            var editMoods by remember { mutableStateOf("") }
            var editLyrics by remember { mutableStateOf("") }
            var editCoverUri by remember { mutableStateOf<String?>(null) }
            var deletingSong by remember { mutableStateOf<SongEntity?>(null) }
            var themeName by remember { mutableStateOf(getPreferences(MODE_PRIVATE).getString("besound_theme", "Golden Dusk") ?: "Golden Dusk") }
            var showThemeMenu by remember { mutableStateOf(false) }
            var showNowOptions by remember { mutableStateOf(false) }
            SideEffect { applyPalette(themeName) }
            LaunchedEffect(themeName) { getPreferences(MODE_PRIVATE).edit().putString("besound_theme", themeName).apply() }

            val currentSong = songs.firstOrNull { it.uri == currentUri } ?: externalSong?.takeIf { it.uri == currentUri }
            var recentPlayedUris by remember {
                mutableStateOf(
                    getSharedPreferences("besound_recently_played", MODE_PRIVATE)
                        .getString("uris", "")
                        .orEmpty()
                        .split("\n")
                        .filter { it.isNotBlank() }
                        .take(10)
                )
            }

            fun recordRecentlyPlayed(uri: String) {
                val updated = (listOf(uri) + recentPlayedUris.filterNot { it == uri }).take(10)
                recentPlayedUris = updated
                getSharedPreferences("besound_recently_played", MODE_PRIVATE)
                    .edit().putString("uris", updated.joinToString("\n")).apply()
            }

            val recentSongs = recentPlayedUris.mapNotNull { uri -> songs.firstOrNull { it.uri == uri } }
            var favoriteUris by remember {
                mutableStateOf(
                    getSharedPreferences("besound_favorites", MODE_PRIVATE)
                        .getStringSet("uris", emptySet())?.toSet() ?: emptySet()
                )
            }
            val favoriteSongs = remember(songs, favoriteUris) { songs.filter { it.uri in favoriteUris } }
            val newestSongs = remember(songs) { songs.sortedByDescending { it.addedAt } }
            var homeFeedMode by remember { mutableStateOf("new") }
            var selectedMood by remember { mutableStateOf("Semua") }
            var showQueueDialog by remember { mutableStateOf(false) }
            var playCounts by remember {
                mutableStateOf(
                    getSharedPreferences("besound_play_counts", MODE_PRIVATE).all
                        .filterKeys { it.startsWith("plays:") }
                        .mapNotNull { (key, value) -> (value as? Int)?.let { key.removePrefix("plays:") to it } }
                        .toMap()
                )
            }
            val trendingSongs = remember(recentSongs, songs, playCounts, newestSongs) {
                if (playCounts.values.any { it > 0 }) songs.sortedByDescending { playCounts[it.uri] ?: 0 }.take(12)
                else (recentSongs + newestSongs.filterNot { song -> recentSongs.any { it.uri == song.uri } }).take(12)
            }
            val moodSongs = remember(songs, selectedMood) {
                if (selectedMood == "Semua") songs
                else songs.filter { song -> song.moods.split(",").any { it.trim().equals(selectedMood, ignoreCase = true) } }
            }

            fun recordPlayCount(uri: String) {
                if (songs.none { it.uri == uri }) return
                val next = (playCounts[uri] ?: 0) + 1
                playCounts = playCounts + (uri to next)
                getSharedPreferences("besound_play_counts", MODE_PRIVATE).edit().putInt("plays:$uri", next).apply()
            }

            fun toggleFavorite(song: SongEntity) {
                val updated = favoriteUris.toMutableSet().apply {
                    if (song.uri in this) remove(song.uri) else add(song.uri)
                }
                favoriteUris = updated
                getSharedPreferences("besound_favorites", MODE_PRIVATE).edit().putStringSet("uris", updated).apply()
            }

            // Public offline copies are indexed in shared Internal Storage/Music/BESOUND. Room stays unchanged.
            LaunchedEffect(songs) {
                val prefs = getSharedPreferences("besound_offline", MODE_PRIVATE)
                val restored = prefs.all.mapNotNull { (key, value) ->
                    val originalUri = key.removePrefix("offline:")
                    val savedLocation = value as? String
                    val exists = if (savedLocation.isNullOrBlank()) false else runCatching {
                        val savedUri = Uri.parse(savedLocation)
                        if (savedUri.scheme == "content") contentResolver.query(savedUri, arrayOf(MediaStore.Audio.Media._ID), null, null, null)?.use { it.moveToFirst() } == true
                        else File(savedLocation).exists()
                    }.getOrDefault(false)
                    if (key.startsWith("offline:") && exists) originalUri to savedLocation!! else null
                }.toMap()
                downloadedFiles = restored
                prefs.edit().apply {
                    prefs.all.keys.filter { it.startsWith("offline:") && it.removePrefix("offline:") !in restored.keys }.forEach { remove(it) }
                }.apply()
            }

            // Keep notification/lock-screen artwork in sync with the cover saved in Room.
            // This also handles covers selected from the editor after playback has started.
            LaunchedEffect(songs) {
                trackArtworkUris = songs.associate { it.uri to it.coverUri }
                cachedArtworkUri = null
                cachedArtworkBitmap = null
                updateCompatMediaSession(forceMetadata = true)
                if (::notificationManager.isInitialized) notificationManager.invalidate()
            }

            // Repair legacy placeholder titles such as "msf:114295" using the actual file name.
            LaunchedEffect(songs) {
                songs.filter {
                    it.title.isBlank() || it.title.startsWith("msf:", ignoreCase = true) ||
                        it.title.equals("Untitled", ignoreCase = true)
                }.forEach { song ->
                    val recoveredTitle = displayNameFor(Uri.parse(song.uri))
                    if (recoveredTitle.isNotBlank() && recoveredTitle != song.title) {
                        dao.upsert(song.copy(title = recoveredTitle))
                    }
                }
            }

            LaunchedEffect(songs) {
                val validUris = songs.map { it.uri }.toSet()
                selectedLibraryUris = selectedLibraryUris.intersect(validUris)
                if (songs.isEmpty()) librarySelectionMode = false
            }

            val filteredSongs = remember(songs, searchText) {
                if (searchText.isBlank()) songs
                else songs.filter {
                    it.title.contains(searchText, true) ||
                        it.artist.contains(searchText, true) ||
                        it.album.contains(searchText, true)
                }
            }

            fun saveSongOffline(song: SongEntity) {
                if (downloadedFiles.containsKey(song.uri) || downloadingUri == song.uri) return
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 5201)
                    android.widget.Toast.makeText(this@MainActivity, "Izinkan akses penyimpanan, lalu tekan Download lagi.", android.widget.Toast.LENGTH_LONG).show()
                    return
                }
                downloadingUri = song.uri
                scope.launch {
                    val result = runCatching {
                        withContext(Dispatchers.IO) {
                            val sourceUri = Uri.parse(song.uri)
                            val sourceName = displayNameFor(sourceUri).ifBlank { song.title }
                            val extension = sourceName.substringAfterLast('.', "mp3").lowercase().let { if (it.matches(Regex("[a-z0-9]{2,5}"))) it else "mp3" }
                            val safeName = song.title.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_').take(64).ifBlank { "BESOUND_Track" }
                            val displayName = "${safeName}.${extension}"
                            val input = if (sourceUri.scheme == "file") File(requireNotNull(sourceUri.path)).inputStream()
                                else contentResolver.openInputStream(sourceUri) ?: error("File sumber tidak bisa dibaca")
                            input.use { source ->
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                    val values = ContentValues().apply {
                                        put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
                                        put(MediaStore.Audio.Media.MIME_TYPE, when (extension) { "m4a" -> "audio/mp4"; "wav" -> "audio/wav"; "flac" -> "audio/flac"; "ogg" -> "audio/ogg"; else -> "audio/mpeg" })
                                        put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/BESOUND")
                                        put(MediaStore.Audio.Media.IS_PENDING, 1)
                                    }
                                    val destination = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                                        ?: error("Tidak bisa membuat file di Music/BESOUND")
                                    try {
                                        contentResolver.openOutputStream(destination, "w")?.use { output -> source.copyTo(output) }
                                            ?: error("Tidak bisa menulis file unduhan")
                                        val ready = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                                        contentResolver.update(destination, ready, null, null)
                                        destination.toString()
                                    } catch (e: Exception) {
                                        contentResolver.delete(destination, null, null)
                                        throw e
                                    }
                                } else {
                                    val musicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "BESOUND")
                                    if (!musicDir.exists() && !musicDir.mkdirs()) error("Folder Music/BESOUND tidak bisa dibuat")
                                    val destination = File(musicDir, displayName)
                                    source.use { inputStream -> destination.outputStream().use { output -> inputStream.copyTo(output) } }
                                    destination.absolutePath
                                }
                            }
                        }
                    }
                    result.onSuccess { savedLocation ->
                        getSharedPreferences("besound_offline", MODE_PRIVATE).edit().putString("offline:${song.uri}", savedLocation).apply()
                        downloadedFiles = downloadedFiles + (song.uri to savedLocation)
                        android.widget.Toast.makeText(this@MainActivity, "Tersimpan di Music/BESOUND", android.widget.Toast.LENGTH_SHORT).show()
                    }.onFailure { error ->
                        android.widget.Toast.makeText(this@MainActivity, "Download gagal: ${error.message ?: "file tidak dapat disimpan"}", android.widget.Toast.LENGTH_LONG).show()
                    }
                    downloadingUri = null
                }
            }

            fun removeOfflineCopy(song: SongEntity, showToast: Boolean = true) {
                downloadedFiles[song.uri]?.let { savedLocation ->
                    runCatching {
                        val savedUri = Uri.parse(savedLocation)
                        if (savedUri.scheme == "content") contentResolver.delete(savedUri, null, null)
                        else File(savedLocation).delete()
                    }
                }
                getSharedPreferences("besound_offline", MODE_PRIVATE).edit().remove("offline:${song.uri}").apply()
                downloadedFiles = downloadedFiles - song.uri
                if (showToast) {
                    android.widget.Toast.makeText(this@MainActivity, "Unduhan ${song.title} dihapus. Lagu asli tetap aman.", android.widget.Toast.LENGTH_SHORT).show()
                }
            }

            fun removeSongsFromLibrary(targets: List<SongEntity>) {
                val uniqueTargets = targets.distinctBy { it.uri }
                if (uniqueTargets.isEmpty()) return
                val targetUris = uniqueTargets.map { it.uri }.toSet()

                if (currentUri?.let { it in targetUris } == true) {
                    player.stop()
                    player.clearMediaItems()
                    currentUri = null
                    externalSong = null
                    isPlaying = false
                    positionMs = 0L
                    durationMs = 0L
                } else {
                    val queueIndexes = (0 until player.mediaItemCount)
                        .filter { player.getMediaItemAt(it).mediaId in targetUris }
                        .sortedDescending()
                    queueIndexes.forEach { index -> player.removeMediaItem(index) }
                }

                uniqueTargets.forEach { removeOfflineCopy(it, showToast = false) }
                scope.launch { uniqueTargets.forEach { dao.delete(it.uri) } }
                selectedLibraryUris = emptySet()
                librarySelectionMode = false
                android.widget.Toast.makeText(
                    this@MainActivity,
                    if (uniqueTargets.size == 1) "Lagu dihapus dari Library" else "${uniqueTargets.size} lagu dihapus dari Library",
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }

            val coverPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    // Copy the selected image into BESOUND's private storage.
                    // The cover then survives deletion/moving of the original gallery file.
                    editCoverUri = persistArtwork(uri)?.toString()
                    if (editCoverUri == null) {
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "Cover gagal disimpan. Coba pilih foto lain.",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }

            val audioPicker = rememberLauncherForActivityResult(
                OpenMultipleAudioDocuments()
            ) { uris ->
                uris.forEach { uri ->
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                    }.onFailure {
                        // Some document providers grant read access only. Playback remains
                        // available, but embedded-tag editing will report a clear write error.
                        runCatching {
                            contentResolver.takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        }
                    }
                    val metadata = readMetadata(uri)
                    val fallbackTitle = displayNameFor(uri)
                    scope.launch {
                        // Re-selecting an already imported MP3 can refresh its persisted
                        // read/write document grant. Keep its lyrics and selected cover intact.
                        val existing = dao.getByUri(uri.toString())
                        if (existing != null) {
                            dao.upsert(existing)
                        } else {
                            dao.upsert(
                                SongEntity(
                                    uri = uri.toString(),
                                    title = metadata.first.ifBlank { fallbackTitle },
                                    artist = metadata.second.ifBlank { "Unknown artist" },
                                    album = metadata.third.ifBlank { "Unknown album" }
                                )
                            )
                        }
                    }
                }
            }

            fun playSong(song: SongEntity, openPlayer: Boolean = true) {
                val index = songs.indexOfFirst { it.uri == song.uri }
                currentUri = song.uri
                if (index >= 0) {
                    externalSong = null
                    recordRecentlyPlayed(song.uri)
                    player.setMediaItems(songs.map { item ->
                        MediaItem.Builder()
                            .setMediaId(item.uri)
                            .setUri(downloadedFiles[item.uri]?.let { Uri.parse(it) } ?: Uri.parse(item.uri))
                            .setMediaMetadata(
                                androidx.media3.common.MediaMetadata.Builder()
                                    .setTitle(item.title)
                                    .setArtist(item.artist)
                                    .setAlbumTitle(item.album)
                                    .apply { item.coverUri?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) } }
                                    .build()
                            ).build()
                    }, index, 0L)
                } else {
                    externalSong = song
                    player.setMediaItem(
                        MediaItem.Builder().setMediaId(song.uri).setUri(Uri.parse(song.uri))
                            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                                .setTitle(song.title).setArtist(song.artist).setAlbumTitle(song.album)
                                .apply { song.coverUri?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) } }
                                .build()).build()
                    )
                }
                player.prepare()
                player.play()
                isPlaying = true
                if (openPlayer) { previousTab = selectedTab; selectedTab = 5 }
            }

            fun playSongQueue(queue: List<SongEntity>, startIndex: Int = 0) {
                if (queue.isEmpty()) return
                val safeIndex = startIndex.coerceIn(0, queue.lastIndex)
                val mediaItems = queue.map { item ->
                    MediaItem.Builder()
                        .setMediaId(item.uri)
                        .setUri(downloadedFiles[item.uri]?.let { Uri.parse(it) } ?: Uri.parse(item.uri))
                        .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                            .setTitle(item.title)
                            .setArtist(item.artist)
                            .setAlbumTitle(item.album)
                            .apply { item.coverUri?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) } }
                            .build())
                        .build()
                }
                val selected = queue[safeIndex]
                currentUri = selected.uri
                externalSong = selected.takeIf { queued -> songs.none { it.uri == queued.uri } }
                recordRecentlyPlayed(selected.uri)
                player.setMediaItems(mediaItems, safeIndex, 0L)
                player.prepare()
                player.play()
                isPlaying = true
                previousTab = selectedTab
                selectedTab = 5
            }

            fun playPlaylistQueue(queue: List<PlaylistCloud.Track>, startIndex: Int) {
                if (queue.isEmpty()) return
                val safeIndex = startIndex.coerceIn(0, queue.lastIndex)
                val mediaItems = queue.map { track ->
                    MediaItem.Builder()
                        .setMediaId(track.audioUrl)
                        .setUri(Uri.parse(track.audioUrl))
                        .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                            .setTitle(track.title)
                            .setArtist(track.artist)
                            .setAlbumTitle("BESOUND Playlist")
                            .apply { track.coverUrl?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) } }
                            .build())
                        .build()
                }
                val track = queue[safeIndex]
                currentUri = track.audioUrl
                externalSong = SongEntity(uri = track.audioUrl, title = track.title, artist = track.artist, album = "BESOUND Playlist", lyrics = "", coverUri = track.coverUrl)
                recordRecentlyPlayed(track.audioUrl)
                player.setMediaItems(mediaItems, safeIndex, 0L)
                player.prepare()
                player.play()
                isPlaying = true
                previousTab = selectedTab
                selectedTab = 5
            }

            fun openEditor(song: SongEntity) {
                editingSong = song
                editTitle = song.title
                editArtist = song.artist
                editAlbum = song.album
                editMoods = song.moods
                editLyrics = song.lyrics
                editCoverUri = song.coverUri
                showEditor = true
            }

            LaunchedEffect(Unit) {
                while (true) {
                    isPlaying = player.isPlaying
                    positionMs = player.currentPosition.coerceAtLeast(0L)
                    durationMs = player.duration.takeIf { it > 0L } ?: 0L
                    updateCompatPlaybackState()
                    // Do not infer a selected track from ExoPlayer's default index (0).
                    // A track is selected only when the player actually has a media item.
                    val activeItem = player.currentMediaItem
                    currentUri = activeItem?.mediaId
                    if (activeItem != null && songs.none { it.uri == activeItem.mediaId }) {
                        val metadata = activeItem.mediaMetadata
                        externalSong = SongEntity(
                            uri = activeItem.mediaId,
                            title = metadata.title?.toString().orEmpty(),
                            artist = metadata.artist?.toString().orEmpty(),
                            album = metadata.albumTitle?.toString().orEmpty(),
                            lyrics = "",
                            coverUri = metadata.artworkUri?.toString()
                        )
                    }
                    delay(400)
                }
            }

            DisposableEffect(player) {
                val listener = object : Player.Listener {
                    override fun onAudioSessionIdChanged(audioSessionId: Int) {
                        activeAudioSessionId = audioSessionId
                    }
                    override fun onIsPlayingChanged(playing: Boolean) {
                        isPlaying = playing
                        updateCompatMediaSession()
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        currentUri = mediaItem?.mediaId
                        if (mediaItem != null && songs.none { it.uri == mediaItem.mediaId }) {
                            val metadata = mediaItem.mediaMetadata
                            externalSong = SongEntity(
                                uri = mediaItem.mediaId,
                                title = metadata.title?.toString().orEmpty(),
                                artist = metadata.artist?.toString().orEmpty(),
                                album = metadata.albumTitle?.toString().orEmpty(),
                                lyrics = "",
                                coverUri = metadata.artworkUri?.toString()
                            )
                        }
                        mediaItem?.mediaId?.let { recordRecentlyPlayed(it); recordPlayCount(it) }
                        // Media3 does not guarantee that a notification rebuilds its large icon
                        // just because a MediaItem's artwork metadata changed.
                        updateCompatMediaSession(forceMetadata = true)
                        if (::notificationManager.isInitialized) notificationManager.invalidate()
                    }
                    override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
                        updateCompatMediaSession(forceMetadata = true)
                        if (::notificationManager.isInitialized) notificationManager.invalidate()
                    }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        durationMs = player.duration.takeIf { it > 0L } ?: 0L
                        updateCompatMediaSession()
                    }
                    override fun onPlayerError(error: androidx.media3.common.PlaybackException) {
                        isPlaying = false
                        val detail = error.cause?.message ?: error.message ?: "Audio tidak dapat dibaca"
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "Gagal memutar lagu: $detail",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                    override fun onPositionDiscontinuity(
                        oldPosition: Player.PositionInfo,
                        newPosition: Player.PositionInfo,
                        reason: Int
                    ) {
                        updateCompatPlaybackState()
                    }
                }
                player.addListener(listener)
                onDispose { player.removeListener(listener) }
            }

            BackHandler(enabled = true) {
                when {
                    showLyrics -> showLyrics = false
                    selectedTab == 5 -> selectedTab = previousTab.coerceIn(0, 6)
                    selectedTab == 10 -> selectedTab = 9
                    selectedTab in 11..15 -> selectedTab = 9
                    selectedTab == 9 || selectedTab == 16 -> selectedTab = 4
                    selectedTab == 7 || selectedTab == 8 || selectedTab == 17 -> selectedTab = 0
                    selectedTab != 0 -> selectedTab = 0
                    else -> showExitDialog = true
                }
            }

            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Orange,
                    onPrimary = Color.White,
                    secondary = Golden,
                    background = Cream,
                    surface = Cream,
                    onBackground = Ink,
                    onSurface = Ink,
                    onSurfaceVariant = Muted,
                    surfaceVariant = CreamCard,
                    secondaryContainer = CreamCard,
                    onSecondaryContainer = Ink
                )
            ) {
                Scaffold(
                    containerColor = Cream,
                    bottomBar = {
                        Column {
                            if (selectedTab != 5 && selectedTab != 0 && !showLyrics && player.currentMediaItem != null && currentSong != null) {
                                Box(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp)) {
                                    MiniPlayer(
                                        song = currentSong, isPlaying = isPlaying, positionMs = positionMs, durationMs = durationMs,
                                        onPlayPause = { if (player.isPlaying) player.pause() else player.play() },
                                        onPrevious = { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else player.seekTo(0L) },
                                        onNext = { if (player.hasNextMediaItem()) player.seekToNextMediaItem() },
                                        onOpen = { previousTab = selectedTab; selectedTab = 5 }
                                    )
                                }
                            }
                            if (!showLyrics && selectedTab != 8) NavigationBar(containerColor = NavSurface) {
                                val navItems = listOf(
                                    Triple("Home", Icons.Default.Home, 0),
                                    Triple("Playlist", Icons.Default.QueueMusic, 6),
                                    Triple("Library", Icons.Default.LibraryMusic, 3),
                                    Triple("Profile", Icons.Default.Person, 4)
                                )
                                navItems.forEach { item ->
                                    NavigationBarItem(
                                        selected = selectedTab == item.third || (selectedTab == 5 && item.third == 0) || (item.third == 3 && selectedTab == 17) || (item.third == 4 && selectedTab in 9..16),
                                        onClick = { selectedTab = item.third },
                                        icon = { Icon(item.second, contentDescription = item.first) },
                                        label = { Text(item.first, maxLines = 1) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Orange, selectedTextColor = Ink, indicatorColor = CreamCard,
                                            unselectedIconColor = Muted, unselectedTextColor = Muted
                                        )
                                    )
                                }
                            }
                        }
                    }
                ) { padding ->
                    Column(
                        Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                    ) {
                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (selectedTab == 0) {
                                Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("BESOUND", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = (-0.8).sp)
                                        Spacer(Modifier.width(7.dp))
                                        AudioVisualizer(isPlaying = isPlaying, barColor = Orange, modifier = Modifier.height(25.dp))
                                    }
                                    Text("Your Music. Your Lyrics. Your World.", color = Muted, fontSize = 12.sp)
                                }
                            } else {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        when (selectedTab) { 8 -> "Search"; 9 -> "Pengaturan"; 10 -> "Audio & Equalizer"; 11 -> "Penyimpanan & Cache"; 12 -> "Notifikasi"; 13 -> "Jaringan & Data"; 14 -> "Privasi & Keamanan"; 15 -> "Tentang BESOUND"; 16 -> "Admin BEI SONG"; 17 -> "Favorit"; else -> "BESOUND" },
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Ink,
                                        letterSpacing = (-0.8).sp
                                    )
                                    if (selectedTab !in 8..15) Text(
                                        "Your music. Your lyrics. Your world.",
                                        color = Muted,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                            if (selectedTab == 5) {
                                Box {
                                    IconButton(onClick = { showNowOptions = true }) {
                                        Icon(Icons.Default.MoreVert, "Menu lainnya", tint = Orange, modifier = Modifier.size(29.dp))
                                    }
                                    DropdownMenu(
                                        expanded = showNowOptions,
                                        onDismissRequest = { showNowOptions = false },
                                        containerColor = CreamCard,
                                        tonalElevation = 8.dp,
                                        shadowElevation = 8.dp
                                    ) {
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Share, null, tint = Orange)
                                                    Spacer(Modifier.width(12.dp))
                                                    Text("Share", color = Ink)
                                                }
                                            },
                                            onClick = {
                                                showNowOptions = false
                                                currentSong?.let { song ->
                                                    val shareText = "Dengarkan ${song.title} - ${song.artist} di BESOUND."
                                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                                        type = "text/plain"
                                                        putExtra(Intent.EXTRA_TEXT, shareText)
                                                    }
                                                    startActivity(Intent.createChooser(sendIntent, "Bagikan lagu"))
                                                }
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.PlaylistAdd, null, tint = Orange)
                                                    Spacer(Modifier.width(12.dp))
                                                    Text("Add to Playlist", color = Ink)
                                                }
                                            },
                                            onClick = {
                                                showNowOptions = false
                                                selectedTab = 6
                                            }
                                        )
                                    }
                                }
                            } else {
                                if (selectedTab == 8 || selectedTab in 9..17) {
                                    IconButton(onClick = {
                                        selectedTab = when (selectedTab) {
                                            10, 11, 12, 13, 14, 15, 16 -> if (selectedTab == 16) 4 else 9
                                            9 -> 4
                                            else -> 0
                                        }
                                    }) {
                                        Icon(Icons.Default.ArrowBack, "Kembali", tint = Ink, modifier = Modifier.size(25.dp))
                                    }
                                }
                                Box {
                                    IconButton(onClick = { showThemeMenu = true }) {
                                        Icon(Icons.Default.Palette, "Ganti tema", tint = Orange, modifier = Modifier.size(30.dp))
                                    }
                                    DropdownMenu(
                                        expanded = showThemeMenu,
                                        onDismissRequest = { showThemeMenu = false },
                                        containerColor = CreamCard,
                                        tonalElevation = 8.dp,
                                        shadowElevation = 8.dp
                                    ) {
                                        listOf("Golden Dusk", "Cream Light", "Midnight").forEach { option ->
                                            DropdownMenuItem(
                                                text = {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            option,
                                                            color = Ink,
                                                            fontWeight = if (themeName == option) FontWeight.Bold else FontWeight.Normal
                                                        )
                                                        if (themeName == option) {
                                                            Spacer(Modifier.width(12.dp))
                                                            Icon(Icons.Default.Check, contentDescription = "Tema aktif", tint = Orange)
                                                        }
                                                    }
                                                },
                                                onClick = { themeName = option; showThemeMenu = false }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        if (selectedTab == 0) {
                            OutlinedTextField(
                                value = searchText,
                                onValueChange = { searchText = it; searchCategory = "All Song" },
                                modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { selectedTab = 8 }),
                                placeholder = { Text("Cari lagu, artis, playlist...", color = Muted) },
                                shape = RoundedCornerShape(28.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Ink, unfocusedTextColor = Ink, cursorColor = Orange,
                                    focusedBorderColor = Orange, unfocusedBorderColor = DividerTone,
                                    focusedContainerColor = CreamCard, unfocusedContainerColor = CreamCard
                                )
                            )
                        }
                        Spacer(Modifier.height(18.dp))

                        if (selectedTab == 0) {
                            val homeSongs = if (homeFeedMode == "trending") trendingSongs else newestSongs.take(12)
                            Column(
                                Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                // Bei mascot greeting: retain the robot, remove the decorative waveform.
                                Card(
                                    modifier = Modifier.fillMaxWidth().height(116.dp),
                                    shape = RoundedCornerShape(24.dp),
                                    colors = CardDefaults.cardColors(containerColor = CreamCard),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Orange.copy(alpha = 0.75f)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                                ) {
                                    Box(Modifier.fillMaxSize()) {
                                        Image(
                                            painterResource(R.drawable.home_sunset), "Latar hangat BESOUND",
                                            Modifier.fillMaxSize().graphicsLayer { alpha = 0.24f },
                                            contentScale = ContentScale.Crop
                                        )
                                        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Transparent, CreamCard.copy(alpha = 0.30f), Orange.copy(alpha = 0.14f)))))
                                        Row(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Image(
                                                painterResource(R.drawable.bei_mascot_robot), "Robot Bei menyapa",
                                                Modifier.width(112.dp).fillMaxHeight(), contentScale = ContentScale.Fit
                                            )
                                            Spacer(Modifier.width(8.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                                Text("Asyik!", color = Golden, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                                                Text("Nikmati lagunya, aku temenin.", color = Ink, fontSize = 12.sp, lineHeight = 16.sp)
                                            }
                                        }
                                    }
                                }

                                // Dynamic Now Playing card: blurred artwork in the background, crisp cover on the right.
                                Card(
                                    modifier = Modifier.fillMaxWidth().height(142.dp),
                                    shape = RoundedCornerShape(24.dp),
                                    colors = CardDefaults.cardColors(containerColor = CreamCard),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, Orange.copy(alpha = 0.55f))
                                ) {
                                    Box(Modifier.fillMaxSize()) {
                                        if (currentSong != null) {
                                            SongArtwork(currentSong, Modifier.fillMaxSize().blur(17.dp).graphicsLayer { alpha = 0.34f }, largeFallback = true)
                                        } else {
                                            Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(CreamCard, Cream, Orange.copy(alpha = 0.18f)))))
                                        }
                                        Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Cream.copy(alpha = 0.88f), CreamCard.copy(alpha = 0.72f), Color.Transparent))))
                                        Row(Modifier.fillMaxSize().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                                Surface(color = Orange.copy(alpha = 0.20f), shape = RoundedCornerShape(50)) {
                                                    Text("Now Playing", color = Golden, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
                                                }
                                                Text(currentSong?.title ?: "Belum ada musik diputar", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                Text(currentSong?.artist ?: "Pilih lagu untuk mulai mendengarkan", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                AudioVisualizer(isPlaying = isPlaying, barColor = Orange, modifier = Modifier.fillMaxWidth(0.82f).height(20.dp))
                                            }
                                            Spacer(Modifier.width(10.dp))
                                            if (currentSong != null) {
                                                SongArtwork(currentSong, Modifier.size(104.dp).clip(RoundedCornerShape(17.dp)), largeFallback = true)
                                            } else {
                                                Box(Modifier.size(104.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Orange, Golden))), contentAlignment = Alignment.Center) {
                                                    Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(38.dp))
                                                }
                                            }
                                        }
                                    }
                                }

                                // Two image-led destinations, both open their actual catalog screens.
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Card(
                                        modifier = Modifier.weight(1f).height(104.dp).clickable { selectedTab = 1 },
                                        shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = CreamCard),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Orange.copy(alpha = 0.70f))
                                    ) {
                                        Box(Modifier.fillMaxSize()) {
                                            Image(painterResource(R.drawable.bei_song_mask), "Foto BEI SONG", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Transparent, Color(0xE817100C)))))
                                            Column(Modifier.align(Alignment.BottomStart).padding(9.dp)) {
                                                Text("BEI SONG", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                                Text("Karya original Be'i", color = Color.White, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                    Card(
                                        modifier = Modifier.weight(1f).height(104.dp).clickable { selectedTab = 2 },
                                        shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = CreamCard),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Orange.copy(alpha = 0.70f))
                                    ) {
                                        Box(Modifier.fillMaxSize()) {
                                            Image(painterResource(R.drawable.global_music_city), "Foto GLOBAL SONG", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                            Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Transparent, Color(0xE817100C)))))
                                            Column(Modifier.align(Alignment.BottomStart).padding(9.dp)) {
                                                Text("GLOBAL SONG", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
                                                Text("Musik pilihan dunia", color = Color.White, fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }

                                // Full player on Home; controls share the same ExoPlayer state as notifications and other screens.
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(24.dp),
                                    colors = CardDefaults.cardColors(containerColor = CreamCard),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, DividerTone),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                                ) {
                                    Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (currentSong != null) SongArtwork(currentSong, Modifier.size(76.dp).clip(RoundedCornerShape(14.dp)), largeFallback = true)
                                            else Box(Modifier.size(76.dp).clip(RoundedCornerShape(14.dp)).background(Orange.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Orange, modifier = Modifier.size(30.dp)) }
                                            Spacer(Modifier.width(11.dp))
                                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                                Text(currentSong?.title ?: "Belum ada lagu", color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                Text(currentSong?.artist ?: "Pilih lagu dari BEI SONG atau Library", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                            if (currentSong != null) {
                                                IconButton(onClick = { toggleFavorite(currentSong) }) {
                                                    Icon(if (currentSong.uri in favoriteUris) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorit", tint = if (currentSong.uri in favoriteUris) Orange else Muted)
                                                }
                                            }
                                        }
                                        Slider(
                                            value = positionMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1L).toFloat()),
                                            onValueChange = { player.seekTo(it.toLong()) },
                                            valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(),
                                            enabled = currentSong != null && durationMs > 0L,
                                            colors = SliderDefaults.colors(thumbColor = Golden, activeTrackColor = Orange, inactiveTrackColor = DividerTone)
                                        )
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Text(formatTime(positionMs), color = Muted, fontSize = 10.sp)
                                            Text(formatTime(durationMs), color = Muted, fontSize = 10.sp)
                                        }
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(onClick = { shuffleEnabled = !shuffleEnabled; player.shuffleModeEnabled = shuffleEnabled }, enabled = currentSong != null) {
                                                Icon(Icons.Default.Shuffle, "Acak", tint = if (shuffleEnabled) Orange else Muted)
                                            }
                                            IconButton(onClick = { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() else if (currentSong != null) player.seekTo(0L) }, enabled = currentSong != null) {
                                                Icon(Icons.Default.SkipPrevious, "Sebelumnya", tint = Ink, modifier = Modifier.size(27.dp))
                                            }
                                            FilledIconButton(
                                                onClick = {
                                                    if (player.isPlaying) player.pause()
                                                    else if (player.currentMediaItem == null && currentSong != null) playSong(currentSong, openPlayer = false)
                                                    else {
                                                        if (player.playbackState == Player.STATE_IDLE) player.prepare()
                                                        if (player.playbackState == Player.STATE_ENDED) player.seekTo(0L)
                                                        player.play()
                                                    }
                                                    isPlaying = player.isPlaying
                                                },
                                                enabled = currentSong != null,
                                                modifier = Modifier.size(54.dp),
                                                colors = IconButtonDefaults.filledIconButtonColors(containerColor = Orange, contentColor = Color.White)
                                            ) {
                                                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Jeda" else "Putar", modifier = Modifier.size(30.dp))
                                            }
                                            IconButton(onClick = { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }, enabled = currentSong != null) {
                                                Icon(Icons.Default.SkipNext, "Berikutnya", tint = Ink, modifier = Modifier.size(27.dp))
                                            }
                                            IconButton(onClick = {
                                                repeatMode = when (repeatMode) { Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL; Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE; else -> Player.REPEAT_MODE_OFF }
                                                player.repeatMode = repeatMode
                                            }, enabled = currentSong != null) {
                                                Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat, "Ulangi", tint = if (repeatMode == Player.REPEAT_MODE_OFF) Muted else Orange)
                                            }
                                            IconButton(onClick = { showQueueDialog = true }) {
                                                Icon(Icons.Default.QueueMusic, "Antrean lagu", tint = Orange)
                                            }
                                        }
                                    }
                                }

                                // Compact shortcuts remain functional and do not crowd the top of Home.
                                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                                    HomeShortcut("Trending", Icons.Default.TrendingUp, homeFeedMode == "trending") { homeFeedMode = "trending" }
                                    HomeShortcut("Rilis Baru", Icons.Default.NewReleases, homeFeedMode == "new") { homeFeedMode = "new" }
                                    HomeShortcut("Playlist", Icons.Default.QueueMusic, false) { selectedTab = 6 }
                                    HomeShortcut("Favorit", Icons.Default.Favorite, false) { selectedTab = 17 }
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(if (homeFeedMode == "trending") "Sering Diputar" else "Lagu Terbaru", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        TextButton(onClick = { selectedTab = if (homeFeedMode == "trending") 7 else 3 }) { Text("Lihat Semua  ›", color = Orange, fontSize = 11.sp) }
                                    }
                                    if (homeSongs.isEmpty()) {
                                        Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                            Text("Belum ada lagu. Tambahkan musik melalui Library.", color = Muted, modifier = Modifier.padding(16.dp), fontSize = 12.sp)
                                        }
                                    } else {
                                        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                                            homeSongs.forEach { song ->
                                                Card(modifier = Modifier.width(132.dp).clickable { playSong(song, true) }, shape = RoundedCornerShape(17.dp), colors = CardDefaults.cardColors(containerColor = CreamCard)) {
                                                    Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                                                        Box {
                                                            SongArtwork(song, Modifier.fillMaxWidth().height(116.dp).clip(RoundedCornerShape(12.dp)), largeFallback = true)
                                                            IconButton(onClick = { toggleFavorite(song) }, modifier = Modifier.align(Alignment.TopEnd).size(34.dp)) {
                                                                Icon(if (song.uri in favoriteUris) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favorit ${song.title}", tint = if (song.uri in favoriteUris) Orange else Color.White, modifier = Modifier.size(19.dp))
                                                            }
                                                        }
                                                        Text(song.title, color = Ink, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                        Text(song.artist, color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                            }
                        } else if (selectedTab == 1 || selectedTab == 2) {
                            val isBeiSong = selectedTab == 1
                            if (isBeiSong) {
                                BeiSongCloudScreen(onPlaySong = { cloudSong ->
                                    scope.launch {
                                        val localTrack = SongEntity(
                                            uri = cloudSong.audioUrl,
                                            title = cloudSong.title,
                                            artist = cloudSong.artist,
                                            album = "BEI SONG",
                                            lyrics = cloudSong.lyrics.orEmpty(),
                                            coverUri = cloudSong.coverUrl
                                        )
                                        dao.upsert(localTrack)
                                        recordRecentlyPlayed(cloudSong.audioUrl)
                                        previousTab = 1
                                        currentUri = cloudSong.audioUrl
                                        player.setMediaItem(
                                            MediaItem.Builder()
                                                .setMediaId(cloudSong.audioUrl)
                                                .setUri(Uri.parse(cloudSong.audioUrl))
                                                .setMediaMetadata(
                                                    androidx.media3.common.MediaMetadata.Builder()
                                                        .setTitle(cloudSong.title)
                                                        .setArtist(cloudSong.artist)
                                                        .setAlbumTitle("BEI SONG")
                                                        .apply { cloudSong.coverUrl?.let { setArtworkUri(Uri.parse(it)) } }
                                                        .build()
                                                ).build()
                                        )
                                        player.prepare()
                                        player.play()
                                        isPlaying = true
                                        selectedTab = 5
                                    }
                                })
                            } else {
                                Text("GLOBAL MUSIC", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Music from around the world", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Text("Cari dan putar musik independen dari katalog Audius langsung di BESOUND.", color = Muted, fontSize = 13.sp)
                                Spacer(Modifier.height(8.dp))
                                OutlinedTextField(
                                    value = globalSearchQuery,
                                    onValueChange = { globalSearchQuery = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    placeholder = { Text("Cari judul lagu atau artis...", color = Muted) },
                                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Orange) },
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                    keyboardActions = KeyboardActions(onSearch = {
                                        if (globalSearchQuery.isNotBlank()) {
                                            scope.launch {
                                                globalSearchLoading = true
                                                globalSearchError = ""
                                                try {
                                                    globalSearchResults = AudiusApi.searchTracks(globalSearchQuery, BuildConfig.AUDIUS_API_KEY)
                                                        .map { it.toSongEntity() }
                                                    if (globalSearchResults.isEmpty()) globalSearchError = "Tidak ada lagu yang bisa diputar untuk pencarian ini."
                                                } catch (error: Exception) {
                                                    globalSearchError = error.message ?: "Pencarian Global Music gagal."
                                                } finally {
                                                    globalSearchLoading = false
                                                }
                                            }
                                        }
                                    }),
                                    shape = RoundedCornerShape(20.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Ink,
                                        unfocusedTextColor = Ink,
                                        cursorColor = Orange,
                                        focusedBorderColor = Orange,
                                        unfocusedBorderColor = Orange.copy(alpha = 0.65f),
                                        focusedContainerColor = CreamCard,
                                        unfocusedContainerColor = CreamCard
                                    )
                                )
                                Button(
                                    onClick = {
                                        if (globalSearchQuery.isBlank()) {
                                            globalSearchError = "Masukkan judul lagu atau nama artis terlebih dahulu."
                                        } else {
                                            scope.launch {
                                                globalSearchLoading = true
                                                globalSearchError = ""
                                                try {
                                                    globalSearchResults = AudiusApi.searchTracks(globalSearchQuery, BuildConfig.AUDIUS_API_KEY)
                                                        .map { it.toSongEntity() }
                                                    if (globalSearchResults.isEmpty()) globalSearchError = "Tidak ada lagu yang bisa diputar untuk pencarian ini."
                                                } catch (error: Exception) {
                                                    globalSearchError = error.message ?: "Pencarian Global Music gagal."
                                                } finally {
                                                    globalSearchLoading = false
                                                }
                                            }
                                        }
                                    },
                                    enabled = !globalSearchLoading && globalSearchQuery.isNotBlank(),
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.White)
                                ) {
                                    Icon(Icons.Default.Search, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (globalSearchLoading) "Mencari..." else "Cari Musik")
                                }
                                if (globalSearchLoading) {
                                    Row(Modifier.fillMaxWidth().padding(22.dp), horizontalArrangement = Arrangement.Center) {
                                        CircularProgressIndicator(color = Orange)
                                    }
                                }
                                if (globalSearchError.isNotBlank()) {
                                    Text(globalSearchError, color = Golden, fontSize = 12.sp, modifier = Modifier.padding(vertical = 8.dp))
                                }
                                if (globalSearchResults.isNotEmpty()) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Hasil pencarian", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        Text("${globalSearchResults.size} lagu", color = Muted, fontSize = 11.sp)
                                    }
                                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                        globalSearchResults.forEachIndexed { index, track ->
                                            Row(
                                                Modifier.fillMaxWidth().clip(RoundedCornerShape(17.dp))
                                                    .background(CreamCard)
                                                    .clickable { playSongQueue(globalSearchResults, index) }
                                                    .padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                SongArtwork(track, Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)))
                                                Spacer(Modifier.width(11.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Text(track.title, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                    Text(track.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text("Audius • Full track", color = Golden, fontSize = 10.sp)
                                                }
                                                IconButton(onClick = { playSongQueue(globalSearchResults, index) }) {
                                                    Icon(Icons.Default.PlayCircleFilled, "Putar ${track.title}", tint = Orange, modifier = Modifier.size(30.dp))
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (selectedTab == 7) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { selectedTab = 0 }) {
                                    Icon(Icons.Default.ArrowBack, "Kembali", tint = Orange)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("HISTORY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("Recently Played", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("10 lagu terakhir yang kamu dengarkan", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            if (recentSongs.isEmpty()) {
                                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp)) {
                                    Text("Belum ada riwayat pemutaran.", color = Muted, modifier = Modifier.padding(18.dp))
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    recentSongs.forEachIndexed { index, song ->
                                        Row(
                                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CreamCard)
                                                .clickable { playSong(song, false) }.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("${index + 1}", color = Muted, fontSize = 12.sp, modifier = Modifier.width(22.dp))
                                            SongArtwork(song, Modifier.size(52.dp).clip(RoundedCornerShape(11.dp)))
                                            Spacer(Modifier.width(10.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(song.title, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                Text(song.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                            val isThisRecentPlaying = currentUri == song.uri && isPlaying
                                            IconButton(onClick = {
                                                if (currentUri == song.uri && player.currentMediaItem != null) {
                                                    if (player.isPlaying) player.pause() else player.play()
                                                } else playSong(song, false)
                                            }) {
                                                Icon(
                                                    if (isThisRecentPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                                    if (isThisRecentPlaying) "Jeda ${song.title}" else "Putar ${song.title}",
                                                    tint = Orange,
                                                    modifier = Modifier.size(27.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (selectedTab == 6) {
                            PlaylistCloudScreen(
                                onPlay = { queue, index -> playPlaylistQueue(queue, index) },
                                onRequestLogin = { selectedTab = 4 }
                            )
                        } else if (selectedTab == 4) {
                            var profileEmail by remember { mutableStateOf(PlaylistCloud.cachedSession(this@MainActivity)?.email.orEmpty()) }
                            var profilePassword by remember { mutableStateOf("") }
                            var profileConfirm by remember { mutableStateOf("") }
                            var profileSignup by remember { mutableStateOf(false) }
                            var profileBusy by remember { mutableStateOf(false) }
                            var profileMessage by remember { mutableStateOf("") }
                            val profileSession = PlaylistCloud.cachedSession(this@MainActivity)
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("PROFILE", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Profil & Pengaturan", color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.AccountCircle, null, tint = Orange, modifier = Modifier.size(52.dp))
                                            Spacer(Modifier.width(12.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(profileSession?.email ?: "Guest user", color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                                Text(if (profileSession == null) "Belum login" else "Akun aktif • Supabase", color = Muted, fontSize = 12.sp)
                                            }
                                            Icon(Icons.Default.ChevronRight, null, tint = Muted)
                                        }
                                        if (profileSession == null) {
                                            OutlinedTextField(profileEmail, { profileEmail = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                            OutlinedTextField(profilePassword, { profilePassword = it }, label = { Text("Password") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                                            if (profileSignup) OutlinedTextField(profileConfirm, { profileConfirm = it }, label = { Text("Ulangi password") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                                            Button(onClick = {
                                                scope.launch {
                                                    profileBusy = true; profileMessage = ""
                                                    try {
                                                        if (profileSignup) {
                                                            require(profilePassword.length >= 8) { "Password minimal 8 karakter." }
                                                            require(profilePassword == profileConfirm) { "Konfirmasi password tidak sama." }
                                                            val created = PlaylistCloud.signUp(this@MainActivity, profileEmail, profilePassword)
                                                            profileMessage = if (created) "Akun berhasil dibuat dan login." else "Akun dibuat. Periksa email untuk verifikasi, lalu login."
                                                        } else { PlaylistCloud.signIn(this@MainActivity, profileEmail, profilePassword); profileMessage = "Login berhasil." }
                                                    } catch (e: Exception) { profileMessage = e.message ?: "Autentikasi gagal." }
                                                    profileBusy = false
                                                }
                                            }, enabled = !profileBusy && profileEmail.contains("@") && profilePassword.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (profileBusy) "Memproses..." else if (profileSignup) "Buat Akun" else "Login") }
                                            TextButton(onClick = { profileSignup = !profileSignup; profileMessage = "" }) { Text(if (profileSignup) "Sudah punya akun? Login" else "Belum punya akun? Buat akun", color = Orange) }
                                        } else {
                                            Button(onClick = { selectedTab = 6 }, modifier = Modifier.fillMaxWidth()) { Text("Buka Playlist Cloud") }
                                            TextButton(onClick = { PlaylistCloud.clearSession(this@MainActivity); profileMessage = "Kamu sudah logout." }) { Text("Keluar dari akun", color = Orange) }
                                        }
                                        if (profileMessage.isNotBlank()) Text(profileMessage, color = Golden, fontSize = 12.sp)
                                    }
                                }
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(horizontal = 14.dp)) {
                                        ProfileMenuRow(Icons.Default.CloudQueue, "Playlist Cloud", "Buka dan kelola playlist online") { selectedTab = 6 }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.AdminPanelSettings, "Mode Admin (BEI SONG)", if (BeiSongCloud.savedAdminToken(this@MainActivity) == null) "Login dan kelola katalog musik" else "Akses admin aktif di perangkat ini") { selectedTab = 16 }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.Settings, "Pengaturan Aplikasi", "Audio, penyimpanan, notifikasi, dan data") { selectedTab = 9 }
                                    }
                                }
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(horizontal = 14.dp)) {
                                        ProfileMenuRow(Icons.Default.Palette, "Tema & Tampilan", "Golden Dusk, Cream Light, Midnight") { showThemeMenu = true }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.Notifications, "Notifikasi", "Atur notifikasi pemutaran") { selectedTab = 12 }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.Info, "Tentang BESOUND", "Versi aplikasi dan informasi") { selectedTab = 15 }
                                    }
                                }
                                OutlinedButton(onClick = { showThemeMenu = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Palette, null); Spacer(Modifier.width(8.dp)); Text("Ganti tema") }
                                Text("BESOUND • v1.5.0", color = Muted, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                            }
                        } else if (selectedTab == 9) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("PENGATURAN", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text("Atur pengalaman BESOUND", color = Ink, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(horizontal = 14.dp)) {
                                        ProfileMenuRow(Icons.Default.Equalizer, "Audio & Equalizer", "Equalizer 10-band, preset, dan efek audio") { selectedTab = 10 }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.Storage, "Penyimpanan & Cache", "Lihat dan bersihkan cache aplikasi") { selectedTab = 11 }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.Notifications, "Notifikasi", "Kontrol notifikasi pemutaran") { selectedTab = 12 }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.Wifi, "Jaringan & Data", "Status koneksi dan sinkronisasi cloud") { selectedTab = 13 }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.Security, "Privasi & Keamanan", "Informasi akun dan penyimpanan data") { selectedTab = 14 }
                                        Divider(color = DividerTone)
                                        ProfileMenuRow(Icons.Default.Info, "Tentang BESOUND", "Versi, informasi, dan lisensi") { selectedTab = 15 }
                                    }
                                }
                                Text("Pengaturan pemutar seperti shuffle, repeat, dan lirik tetap berada di halaman Player/Lyrics.", color = Muted, fontSize = 12.sp)
                            }
                        } else if (selectedTab == 17) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                Text("LAGU FAVORIT", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("${favoriteSongs.size} lagu disukai", color = Muted, fontSize = 12.sp)
                                if (favoriteSongs.isEmpty()) {
                                    Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Icon(Icons.Default.FavoriteBorder, null, tint = Orange, modifier = Modifier.size(32.dp))
                                            Text("Belum ada lagu favorit", color = Ink, fontWeight = FontWeight.Bold)
                                            Text("Tekan ikon hati pada kartu lagu untuk menyimpannya di sini.", color = Muted, fontSize = 12.sp)
                                        }
                                    }
                                } else {
                                    favoriteSongs.forEach { song ->
                                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(CreamCard).clickable { playSong(song, true) }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                            SongArtwork(song, Modifier.size(54.dp).clip(RoundedCornerShape(11.dp)))
                                            Spacer(Modifier.width(10.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(song.title, color = Ink, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(song.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                            IconButton(onClick = { toggleFavorite(song) }) { Icon(Icons.Default.Favorite, "Hapus dari favorit", tint = Orange) }
                                        }
                                    }
                                }
                            }
                        } else if (selectedTab == 10) {
                            AudioEqualizerScreen(context = this@MainActivity, audioSessionId = activeAudioSessionId, controller = audioEffects)
                        } else if (selectedTab == 11) {
                            val cacheBytes = remember { calculateCacheSize(cacheDir) }
                            var cleared by remember { mutableStateOf(false) }
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("PENYIMPANAN", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                        Icon(Icons.Default.Storage, null, tint = Orange, modifier = Modifier.size(34.dp))
                                        Text("Cache aplikasi", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                        Text(if (cleared) "Cache berhasil dibersihkan." else "Ukuran cache saat dibuka: ${formatBytes(cacheBytes)}", color = Muted)
                                        Button(onClick = { cacheDir.deleteRecursively(); cacheDir.mkdirs(); cleared = true }, modifier = Modifier.fillMaxWidth()) { Text("Bersihkan Cache") }
                                        Text("Membersihkan cache tidak menghapus file musik, playlist cloud, atau akun.", color = Muted, fontSize = 11.sp)
                                    }
                                }
                            }
                        } else if (selectedTab == 12) {
                            var mediaNotif by remember { mutableStateOf(getPreferences(MODE_PRIVATE).getBoolean("media_notification_enabled", true)) }
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("NOTIFIKASI", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) { Text("Kontrol musik di notifikasi", color = Ink, fontWeight = FontWeight.Bold); Text("Tampilkan kontrol play, pause, dan next di panel notifikasi", color = Muted, fontSize = 12.sp) }
                                        Switch(checked = mediaNotif, onCheckedChange = { enabled -> mediaNotif = enabled; getPreferences(MODE_PRIVATE).edit().putBoolean("media_notification_enabled", enabled).apply(); notificationManager.setPlayer(if (enabled) player else null) })
                                    }
                                }
                                Text("Izin notifikasi Android juga dapat diatur melalui Pengaturan Sistem.", color = Muted, fontSize = 12.sp)
                            }
                        } else if (selectedTab == 13) {
                            val session = PlaylistCloud.cachedSession(this@MainActivity)
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("JARINGAN & DATA", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Status akun cloud", color = Ink, fontWeight = FontWeight.Bold)
                                        Text(if (session != null) "Login sebagai ${session.email}" else "Belum login ke Supabase", color = Muted, fontSize = 12.sp)
                                        Text("Playlist privat disinkronkan melalui koneksi internet. Musik lokal tetap tersedia tanpa koneksi.", color = Muted, fontSize = 12.sp)
                                        Button(onClick = { selectedTab = 4 }, modifier = Modifier.fillMaxWidth()) { Text(if (session == null) "Login akun" else "Kelola akun") }
                                    }
                                }
                            }
                        } else if (selectedTab == 14) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("PRIVASI & KEAMANAN", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text("Data akun", color = Ink, fontWeight = FontWeight.Bold)
                                        Text("Informasi login playlist cloud disimpan untuk menjaga sesi akun. Token admin disimpan terpisah pada perangkat ini.", color = Muted, fontSize = 12.sp)
                                        Text("Kelola sesi akun melalui halaman Profil. Keluar dari akun akan menghapus sesi lokal.", color = Muted, fontSize = 12.sp)
                                        OutlinedButton(onClick = { selectedTab = 4 }, modifier = Modifier.fillMaxWidth()) { Text("Buka Profil") }
                                    }
                                }
                            }
                        } else if (selectedTab == 15) {
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Spacer(Modifier.height(20.dp))
                                Icon(Icons.Default.Headphones, null, tint = Orange, modifier = Modifier.size(64.dp))
                                Text("BESOUND", color = Ink, fontSize = 28.sp, fontWeight = FontWeight.Black)
                                Text("Your music. Your lyrics. Your world.", color = Muted)
                                Text("Versi ${packageManager.getPackageInfo(packageName, 0).versionName ?: "1.6.0"}", color = Ink, fontWeight = FontWeight.Bold)
                                Text("Dibuat untuk mendengarkan musik dan menikmati lirik.", color = Muted, fontSize = 12.sp)
                            }
                        } else if (selectedTab == 16) {
                            var adminEmail by remember { mutableStateOf(BeiSongCloud.ADMIN_EMAIL) }
                            var adminPassword by remember { mutableStateOf("") }
                            var adminMessage by remember { mutableStateOf("") }
                            var adminBusy by remember { mutableStateOf(false) }
                            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("ADMIN BEI SONG", color = Orange, fontWeight = FontWeight.Bold)
                                if (BeiSongCloud.savedAdminToken(this@MainActivity) == null) {
                                    OutlinedTextField(adminEmail, { adminEmail = it }, label = { Text("Email admin") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                    OutlinedTextField(adminPassword, { adminPassword = it }, label = { Text("Password admin") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                                    Button(onClick = { scope.launch { adminBusy = true; try { BeiSongCloud.saveAdminToken(this@MainActivity, BeiSongCloud.login(adminEmail.trim(), adminPassword)); adminPassword = ""; adminMessage = "Akses admin aktif." } catch (e: Exception) { adminMessage = e.message ?: "Login gagal." }; adminBusy = false } }, enabled = !adminBusy && adminEmail.contains("@") && adminPassword.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (adminBusy) "Memproses..." else "Login Admin") }
                                } else {
                                    Text("Akses admin aktif di perangkat ini.", color = Muted)
                                    OutlinedButton(onClick = { BeiSongCloud.clearAdminToken(this@MainActivity); adminMessage = "Akses admin dinonaktifkan." }, modifier = Modifier.fillMaxWidth()) { Text("Keluar dari Admin") }
                                }
                                if (adminMessage.isNotBlank()) Text(adminMessage, color = Golden)
                            }
                        } else if (selectedTab == 8) {
                            val searchResults = remember(songs, searchText, searchCategory) {
                                val categorySongs = when (searchCategory) {
                                    "Be.i Song" -> songs.filter { it.album.contains("BEI SONG", ignoreCase = true) || it.artist.contains("Be.i", ignoreCase = true) }
                                    "Global" -> songs.filter { it.album.contains("GLOBAL", ignoreCase = true) }
                                    else -> songs
                                }
                                if (searchText.isBlank()) categorySongs else categorySongs.filter {
                                    it.title.contains(searchText, true) || it.artist.contains(searchText, true) || it.album.contains(searchText, true)
                                }
                            }
                            Column(
                                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                OutlinedTextField(
                                    value = searchText,
                                    onValueChange = { searchText = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    placeholder = { Text("Cari lagu, artis, playlist...", color = Muted) },
                                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Orange) },
                                    shape = RoundedCornerShape(28.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Ink,
                                        unfocusedTextColor = Ink,
                                        cursorColor = Orange,
                                        focusedBorderColor = Orange,
                                        unfocusedBorderColor = Orange.copy(alpha = 0.65f),
                                        focusedContainerColor = CreamCard,
                                        unfocusedContainerColor = CreamCard
                                    )
                                )
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("All Song", "Be.i Song", "Global").forEach { category ->
                                        val active = searchCategory == category
                                        TextButton(
                                            onClick = { searchCategory = category },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(22.dp),
                                            colors = ButtonDefaults.textButtonColors(
                                                containerColor = if (active) Orange else CreamCard,
                                                contentColor = if (active) Color.White else Ink
                                            )
                                        ) {
                                            Text(category, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        }
                                    }
                                }
                                Text("Results", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                if (searchResults.isEmpty()) {
                                    Text(
                                        if (searchCategory == "Global") "Belum ada katalog Global Music yang terhubung." else "Lagu tidak ditemukan.",
                                        color = Muted,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(vertical = 20.dp)
                                    )
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                        searchResults.forEach { song ->
                                            Row(
                                                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                                    .background(CreamCard)
                                                    .clickable { playSong(song, false) }
                                                    .padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                SongArtwork(song, Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)))
                                                Spacer(Modifier.width(11.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Text(song.title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                                val activeSearchSong = currentUri == song.uri && isPlaying
                                                IconButton(onClick = {
                                                    if (currentUri == song.uri && player.currentMediaItem != null) {
                                                        if (player.isPlaying) player.pause() else player.play()
                                                    } else playSong(song, false)
                                                }) {
                                                    Icon(
                                                        if (activeSearchSong) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                                        if (activeSearchSong) "Jeda ${song.title}" else "Putar ${song.title}",
                                                        tint = Golden,
                                                        modifier = Modifier.size(29.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (selectedTab == 3) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("YOUR LIBRARY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("${songs.size} lagu tersimpan", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
                                }
                                TextButton(
                                    onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Upload, null, tint = Orange, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text("Upload", color = Orange, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(8.dp))

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("My Library", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                                if (librarySelectionMode) {
                                    Text("${selectedLibraryUris.size} dipilih", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                } else {
                                    Text("LOCAL", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.width(8.dp))
                                    TextButton(
                                        onClick = { librarySelectionMode = true; selectedLibraryUris = emptySet() },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) { Text("Pilih", color = Muted, fontSize = 12.sp) }
                                }
                            }

                            if (librarySelectionMode) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CreamCard).padding(horizontal = 8.dp, vertical = 3.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    TextButton(
                                        onClick = {
                                            selectedLibraryUris = if (selectedLibraryUris.size == filteredSongs.size) emptySet()
                                            else filteredSongs.map { it.uri }.toSet()
                                        },
                                        modifier = Modifier.weight(1f),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.SelectAll, null, tint = Orange, modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text(if (filteredSongs.isNotEmpty() && selectedLibraryUris.size == filteredSongs.size) "Batal pilih" else "Pilih semua", color = Ink, fontSize = 11.sp)
                                    }
                                    TextButton(
                                        onClick = { if (songs.isNotEmpty()) bulkDeletingSongs = songs },
                                        enabled = filteredSongs.isNotEmpty(),
                                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteSweep, null, tint = Color(0xFFE66A55), modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Hapus semua", color = Color(0xFFE66A55), fontSize = 11.sp)
                                    }
                                    IconButton(onClick = { selectedLibraryUris = emptySet(); librarySelectionMode = false }) {
                                        Icon(Icons.Default.Close, "Batal memilih", tint = Muted)
                                    }
                                }
                                if (selectedLibraryUris.isNotEmpty()) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        TextButton(onClick = {
                                            bulkDeletingSongs = filteredSongs.filter { it.uri in selectedLibraryUris }
                                        }) {
                                            Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFE66A55))
                                            Spacer(Modifier.width(4.dp))
                                            Text("Hapus dipilih (${selectedLibraryUris.size})", color = Color(0xFFE66A55), fontSize = 12.sp)
                                        }
                                    }
                                }
                            }

                            if (filteredSongs.isEmpty()) {
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.LibraryMusic, null, tint = Orange, modifier = Modifier.size(48.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text(if (songs.isEmpty()) "Belum ada lagu" else "Lagu tidak ditemukan", fontWeight = FontWeight.Bold, color = Ink)
                                        Text("Upload MP3 atau audio dari HP kamu.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            } else {
                                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 112.dp)) {
                                    items(filteredSongs, key = { it.uri }) { song ->
                                        val isSelected = song.uri in selectedLibraryUris
                                        ListItem(
                                            modifier = Modifier.combinedClickable(
                                                onClick = {
                                                    if (librarySelectionMode) {
                                                        selectedLibraryUris = if (isSelected) selectedLibraryUris - song.uri else selectedLibraryUris + song.uri
                                                    } else playSong(song)
                                                },
                                                onLongClick = {
                                                    if (!librarySelectionMode) librarySelectionMode = true
                                                    selectedLibraryUris = selectedLibraryUris + song.uri
                                                }
                                            ),
                                            headlineContent = {
                                                Text(song.title, fontWeight = FontWeight.SemiBold, softWrap = true)
                                            },
                                            supportingContent = {
                                                Text("${song.artist} • ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted)
                                            },
                                            leadingContent = {
                                                Box {
                                                    SongArtwork(song = song, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)))
                                                    if (librarySelectionMode && isSelected) {
                                                        Box(Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)).background(Color.Black.copy(alpha = 0.42f)), contentAlignment = Alignment.Center) {
                                                            Icon(Icons.Default.CheckCircle, null, tint = Orange, modifier = Modifier.size(25.dp))
                                                        }
                                                    }
                                                }
                                            },
                                            trailingContent = {
                                                if (librarySelectionMode) {
                                                    Checkbox(
                                                        checked = isSelected,
                                                        onCheckedChange = { checked ->
                                                            selectedLibraryUris = if (checked) selectedLibraryUris + song.uri else selectedLibraryUris - song.uri
                                                        },
                                                        colors = CheckboxDefaults.colors(checkedColor = Orange, uncheckedColor = Muted)
                                                    )
                                                } else {
                                                    var showSongMenu by remember(song.uri) { mutableStateOf(false) }
                                                    Box {
                                                        if (downloadingUri == song.uri) {
                                                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Orange, strokeWidth = 2.dp)
                                                        } else {
                                                            IconButton(onClick = { showSongMenu = true }) {
                                                                Icon(Icons.Default.MoreVert, "Opsi ${song.title}", tint = Muted)
                                                            }
                                                        }
                                                        DropdownMenu(expanded = showSongMenu, onDismissRequest = { showSongMenu = false }) {
                                                            DropdownMenuItem(
                                                                text = { Text(if (downloadedFiles.containsKey(song.uri)) "Hapus unduhan" else "Download") },
                                                                leadingIcon = { Icon(if (downloadedFiles.containsKey(song.uri)) Icons.Default.DownloadDone else Icons.Default.Download, null) },
                                                                onClick = {
                                                                    showSongMenu = false
                                                                    if (downloadedFiles.containsKey(song.uri)) removeOfflineCopy(song) else saveSongOffline(song)
                                                                }
                                                            )
                                                            DropdownMenuItem(
                                                                text = { Text("Edit informasi") },
                                                                leadingIcon = { Icon(Icons.Default.Edit, null) },
                                                                onClick = { showSongMenu = false; openEditor(song) }
                                                            )
                                                            DropdownMenuItem(
                                                                text = { Text("Hapus lagu") },
                                                                leadingIcon = { Icon(Icons.Default.DeleteOutline, null) },
                                                                onClick = { showSongMenu = false; deletingSong = song }
                                                            )
                                                        }
                                                    }
                                                }
                                            },
                                            colors = ListItemDefaults.colors(
                                                containerColor = if (isSelected && librarySelectionMode) CreamCard else Cream
                                            )
                                        )
                                        Divider(color = DividerTone)
                                    }
                                }
                            }
                        } else {
                            if (showLyrics) {
                                FullscreenLyricsScreen(
                                    song = currentSong,
                                    onClose = { showLyrics = false }
                                )
                            } else NowPlayingScreen(
                                song = currentSong,
                                isPlaying = isPlaying,
                                positionMs = positionMs,
                                durationMs = durationMs,
                                shuffleEnabled = shuffleEnabled,
                                repeatMode = repeatMode,
                                onPlayPause = {
                                    if (player.isPlaying) {
                                        player.pause()
                                    } else {
                                        // A selected song can outlive the player's in-memory queue
                                        // when the screen is restored. Rebuild the queue instead of
                                        // silently doing nothing when there is no MediaItem.
                                        if (player.currentMediaItem == null && currentSong != null) {
                                            playSong(currentSong, openPlayer = false)
                                        } else {
                                            if (player.playbackState == Player.STATE_IDLE) player.prepare()
                                            if (player.playbackState == Player.STATE_ENDED) player.seekTo(0L)
                                            player.play()
                                        }
                                    }
                                    isPlaying = player.isPlaying
                                },
                                onPrevious = {
                                    if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                    else if (player.currentMediaItem != null) player.seekTo(0)
                                },
                                onNext = {
                                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                },
                                onSeek = { player.seekTo(it) },
                                onLyrics = { showLyrics = true },
                                onQueue = { showQueueDialog = true },
                                onShuffle = {
                                    shuffleEnabled = !shuffleEnabled
                                    player.shuffleModeEnabled = shuffleEnabled
                                },
                                onRepeat = {
                                    repeatMode = when (repeatMode) {
                                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                        else -> Player.REPEAT_MODE_OFF
                                    }
                                    player.repeatMode = repeatMode
                                }
                            )
                        }

                        Spacer(Modifier.height(8.dp))
                        Text(
                            "v1.6.6 • BESOUND BEI SONG CLOUD",
                            color = Muted,
                            fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp)
                        )
                    }
                }
            }

            if (showQueueDialog) {
                PlaybackQueueDialog(player = player, onDismiss = { showQueueDialog = false })
            }

            if (showExitDialog) {
                AlertDialog(
                    onDismissRequest = { showExitDialog = false },
                    title = { Text("Keluar dari BESOUND?") },
                    text = { Text("Musik yang sedang diputar akan tetap berjalan jika kamu kembali ke aplikasi.") },
                    confirmButton = {
                        TextButton(onClick = { showExitDialog = false; this@MainActivity.finish() }) {
                            Text("Keluar", color = Orange)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showExitDialog = false }) { Text("Tetap di aplikasi") }
                    },
                    containerColor = CreamCard,
                    titleContentColor = Ink,
                    textContentColor = Muted
                )
            }

            if (deletingSong != null) {
                AlertDialog(
                    onDismissRequest = { deletingSong = null },
                    title = { Text("Hapus lagu dari Library?") },
                    text = {
                        Text("${deletingSong?.title.orEmpty()} akan dihapus dari Library BESOUND. File audio asli di HP tetap aman; salinan offline BESOUND akan dibersihkan.")
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val target = deletingSong
                            deletingSong = null
                            if (target != null) removeSongsFromLibrary(listOf(target))
                        }) { Text("Hapus", color = Color(0xFFE05A45)) }
                    },
                    dismissButton = {
                        TextButton(onClick = { deletingSong = null }) { Text("Batal") }
                    }
                )
            }

            if (bulkDeletingSongs.isNotEmpty()) {
                val deletingCount = bulkDeletingSongs.size
                AlertDialog(
                    onDismissRequest = { bulkDeletingSongs = emptyList() },
                    title = { Text(if (deletingCount == songs.size) "Hapus semua lagu?" else "Hapus $deletingCount lagu?") },
                    text = {
                        Text("Lagu yang dipilih akan dihapus dari Library BESOUND. File audio asli di HP tidak dihapus. Salinan unduhan BESOUND juga akan dibersihkan.")
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val targets = bulkDeletingSongs
                            bulkDeletingSongs = emptyList()
                            removeSongsFromLibrary(targets)
                        }) { Text("Hapus", color = Color(0xFFE05A45)) }
                    },
                    dismissButton = {
                        TextButton(onClick = { bulkDeletingSongs = emptyList() }) { Text("Batal") }
                    },
                    containerColor = CreamCard,
                    titleContentColor = Ink,
                    textContentColor = Muted
                )
            }

            if (showEditor && editingSong != null) {
                AlertDialog(
                    onDismissRequest = { showEditor = false; showLyrics = false },
                    title = { Text(if (showLyrics) "Lyrics Studio" else "Edit lagu & lirik") },
                    text = {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!showLyrics) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    SongArtwork(
                                        song = editingSong?.copy(coverUri = editCoverUri),
                                        modifier = Modifier.size(76.dp).clip(RoundedCornerShape(14.dp))
                                    )
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Cover lagu", color = Ink, fontWeight = FontWeight.SemiBold)
                                        TextButton(onClick = { coverPicker.launch(arrayOf("image/*")) }) {
                                            Icon(Icons.Default.Image, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("Pilih dari galeri")
                                        }
                                        if (editCoverUri != null) {
                                            TextButton(onClick = { editCoverUri = null }) {
                                                Text("Hapus cover", color = Muted)
                                            }
                                        }
                                    }
                                }
                                OutlinedTextField(editTitle, { editTitle = it }, label = { Text("Judul lagu") }, singleLine = true)
                                OutlinedTextField(editArtist, { editArtist = it }, label = { Text("Artis") }, singleLine = true)
                                OutlinedTextField(editAlbum, { editAlbum = it }, label = { Text("Album") }, singleLine = true)
                                OutlinedTextField(editMoods, { editMoods = it }, label = { Text("Mood / tag (pisahkan koma)") }, placeholder = { Text("Sendu, Santai, Semangat, Romantis") }, singleLine = true)
                            }
                            OutlinedTextField(
                                editLyrics,
                                { editLyrics = it },
                                label = { Text("Lirik lagu") },
                                minLines = 5,
                                maxLines = 9
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val old = editingSong
                            if (old != null) {
                                scope.launch {
                                    try {
                                        val updated = old.copy(
                                            title = editTitle.trim().ifBlank { "Untitled" },
                                            artist = editArtist.trim().ifBlank { "Unknown artist" },
                                            album = editAlbum.trim().ifBlank { "Unknown album" },
                                            moods = editMoods,
                                            lyrics = editLyrics,
                                            coverUri = editCoverUri
                                        )

                                        val coverChanged = editCoverUri != old.coverUri
                                        val resumeAfterSave =
                                            coverChanged &&
                                                player.currentMediaItem?.mediaId == old.uri &&
                                                player.isPlaying
                                        if (resumeAfterSave) player.pause()

                                        try {
                                            // When the cover changes, write it into the actual MP3
                                            // as an ID3v2 APIC picture frame. The picker requests
                                            // writable document access for this operation.
                                            if (coverChanged) {
                                                withContext(Dispatchers.IO) {
                                                    Mp3ArtworkWriter.embed(
                                                        context = this@MainActivity,
                                                        audioUri = Uri.parse(old.uri),
                                                        coverUri = editCoverUri?.let { Uri.parse(it) },
                                                        title = updated.title,
                                                        artist = updated.artist,
                                                        album = updated.album
                                                    )
                                                }
                                            }

                                            // Only update Room after the MP3 tag write succeeds.
                                            dao.upsert(updated)
                                            val saved = dao.getByUri(old.uri)
                                            check(saved == updated) { "Data lagu belum tersimpan dengan benar." }
                                            // Refresh Media3 and Android media surfaces immediately.
                                            refreshPlayingTrackMetadata(saved!!)
                                            if (resumeAfterSave) player.play()
                                        } catch (saveError: Exception) {
                                            if (resumeAfterSave) player.play()
                                            throw saveError
                                        }
                                        editingSong = dao.getByUri(old.uri) ?: old
                                        showEditor = false
                                        showLyrics = false
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            if (coverChanged) {
                                                "Cover berhasil ditanam ke metadata MP3."
                                            } else {
                                                "Perubahan lagu berhasil disimpan."
                                            },
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } catch (error: Exception) {
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            "Gagal menyimpan: ${error.message ?: "coba lagi"}",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            }
                        }) { Text("Simpan") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditor = false; showLyrics = false }) { Text("Tutup") }
                    }
                )
            }
        }
    }

    private fun displayNameFor(uri: Uri): String {
        var displayName = ""
        runCatching {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (column >= 0) displayName = cursor.getString(column).orEmpty()
                }
            }
        }
        if (displayName.isBlank()) {
            displayName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':').orEmpty()
        }
        val withoutExtension = displayName.substringBeforeLast('.', displayName).trim()
        return withoutExtension.ifBlank { "Untitled" }
    }

    private fun readMetadata(uri: Uri): Triple<String, String, String> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            Triple(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
            )
        } catch (_: Exception) {
            Triple("", "", "")
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Store selected artwork inside app-private storage and return a stable file URI. */
    private fun persistArtwork(source: Uri): Uri? = runCatching {
        val directory = File(filesDir, "track_covers").apply { mkdirs() }
        val mime = contentResolver.getType(source).orEmpty()
        val extension = when {
            mime.contains("png", ignoreCase = true) -> "png"
            mime.contains("webp", ignoreCase = true) -> "webp"
            else -> "jpg"
        }
        val destination = File(directory, "cover_${UUID.randomUUID()}.$extension")
        contentResolver.openInputStream(source)?.use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Tidak bisa membaca foto yang dipilih")
        check(destination.length() > 0L) { "File cover kosong" }
        Uri.fromFile(destination)
    }.getOrNull()

    /** Replace the active media item's metadata so Android refreshes all media surfaces. */
    private fun refreshPlayingTrackMetadata(song: SongEntity) {
        if (!::player.isInitialized) return
        val index = player.currentMediaItemIndex
        val current = player.currentMediaItem ?: return
        if (current.mediaId != song.uri) return
        trackArtworkUris = trackArtworkUris + (song.uri to song.coverUri)
        val metadata = androidx.media3.common.MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
            .apply {
                song.coverUri?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) }
            }
            .build()
        val refreshed = MediaItem.Builder()
            .setMediaId(song.uri)
            .setUri(Uri.parse(song.uri))
            .setMediaMetadata(metadata)
            .build()
        player.replaceMediaItem(index, refreshed)
        // Refresh both media surfaces explicitly: legacy MediaSession metadata for the
        // lock screen and the Media3 notification's cached large icon.
        cachedArtworkUri = null
        cachedArtworkBitmap = null
        cachedEmbeddedArtworkKey = null
        cachedEmbeddedArtworkBitmap = null
        updateCompatMediaSession(forceMetadata = true)
        if (::notificationManager.isInitialized) notificationManager.invalidate()
    }

    /**
     * Resolve the selected cover from Room first. The app editor stores gallery images
     * as private file:// URIs in SongEntity.coverUri; ExoPlayer metadata is not the
     * authoritative store and can be empty or stale after metadata replacement.
     */
    private fun resolveCurrentArtworkUri(mediaPlayer: Player): Uri? {
        val item = mediaPlayer.currentMediaItem
        val mediaId = item?.mediaId
        if (!mediaId.isNullOrBlank() && trackArtworkUris.containsKey(mediaId)) {
            return trackArtworkUris[mediaId]
                ?.takeIf { it.isNotBlank() }
                ?.let(Uri::parse)
        }
        return mediaPlayer.mediaMetadata.artworkUri ?: item?.mediaMetadata?.artworkUri
    }

    /**
     * Decode user-selected cover art at notification-friendly dimensions.
     * Downsampling avoids putting full-resolution phone photos into Android's
     * notification and lock-screen metadata.
     */
    private fun loadArtworkBitmapCached(uri: Uri): android.graphics.Bitmap? {
        val key = uri.toString()
        if (cachedArtworkUri == key) return cachedArtworkBitmap
        val bitmap = loadArtworkBitmap(uri)
        cachedArtworkUri = key
        cachedArtworkBitmap = bitmap
        return bitmap
    }

    /**
     * Read the embedded ID3 album picture directly from the active MP3.
     * This is preferred for notifications and lock-screen metadata, so the
     * Android media surfaces use the artwork that is actually inside the file.
     */
    private fun loadEmbeddedArtworkBitmap(mediaPlayer: Player): android.graphics.Bitmap? {
        val item = mediaPlayer.currentMediaItem ?: return null
        val audioUri = item.localConfiguration?.uri ?: Uri.parse(item.mediaId)
        val key = audioUri.toString()
        if (cachedEmbeddedArtworkKey == key) return cachedEmbeddedArtworkBitmap

        val bitmap = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                if (audioUri.scheme == "file") {
                    retriever.setDataSource(requireNotNull(audioUri.path))
                } else {
                    retriever.setDataSource(this@MainActivity, audioUri)
                }
                val picture = retriever.embeddedPicture ?: return@runCatching null
                val bounds = android.graphics.BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                android.graphics.BitmapFactory.decodeByteArray(picture, 0, picture.size, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

                var sampleSize = 1
                val maxDimension = 512
                while (bounds.outWidth / sampleSize > maxDimension ||
                    bounds.outHeight / sampleSize > maxDimension
                ) sampleSize *= 2

                val options = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                android.graphics.BitmapFactory.decodeByteArray(picture, 0, picture.size, options)
            } finally {
                retriever.release()
            }
        }.getOrNull()

        cachedEmbeddedArtworkKey = key
        cachedEmbeddedArtworkBitmap = bitmap
        return bitmap
    }

    /** Shared default artwork for tracks without their own cover. */
    private var defaultArtworkBitmap: android.graphics.Bitmap? = null

    private fun loadDefaultArtworkBitmap(): android.graphics.Bitmap? {
        if (defaultArtworkBitmap == null) {
            defaultArtworkBitmap = android.graphics.BitmapFactory.decodeResource(
                resources, R.drawable.besound_default_artwork
            )
        }
        return defaultArtworkBitmap
    }

    private fun loadArtworkBitmap(uri: Uri): android.graphics.Bitmap? {
        return runCatching {
            fun openStream() = when (uri.scheme) {
                "file" -> File(requireNotNull(uri.path)).inputStream()
                "http", "https" -> java.net.URL(uri.toString()).openConnection().apply {
                    connectTimeout = 12000
                    readTimeout = 15000
                }.getInputStream()
                else -> contentResolver.openInputStream(uri)
            }

            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            openStream()?.use { stream -> android.graphics.BitmapFactory.decodeStream(stream, null, bounds) }
                ?: return null
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val maxDimension = 512
            var sampleSize = 1
            while (bounds.outWidth / sampleSize > maxDimension ||
                bounds.outHeight / sampleSize > maxDimension
            ) sampleSize *= 2

            val options = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
            }
            openStream()?.use { stream -> android.graphics.BitmapFactory.decodeStream(stream, null, options) }
        }.getOrNull()
    }

    /** Publish artwork/title metadata only when the active track metadata actually changes. */
    private fun updateCompatMediaSession(forceMetadata: Boolean = false) {
        if (!::mediaSession.isInitialized || !::player.isInitialized) return
        val item = player.currentMediaItem
        val artworkUri = resolveCurrentArtworkUri(player)
        val duration = player.duration.takeIf { it > 0L } ?: 0L
        val title = item?.mediaMetadata?.title?.toString() ?: "BESOUND"
        val artist = item?.mediaMetadata?.artist?.toString().orEmpty()
        val album = item?.mediaMetadata?.albumTitle?.toString().orEmpty()
        val mediaId = item?.mediaId.orEmpty()
        val metadataKey = listOf(
            mediaId, title, artist, album, duration.toString(), artworkUri?.toString().orEmpty()
        ).joinToString("\\u001f")

        if (forceMetadata || metadataKey != lastCompatMetadataKey) {
            val metadata = MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, album)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, duration)
                .apply {
                    val artwork = loadEmbeddedArtworkBitmap(player)
                        ?: artworkUri?.let { loadArtworkBitmapCached(it) }
                        ?: loadDefaultArtworkBitmap()
                    if (artwork != null) {
                        putBitmap(MediaMetadataCompat.METADATA_KEY_ART, artwork)
                        putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, artwork)
                        putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, artwork)
                        artworkUri?.toString()?.let { uri ->
                            putString(MediaMetadataCompat.METADATA_KEY_ART_URI, uri)
                            putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, uri)
                            putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON_URI, uri)
                        }
                    }
                }
                .build()
            mediaSession.setMetadata(metadata)
            lastCompatMetadataKey = metadataKey
        }
    }

    /** Playback position/state changes frequently; keep these separate from expensive artwork metadata. */
    private fun updateCompatPlaybackState() {
        if (!::mediaSession.isInitialized || !::player.isInitialized) return
        val actions = PlaybackStateCompat.ACTION_PLAY or
            PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or
            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
            PlaybackStateCompat.ACTION_SEEK_TO or
            PlaybackStateCompat.ACTION_STOP
        val state = when {
            player.isPlaying -> PlaybackStateCompat.STATE_PLAYING
            player.playbackState == Player.STATE_BUFFERING -> PlaybackStateCompat.STATE_BUFFERING
            player.playbackState == Player.STATE_ENDED -> PlaybackStateCompat.STATE_STOPPED
            player.currentMediaItem != null -> PlaybackStateCompat.STATE_PAUSED
            else -> PlaybackStateCompat.STATE_NONE
        }
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, player.currentPosition.coerceAtLeast(0L), if (player.isPlaying) 1f else 0f)
                .build()
        )
    }

    private fun createPlaybackNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                notificationChannelId,
                "BESOUND playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Kontrol pemutaran musik BESOUND"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        if (::notificationManager.isInitialized) notificationManager.setPlayer(null)
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

/**
 * Detect vertical swipes in the Initial pointer pass only on dedicated hint zones.
 * The cover, transport controls, and lyrics scrolling area do not own navigation gestures.
 * Horizontal gestures are deliberately ignored.
 */
private fun Modifier.verticalSwipeGesture(
    onSwipeDown: () -> Unit,
    onSwipeUp: () -> Unit
): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(
            requireUnconsumed = false,
            pass = PointerEventPass.Initial
        )
        var previousY = down.position.y
        var totalY = 0f
        var completed = false
        val threshold = viewConfiguration.touchSlop * 1.5f

        while (!completed) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val change = event.changes.firstOrNull { it.id == down.id }
            if (change == null || !change.pressed) {
                completed = true
            } else {
                val deltaY = change.position.y - previousY
                val deltaX = change.position.x - down.position.x
                previousY = change.position.y
                totalY = change.position.y - down.position.y
                if (abs(totalY) >= threshold && abs(totalY) > abs(deltaX) * 1.2f) {
                    change.consume()
                    // Finger moving down is a swipe-down; finger moving up is a swipe-up.
                    if (totalY > 0f) onSwipeDown() else onSwipeUp()
                    completed = true
                }
            }
        }
    }
}

@Composable
private fun SongArtwork(
    song: SongEntity?,
    modifier: Modifier = Modifier,
    largeFallback: Boolean = false
) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, song?.coverUri) {
        value = null
        val cover = song?.coverUri
        if (!cover.isNullOrBlank()) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val coverUri = Uri.parse(cover)
                    val stream = when (coverUri.scheme) {
                        "http", "https" -> java.net.URL(cover).openConnection().apply {
                            connectTimeout = 12000
                            readTimeout = 15000
                        }.getInputStream()
                        else -> context.contentResolver.openInputStream(coverUri)
                    }
                    stream?.use { input ->
                        val bytes = input.readBytes()
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                        val sample = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 1200)
                        val options = BitmapFactory.Options().apply { inSampleSize = sample }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                    }
                }.getOrNull()
            }
        }
    }
    Box(
        modifier = modifier.background(
            Brush.linearGradient(listOf(Orange, Golden, Color(0xFFFFE2B7)))
        ),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = "Cover ${song?.title.orEmpty()}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (largeFallback) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Headphones, null, tint = Color.White, modifier = Modifier.size(84.dp))
                Text("BESOUND", color = Color.White, fontSize = 22.sp,
                    fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            }
        } else {
            Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun AudioVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = Orange,
    fillBars: Boolean = false
) {
    val transition = rememberInfiniteTransition(label = "audioVisualizer")
    val heights = if (fillBars) {
        listOf(5f, 8f, 12f, 17f, 23f, 28f, 21f, 15f, 10f, 7f, 12f, 18f, 25f, 20f, 14f, 9f,
            6f, 11f, 17f, 24f, 29f, 22f, 16f, 11f, 7f, 13f, 19f, 25f, 18f, 12f, 8f, 5f)
    } else {
        listOf(10f, 19f, 27f, 15f, 24f, 12f, 21f)
    }
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(if (fillBars) 2.dp else 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        heights.forEachIndexed { index, target ->
            val animatedHeight by transition.animateFloat(
                initialValue = 5f,
                targetValue = target,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 300 + (index % 7) * 48, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "visualizerBar$index"
            )
            val visibleHeight = if (isPlaying) animatedHeight else 4f
            Box(
                Modifier
                    .then(if (fillBars) Modifier.weight(1f) else Modifier.width(3.dp))
                    .height(visibleHeight.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                if (fillBars) Golden else barColor,
                                barColor,
                                Color(0xFFB84A12)
                            )
                        )
                    )
            )
        }
    }
}

private fun formatTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0L) / 1000L).toInt()
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

@Composable
private fun ColumnScope.NowPlayingScreen(
    song: SongEntity?, isPlaying: Boolean, positionMs: Long, durationMs: Long,
    shuffleEnabled: Boolean, repeatMode: Int, onPlayPause: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit,
    onShuffle: () -> Unit, onRepeat: () -> Unit, onLyrics: () -> Unit, onQueue: () -> Unit
) {
    BoxWithConstraints(
        Modifier.fillMaxWidth().weight(1f)
    ) {
        val coverSize = minOf(maxWidth * 0.96f, maxHeight * 0.50f, 380.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly) {
            Text("NOW PLAYING", color = Orange, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            SongArtwork(
                song = song,
                modifier = Modifier.size(coverSize).clip(RoundedCornerShape(26.dp)),
                largeFallback = true
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(song?.title ?: "Belum ada lagu dipilih", color = Ink, fontSize = 21.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artist ?: "Pilih lagu dari Library", color = Muted, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Slider(value = positionMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1L).toFloat()),
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(), enabled = durationMs > 0L,
                colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange,
                    inactiveTrackColor = DividerTone))
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(positionMs), color = Muted, fontSize = 11.sp)
                Text(formatTime(durationMs), color = Muted, fontSize = 11.sp)
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.End) {
                    IconButton(onClick = onShuffle, modifier = Modifier.size(42.dp)) {
                        Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffleEnabled) Orange else Muted,
                            modifier = Modifier.size(23.dp))
                    }
                    IconButton(onClick = onPrevious, modifier = Modifier.size(46.dp)) {
                        Icon(Icons.Default.SkipPrevious, "Previous", tint = Ink, modifier = Modifier.size(31.dp))
                    }
                }
                Box(Modifier.width(82.dp), contentAlignment = Alignment.Center) {
                    FilledIconButton(onClick = onPlayPause, enabled = song != null,
                        modifier = Modifier.size(72.dp),
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Orange,
                            contentColor = Color.White, disabledContainerColor = DividerTone,
                            disabledContentColor = Muted)) {
                        Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            "Play atau pause", modifier = Modifier.size(42.dp))
                    }
                }
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Start) {
                    IconButton(onClick = onNext, modifier = Modifier.size(46.dp)) {
                        Icon(Icons.Default.SkipNext, "Next", tint = Ink, modifier = Modifier.size(31.dp))
                    }
                    IconButton(onClick = onRepeat, modifier = Modifier.size(42.dp)) {
                        Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                            "Repeat", tint = if (repeatMode == Player.REPEAT_MODE_OFF) Muted else Orange,
                            modifier = Modifier.size(23.dp))
                    }
                    IconButton(onClick = onQueue, modifier = Modifier.size(38.dp)) {
                        Icon(Icons.Default.QueueMusic, "Antrean lagu", tint = Ink, modifier = Modifier.size(22.dp))
                    }
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 6.dp)
                    .verticalSwipeGesture(onSwipeDown = {}, onSwipeUp = onLyrics),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Default.KeyboardArrowUp,
                    contentDescription = "Geser ke atas untuk membuka lirik",
                    tint = Orange,
                    modifier = Modifier.size(34.dp)
                )
                Text(
                    "SWIPE UP FOR LYRICS",
                    color = Orange,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.8.sp
                )
                Text(
                    "Geser ke atas untuk membuka lirik",
                    color = Muted,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun FullscreenLyricsScreen(song: SongEntity?, onClose: () -> Unit) {
    // Keep the lyrics area dedicated to vertical scrolling. Only the bottom hint
    // region handles the upward navigation gesture, so reading lyrics cannot
    // accidentally close the fullscreen lyrics screen.
    Column(Modifier.fillMaxWidth().fillMaxHeight()
        .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.SpaceBetween) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("LYRICS", color = Orange, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        val lines = song?.lyrics.orEmpty().lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Belum ada lirik untuk lagu ini", color = Muted, fontSize = 18.sp)
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center) {
                lines.forEachIndexed { index, line ->
                    Text(line, color = if (index == 0) Ink else Muted,
                        fontSize = if (index == 0) 25.sp else 20.sp,
                        fontWeight = if (index == 0) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(vertical = 12.dp))
                }
            }
        }
        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)
            .verticalSwipeGesture(onSwipeDown = {}, onSwipeUp = onClose),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(song?.title ?: "BESOUND", color = Ink, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song?.artist ?: "", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                "SWIPE UP TO PLAYER",
                color = Orange,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.8.sp
            )
        }
    }
}

@Composable
private fun MusicVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = Orange,
    barCount: Int = 7,
    maxBarHeight: androidx.compose.ui.unit.Dp = 30.dp
) {
    val transition = rememberInfiniteTransition(label = "besound_equalizer")
    Row(
        modifier = modifier.height(maxBarHeight),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(barCount) { index ->
            val animatedHeight by transition.animateFloat(
                initialValue = 0.18f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 360 + (index % 4) * 115,
                        delayMillis = index * 65,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "equalizer_bar_$index"
            )
            val barFraction = if (isPlaying) animatedHeight else 0.18f
            Box(
                Modifier
                    .width(4.dp)
                    .height(maxBarHeight * barFraction.coerceIn(0.12f, 1f))
                    .clip(CircleShape)
                    .background(barColor)
            )
        }
    }
}

@Composable
private fun HomeShortcut(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean = false,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.width(82.dp).height(86.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(17.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) Orange.copy(alpha = 0.18f) else CreamCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, if (selected) Orange else DividerTone)
    ) {
        Column(Modifier.fillMaxSize().padding(7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = if (selected) Orange else Golden, modifier = Modifier.size(25.dp))
            Spacer(Modifier.height(6.dp))
            Text(title, color = Ink, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun HomeMixCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.height(132.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = CreamCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, DividerTone)
    ) {
        Column(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(CreamCard, Orange.copy(alpha = 0.12f)))).padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Icon(icon, null, tint = Golden, modifier = Modifier.size(25.dp))
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(subtitle, color = Muted, fontSize = 10.sp, lineHeight = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

@Composable
private fun PlaybackQueueDialog(player: ExoPlayer, onDismiss: () -> Unit) {
    var refreshKey by remember { mutableIntStateOf(0) }
    val itemCount = player.mediaItemCount + (refreshKey * 0)
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CreamCard,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Antrean Putar", color = Ink, fontWeight = FontWeight.Bold)
                Text("$itemCount lagu dalam antrean", color = Muted, fontSize = 11.sp)
            }
        },
        text = {
            if (itemCount == 0) {
                Text("Belum ada lagu dalam antrean.", color = Muted)
            } else {
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    repeat(itemCount) { index ->
                        val item = player.getMediaItemAt(index)
                        val isCurrent = index == player.currentMediaItemIndex
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (isCurrent) Orange.copy(alpha = 0.13f) else Cream).padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${index + 1}", color = if (isCurrent) Orange else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.width(22.dp))
                            Column(Modifier.weight(1f).clickable { player.seekTo(index, 0L); player.play(); refreshKey++ }) {
                                Text(item.mediaMetadata.title?.toString().orEmpty().ifBlank { "Tanpa judul" }, color = Ink, fontSize = 12.sp, fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(item.mediaMetadata.artist?.toString().orEmpty(), color = Muted, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { if (index > 0) { player.moveMediaItem(index, index - 1); refreshKey++ } }, enabled = index > 0, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.KeyboardArrowUp, "Pindah ke atas", tint = if (index > 0) Ink else Muted.copy(alpha = 0.35f))
                            }
                            IconButton(onClick = { if (index < player.mediaItemCount - 1) { player.moveMediaItem(index, index + 1); refreshKey++ } }, enabled = index < player.mediaItemCount - 1, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.KeyboardArrowDown, "Pindah ke bawah", tint = if (index < player.mediaItemCount - 1) Ink else Muted.copy(alpha = 0.35f))
                            }
                            IconButton(onClick = { player.removeMediaItem(index); refreshKey++ }, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.Close, "Hapus dari antrean", tint = Muted, modifier = Modifier.size(17.dp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Selesai", color = Orange) } }
    )
}

@Composable
private fun ProfileMenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Orange, modifier = Modifier.size(25.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Icon(Icons.Default.ChevronRight, null, tint = Muted)
    }
}

private fun calculateCacheSize(file: File): Long = runCatching {
    if (!file.exists()) 0L else if (file.isFile) file.length() else file.listFiles()?.sumOf { calculateCacheSize(it) } ?: 0L
}.getOrDefault(0L)

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1024L * 1024L -> "%.1f MB".format(bytes / (1024f * 1024f))
    bytes >= 1024L -> "%.1f KB".format(bytes / 1024f)
    else -> "$bytes B"
}

private class BesoundAudioEffects(sessionId: Int) {
    val equalizer: Equalizer? = runCatching { Equalizer(0, sessionId) }.getOrNull()
    val bassBoost: BassBoost? = runCatching { BassBoost(0, sessionId) }.getOrNull()
    val virtualizer: Virtualizer? = runCatching { Virtualizer(0, sessionId) }.getOrNull()
    val loudness: LoudnessEnhancer? = runCatching { LoudnessEnhancer(sessionId) }.getOrNull()

    fun setBand(index: Int, db: Float) {
        val eq = equalizer ?: return
        runCatching {
            val bands = eq.numberOfBands.toInt()
            if (bands <= 0) return
            val min = eq.bandLevelRange[0].toInt()
            val max = eq.bandLevelRange[1].toInt()
            val target = (db * 100f).toInt().coerceIn(min, max).toShort()
            val centerHz = intArrayOf(31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000)[index]
            val band = (0 until bands).minByOrNull { b -> kotlin.math.abs(eq.getCenterFreq(b.toShort()) / 1000 - centerHz) } ?: 0
            eq.setBandLevel(band.toShort(), target)
        }
    }

    fun setEnabled(enabled: Boolean) { runCatching { equalizer?.enabled = enabled } }
    fun setBass(enabled: Boolean) { runCatching { bassBoost?.apply { if (strengthSupported) setStrength(if (enabled) 650.toShort() else 0.toShort()); this.enabled = enabled } } }
    fun setVirtualizer(enabled: Boolean) { runCatching { virtualizer?.apply { if (strengthSupported) setStrength(if (enabled) 500.toShort() else 0.toShort()); this.enabled = enabled } } }
    fun setLoudness(enabled: Boolean) { runCatching { loudness?.apply { setTargetGain(if (enabled) 350 else 0); this.enabled = enabled } } }
    fun release() { runCatching { equalizer?.release() }; runCatching { bassBoost?.release() }; runCatching { virtualizer?.release() }; runCatching { loudness?.release() } }
}

@Composable
private fun AudioEqualizerScreen(context: Context, audioSessionId: Int, controller: BesoundAudioEffects?) {
    val prefs = remember(context) { context.getSharedPreferences("besound_audio", Context.MODE_PRIVATE) }
    val bandsHz = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")
    val presets = linkedMapOf(
        "Normal" to listOf(0f,0f,0f,0f,0f,0f,0f,0f,0f,0f),
        "Bass Booster" to listOf(5f,6f,5f,3f,1f,0f,0f,0f,1f,1f),
        "Deep Bass" to listOf(7f,7f,5f,3f,0f,-1f,-1f,0f,0f,0f),
        "Pop" to listOf(-1f,1f,3f,4f,2f,0f,1f,2f,2f,1f),
        "Rock" to listOf(4f,3f,-1f,-2f,0f,2f,4f,5f,5f,4f),
        "Classical" to listOf(4f,3f,2f,1f,-1f,-1f,0f,2f,3f,4f),
        "Jazz" to listOf(3f,2f,1f,2f,-2f,-2f,0f,1f,3f,4f),
        "Vocal" to listOf(-2f,-1f,0f,2f,4f,4f,3f,1f,0f,-1f),
        "Acoustic" to listOf(3f,2f,1f,0f,-1f,1f,2f,3f,3f,2f)
    )
    var enabled by remember { mutableStateOf(prefs.getBoolean("eq_enabled", true)) }
    var bass by remember { mutableStateOf(prefs.getBoolean("bass_enabled", false)) }
    var virtual by remember { mutableStateOf(prefs.getBoolean("virtual_enabled", false)) }
    var loud by remember { mutableStateOf(prefs.getBoolean("loud_enabled", false)) }
    var preset by remember { mutableStateOf(prefs.getString("eq_preset", "Normal") ?: "Normal") }
    var values by remember { mutableStateOf((0..9).map { prefs.getFloat("band_$it", 0f) }) }
    var effectAvailable by remember { mutableStateOf(false) }
    LaunchedEffect(controller) {
        effectAvailable = controller?.equalizer != null
        controller?.setEnabled(enabled)
        controller?.setBass(bass)
        controller?.setVirtualizer(virtual)
        controller?.setLoudness(loud)
        values.forEachIndexed { i, v -> controller?.setBand(i, v) }
    }
    fun saveBand(index: Int, value: Float) {
        values = values.toMutableList().also { it[index] = value }
        prefs.edit().putFloat("band_$index", value).apply()
        preset = "Custom"; prefs.edit().putString("eq_preset", "Custom").apply()
        controller?.setBand(index, value)
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text("BESOUND AUDIO ENGINE", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp); Text("Atur karakter suara", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold) }
                    Switch(checked = enabled, onCheckedChange = { enabled = it; prefs.edit().putBoolean("eq_enabled", it).apply(); controller?.setEnabled(it) })
                }
                Text(if (audioSessionId > 0 && effectAvailable) "Equalizer terhubung ke sesi audio BESOUND." else "Efek audio belum tersedia. Mulai putar lagu dan pastikan perangkat mendukung efek audio.", color = Muted, fontSize = 11.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Equalizer 10-band", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = { values = List(10) { 0f }; values.forEachIndexed { i,v -> controller?.setBand(i,v); prefs.edit().putFloat("band_$i",v).apply() }; preset = "Normal"; prefs.edit().putString("eq_preset", "Normal").apply() }) { Text("Reset", color = Orange) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
                    values.forEachIndexed { index, value ->
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("${value.toInt()}", color = Muted, fontSize = 9.sp)
                            VerticalEqSlider(
                                value = value,
                                enabled = enabled && controller?.equalizer != null,
                                onValueChange = { saveBand(index, it) },
                                modifier = Modifier.height(132.dp).width(26.dp)
                            )
                            Text(bandsHz[index], color = Ink, fontSize = 9.sp, maxLines = 1)
                        }
                    }
                }
                Text("Rentang ±12 dB. Jumlah band hardware dapat berbeda antarperangkat; band virtual dipetakan ke frekuensi terdekat yang didukung.", color = Muted, fontSize = 10.sp)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Preset Audio", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                presets.keys.chunked(3).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { name ->
                            val active = preset == name
                            OutlinedButton(
                                onClick = { preset = name; values = presets.getValue(name); values.forEachIndexed { i,v -> controller?.setBand(i,v); prefs.edit().putFloat("band_$i",v).apply() }; prefs.edit().putString("eq_preset", name).apply() },
                                modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                                colors = ButtonDefaults.outlinedButtonColors(containerColor = if (active) Orange.copy(alpha = 0.18f) else Cream)
                            ) { Text(name, color = if (active) Orange else Ink, fontSize = 10.sp, maxLines = 1) }
                        }
                    }
                }
                if (preset == "Custom") Text("Custom", color = Orange, fontWeight = FontWeight.Bold)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(horizontal = 14.dp)) {
                Text("Efek Audio", color = Ink, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
                AudioEffectToggle("Bass Boost", "Memperkuat frekuensi rendah", bass, controller?.bassBoost != null) { bass = it; prefs.edit().putBoolean("bass_enabled", it).apply(); controller?.setBass(it) }
                Divider(color = DividerTone)
                AudioEffectToggle("Virtualizer", "Efek ruang/spasial jika didukung", virtual, controller?.virtualizer != null) { virtual = it; prefs.edit().putBoolean("virtual_enabled", it).apply(); controller?.setVirtualizer(it) }
                Divider(color = DividerTone)
                AudioEffectToggle("Loudness Enhancement", "Menaikkan gain output audio", loud, controller?.loudness != null) { loud = it; prefs.edit().putBoolean("loud_enabled", it).apply(); controller?.setLoudness(it) }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun VerticalEqSlider(value: Float, enabled: Boolean, onValueChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    Canvas(
        modifier = modifier
            .pointerInput(enabled) {
                if (enabled) detectTapGestures { point ->
                    val fraction = (point.y / size.height).coerceIn(0f, 1f)
                    onValueChange((12f - fraction * 24f).coerceIn(-12f, 12f))
                }
            }
            .pointerInput(enabled) {
                if (enabled) detectDragGestures { change, _ ->
                    val fraction = (change.position.y / size.height).coerceIn(0f, 1f)
                    onValueChange((12f - fraction * 24f).coerceIn(-12f, 12f))
                    change.consume()
                }
            }
    ) {
        val x = size.width / 2f
        val top = 5f
        val bottom = size.height - 5f
        val thumbY = top + ((12f - value) / 24f) * (bottom - top)
        drawLine(DividerTone, androidx.compose.ui.geometry.Offset(x, top), androidx.compose.ui.geometry.Offset(x, bottom), 5f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        drawLine(Orange, androidx.compose.ui.geometry.Offset(x, bottom), androidx.compose.ui.geometry.Offset(x, thumbY), 5f, cap = androidx.compose.ui.graphics.StrokeCap.Round)
        drawCircle(if (enabled) Ink else Muted, radius = 7f, center = androidx.compose.ui.geometry.Offset(x, thumbY))
        drawCircle(Orange, radius = 4f, center = androidx.compose.ui.geometry.Offset(x, thumbY))
    }
}

@Composable
private fun AudioEffectToggle(title: String, subtitle: String, checked: Boolean, available: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(if (available) subtitle else "$subtitle • tidak didukung perangkat", color = Muted, fontSize = 10.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = available)
    }
}

@Composable
private fun MiniPlayer(
    song: SongEntity?,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onOpen: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CreamCard),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(enabled = song != null) { onOpen() }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SongArtwork(song = song, modifier = Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)))
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song?.title ?: "Belum ada lagu diputar",
                    color = Ink,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    song?.artist ?: "Pilih lagu dari Library",
                    color = Muted,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(5.dp))
                val progress = if (durationMs > 0L) {
                    (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                } else 0f
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(CircleShape)
                        .background(DividerTone)
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(progress)
                            .height(3.dp)
                            .clip(CircleShape)
                            .background(Orange)
                    )
                }
            }
            if (song != null) {
                IconButton(onClick = onPrevious, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Lagu sebelumnya", tint = Ink, modifier = Modifier.size(25.dp))
                }
                IconButton(onClick = onPlayPause, modifier = Modifier.size(42.dp)) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play atau pause", tint = Orange, modifier = Modifier.size(30.dp)
                    )
                }
                IconButton(onClick = onNext, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Default.SkipNext, "Lagu berikutnya", tint = Ink, modifier = Modifier.size(25.dp))
                }
            } else {
                Text("Pilih lagu", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}


