create table if not exists public.user_playlists (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null check (char_length(trim(name)) between 1 and 80),
  description text not null default '' check (char_length(description) <= 500),
  cover_path text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists user_playlists_owner_updated_idx on public.user_playlists(owner_id, updated_at desc);
create table if not exists public.user_playlist_tracks (
  id uuid primary key default gen_random_uuid(),
  playlist_id uuid not null references public.user_playlists(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  song_id bigint references public.songs(id) on delete set null,
  title text not null,
  artist text not null default 'Unknown artist',
  audio_url text not null,
  cover_url text,
  position integer not null default 0,
  added_at timestamptz not null default now()
);
create index if not exists user_playlist_tracks_playlist_position_idx on public.user_playlist_tracks(playlist_id, position, added_at);
create table if not exists public.playlist_shares (
  id uuid primary key default gen_random_uuid(),
  playlist_id uuid not null references public.user_playlists(id) on delete cascade,
  owner_id uuid not null references auth.users(id) on delete cascade,
  token_hash text not null unique,
  created_at timestamptz not null default now(),
  revoked_at timestamptz
);
alter table public.user_playlists enable row level security;
alter table public.user_playlist_tracks enable row level security;
alter table public.playlist_shares enable row level security;
create policy "Owners can read their playlists" on public.user_playlists for select to authenticated using ((select auth.uid()) = owner_id);
create policy "Owners can create their playlists" on public.user_playlists for insert to authenticated with check ((select auth.uid()) = owner_id);
create policy "Owners can update their playlists" on public.user_playlists for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id);
create policy "Owners can delete their playlists" on public.user_playlists for delete to authenticated using ((select auth.uid()) = owner_id);
create policy "Owners can read their playlist tracks" on public.user_playlist_tracks for select to authenticated using ((select auth.uid()) = owner_id);
create policy "Owners can add their playlist tracks" on public.user_playlist_tracks for insert to authenticated with check ((select auth.uid()) = owner_id and exists (select 1 from public.user_playlists p where p.id = playlist_id and p.owner_id = (select auth.uid())));
create policy "Owners can update their playlist tracks" on public.user_playlist_tracks for update to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id and exists (select 1 from public.user_playlists p where p.id = playlist_id and p.owner_id = (select auth.uid())));
create policy "Owners can delete their playlist tracks" on public.user_playlist_tracks for delete to authenticated using ((select auth.uid()) = owner_id);
create policy "Owners manage playlist shares" on public.playlist_shares for all to authenticated using ((select auth.uid()) = owner_id) with check ((select auth.uid()) = owner_id and exists (select 1 from public.user_playlists p where p.id = playlist_id and p.owner_id = (select auth.uid())));
grant select, insert, update, delete on public.user_playlists, public.user_playlist_tracks, public.playlist_shares to authenticated;
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('playlist-covers', 'playlist-covers', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = false, file_size_limit = 5242880, allowed_mime_types = array['image/jpeg','image/png','image/webp'];
create policy "Playlist cover owners can view" on storage.objects for select to authenticated using (bucket_id = 'playlist-covers' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "Playlist cover owners can upload" on storage.objects for insert to authenticated with check (bucket_id = 'playlist-covers' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "Playlist cover owners can update" on storage.objects for update to authenticated using (bucket_id = 'playlist-covers' and (storage.foldername(name))[1] = (select auth.uid())::text) with check (bucket_id = 'playlist-covers' and (storage.foldername(name))[1] = (select auth.uid())::text);
create policy "Playlist cover owners can delete" on storage.objects for delete to authenticated using (bucket_id = 'playlist-covers' and (storage.foldername(name))[1] = (select auth.uid())::text);
create or replace function public.get_shared_playlist(p_token text)
returns jsonb language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'playlist', jsonb_build_object('id', p.id, 'name', p.name, 'description', p.description, 'created_at', p.created_at),
    'tracks', coalesce((select jsonb_agg(jsonb_build_object('title', t.title, 'artist', t.artist, 'audio_url', t.audio_url, 'cover_url', t.cover_url) order by t.position, t.added_at) from public.user_playlist_tracks t where t.playlist_id = p.id), '[]'::jsonb)
  )
  from public.playlist_shares s join public.user_playlists p on p.id = s.playlist_id
  where s.token_hash = encode(extensions.digest(p_token, 'sha256'), 'hex') and s.revoked_at is null limit 1;
$$;
revoke all on function public.get_shared_playlist(text) from public;
grant execute on function public.get_shared_playlist(text) to anon, authenticated;
