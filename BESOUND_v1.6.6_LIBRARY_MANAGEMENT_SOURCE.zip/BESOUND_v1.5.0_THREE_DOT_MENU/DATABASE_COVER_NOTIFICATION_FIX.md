# BESOUND v1.1.4 notification artwork source patch

## Root cause addressed
The editor saves selected gallery covers in `SongEntity.coverUri` in the Room database as app-private `file://` URIs. The notification and compatibility media-session code previously relied primarily on ExoPlayer's `MediaMetadata.artworkUri`. That metadata can be absent or stale even while the Compose UI correctly displays the database cover.

## Changes
- Treat the Room cover URI as the authoritative artwork source for tracks known to the local library.
- For a known track with a saved cover, load that selected cover for the notification and lock screen.
- For a known track without a cover, use the BESOUND mascot fallback and do not reuse stale ExoPlayer artwork.
- Refresh notification and MediaSession artwork when Room emits updated song data and immediately after saving an edited active track.
- Avoid writing the literal string `null` into MediaSession artwork URI metadata when the fallback bitmap is used.

## Preserved
- Package ID: `com.bei.besound`
- Room database name and schema version: `bei_music.db`, version 2
- Existing songs, lyrics, and stored cover files
- Release signing configuration and GitHub Secrets names

## Version
- versionName: 1.1.4
- versionCode: 15

## Verification status
The ZIP structure and artwork PNG are checked. The Kotlin changes have been source-inspected but not compiled in this environment. A green GitHub Actions run and a device test are still required before treating the APK as verified.
