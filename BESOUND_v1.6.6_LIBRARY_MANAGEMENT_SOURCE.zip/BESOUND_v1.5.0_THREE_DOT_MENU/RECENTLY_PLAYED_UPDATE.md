# BESOUND v1.3.8 - Recently Played Home Update

- Home Recently Played now uses persistent playback history, not the first songs in the local library.
- Playback history stores the latest 10 unique track URIs in app preferences and updates when a track is selected or Media3 transitions to another track (including next/previous).
- Home shows the most recent four tracks with play/pause icon reflecting the active track state.
- Lihat Semua opens a dedicated Recently Played page listing up to 10 latest tracks.
- Selecting a row starts that track; the trailing control toggles play/pause for the active track.
- Back from Recently Played returns to Home.
- Existing package ID and signing configuration are unchanged.
