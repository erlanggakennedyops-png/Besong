# BESOUND v1.6.6 – Library Management Update

- Consolidated the Library upload actions into one Upload button.
- Removed the redundant All Songs / Downloaded filter strip from the Library screen.
- Reduced vertical spacing so the song list appears higher on screen.
- Added long-press multi-select for Library tracks.
- Added Select All, Delete Selected, and Delete All actions.
- Added a confirmation dialog before bulk deletion.
- Bulk deletion removes tracks from the BESOUND Room Library and cleans BESOUND-created offline copies; original source audio files are not deleted.
- Preserved the existing package ID, database, cloud integrations, and player implementation.
