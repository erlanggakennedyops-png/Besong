# BESOUND v1.1.2 notification artwork patch

## What changed
- Force `PlayerNotificationManager.invalidate()` after a media-item transition and after player metadata changes.
- Force a notification refresh after the currently playing song's metadata/cover is replaced in the editor.
- Clear the in-memory artwork cache when the active song's cover is replaced.
- Resolve the active artwork URI from `player.mediaMetadata` first, then the current media item's metadata, both in the notification adapter and compatibility media-session metadata.

## Important verification status
This is a source patch only. It has been checked for the intended code changes and archive integrity, but it has **not** been compiled or run on an Android device in this environment because no Gradle wrapper, Gradle installation, or Android SDK is available here. Do not install it as an APK; there is no APK in this patch archive. Build it with the project's GitHub Actions workflow before installing.
