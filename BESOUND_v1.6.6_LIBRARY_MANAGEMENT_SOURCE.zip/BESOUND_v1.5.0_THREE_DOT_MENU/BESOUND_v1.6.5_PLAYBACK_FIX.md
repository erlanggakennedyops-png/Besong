# BESOUND v1.6.5 - Playback & Player Layout Fix

- Rebuilds the selected local track queue if the Now Playing screen has a selected song but the ExoPlayer queue is empty.
- Calls prepare() when playback is resumed from IDLE and seeks to the start after ENDED.
- Displays a readable playback error toast instead of silently leaving the player at 0:00.
- Centers the primary Play/Pause button in a balanced three-zone control row.
- Keeps existing Media3 ExoPlayer, queue, lyrics swipe, artwork, and Golden Dusk UI.

Version code: 58. Version name: 1.6.5.
