# BESOUND v1.6.3 - Global Music without mandatory API key

- Removed the GitHub Actions gate that required AUDIUS_API_KEY.
- Audius read-only search now sends x-api-key only when an optional key is configured.
- Removed the in-app warning that blocked Global Music when the key was absent.
- Kept Audius search and streaming connected to the existing Media3 player.
- Version code: 56; version name: 1.6.3.

Note: Audius read-only endpoints may work without credentials, but rate limits or provider policy can change. Verify search and streaming on a real device after installing the APK.
