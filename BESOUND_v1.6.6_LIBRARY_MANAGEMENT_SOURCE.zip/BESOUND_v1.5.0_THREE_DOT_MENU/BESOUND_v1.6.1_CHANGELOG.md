# BESOUND v1.6.1 – Home Visual Refresh

- Reworked Home around a dynamic Now Playing card using the active track artwork with a softened/blurred background.
- Kept the Bei robot greeting card and removed its decorative waveform.
- Added image-led BEI SONG and GLOBAL SONG destinations above the main player.
- Added a Home player connected to the existing Media3 player state, including play/pause, seek, shuffle, previous/next, repeat, favorite, and queue.
- Hid the duplicate bottom mini-player on Home; it remains available on other tabs while music is playing.
- Kept existing catalog, playlist, library, favorites, history, and Supabase code in place.
