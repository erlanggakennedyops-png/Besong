BESOUND v1.3.8 - Mini Player update

- Mini player appears on non-Home screens while a track is active.
- Hidden on Home and on the full Music Player screen.
- Shows artwork, title, artist, playback progress, previous, play/pause, next.
- Tap the mini player body to open the full Music Player.
- Playback progress uses the existing player position/duration state.

Package ID remains com.bei.besound. Version code 39, version name 1.3.8.
