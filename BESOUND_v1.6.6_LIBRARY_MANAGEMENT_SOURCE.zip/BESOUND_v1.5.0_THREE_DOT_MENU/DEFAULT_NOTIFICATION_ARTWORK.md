# BESOUND v1.1.3 default notification artwork

- Adds the supplied BESOUND mascot image as `res/drawable-nodpi/besound_default_artwork.png`.
- PlayerNotificationManager uses the track-specific cover when available; otherwise it falls back to the BESOUND mascot image.
- MediaSessionCompat metadata uses the same fallback bitmap, so Android lock-screen media controls receive artwork for tracks without a custom cover.
- If a track cover URI exists but cannot be decoded, the notification adapter also falls back to the mascot image.
- Version bumped to 1.1.3 (versionCode 14) so it can update an installed v1.1.2 app without changing applicationId or signing identity.

This is a source change. It must still be built and tested on an Android device.
