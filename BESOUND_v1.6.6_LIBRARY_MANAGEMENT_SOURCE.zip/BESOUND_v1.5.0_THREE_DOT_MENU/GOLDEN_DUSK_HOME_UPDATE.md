# BESOUND v1.1.7 — Golden Dusk Home

## Changes
- Redesigned Home with a warm Golden Dusk palette and softly animated gradient atmosphere.
- Added Featured Today card using the current track or first available local track.
- Added Quick Access: Bei Song, Global Music, My Library, and Playlists.
- Added horizontal track cards and Made for Your Mood cards: Sad, Lovely, Chill, Ironic.
- Preserved the existing Room database, ExoPlayer playback, MediaSession, and notification artwork implementation.
- Bumped Android version to 1.1.7 (versionCode 18).

## Important behavior notes
- The mood shelves are currently visual curated-category cards. The project does not yet contain a persisted owner-curated playlist/category data model or account-based owner permissions, so add/edit/reorder/playlist membership is not implemented by this visual update.
- The Recently Played row currently displays the active track first followed by other local library tracks; there is no persistent playback-history table in this project yet.
- The Playlists shortcut currently opens My Library because a dedicated playlist screen/data model is not present in this source.
