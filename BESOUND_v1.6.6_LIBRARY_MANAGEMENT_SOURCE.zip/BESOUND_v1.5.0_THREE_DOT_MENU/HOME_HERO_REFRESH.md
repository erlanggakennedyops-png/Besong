# BESOUND v1.3.8 Home Hero Refresh

- Adds a cinematic sunset welcome card above the BESOUND signature branding.
- Uses the existing `home_sunset.jpg` artwork with a dark horizontal overlay for readable text.
- Adds a gold `YOUR DAILY SOUND` label, welcoming headline, and animated audio visualizer.
- Designed to fill the large empty upper region without removing or replacing existing Home sections.
- Existing player controls, navigation, recent history, and mini-player behavior are retained.
- Package ID remains `com.bei.besound`; versionCode 39; versionName 1.3.8.

Source-only update; build must be verified through GitHub Actions.
