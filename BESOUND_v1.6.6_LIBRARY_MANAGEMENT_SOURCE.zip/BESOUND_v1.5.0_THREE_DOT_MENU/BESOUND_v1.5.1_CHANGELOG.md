# BESOUND v1.5.1

- Redesigned Profile as the account and settings hub while preserving Supabase playlist login and admin access.
- Added dedicated application settings sections for audio, storage/cache, notifications, network/data, privacy/security, and app information.
- Added Android audio-session Equalizer controls, presets, Bass Boost, Virtualizer, and Loudness Enhancement where supported by the device.
- Moved Mini Player into the persistent bottom bar so it remains visible across tabs while a track is active.
- Added a full-width home search field and localized search prompt.
- Unified home/player/search surfaces with the active Golden Dusk, Cream Light, or Midnight palette.
- Increased versionCode to 52 and versionName to 1.5.1.

Audio effect availability depends on the Android device and active ExoPlayer audio session. The ten visible EQ controls map to the nearest frequency bands exposed by the device audio effect.
