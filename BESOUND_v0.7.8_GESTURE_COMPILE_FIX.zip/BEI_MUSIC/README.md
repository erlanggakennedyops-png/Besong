# BESOUND Android v0.7.8 — Gesture Compile Fix

Golden Dusk Android music app.

## Changes in v0.7.8
- Fixed Kotlin compile error by removing the invalid top-level `awaitPointerEvent` import. The call is resolved as the `AwaitPointerEventScope` member inside `awaitEachGesture`.
- Kept vertical swipe detection on the Initial pointer pass for Now Playing and Fullscreen Lyrics.
- Swipe down on Now Playing opens fullscreen Lyrics; swipe up on Lyrics returns to Now Playing.
- No lyrics icon or button is added.
- Updated Android version to 0.7.8 (versionCode 12) and GitHub Actions artifact name to `BESOUND-v0.7.8-APK`.

## Build
Run `gradle --no-daemon assembleDebug` from the project root, or push to GitHub Actions.

Build and on-device gesture behavior must still be verified by GitHub Actions and on a physical Android device.
