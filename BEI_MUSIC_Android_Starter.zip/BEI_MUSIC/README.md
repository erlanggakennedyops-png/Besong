# BE.I MUSIC — Android Native Starter

Starter project Android native menggunakan Kotlin + Jetpack Compose + AndroidX Media3.

## Tahap 1 yang sudah disiapkan
- Tampilan awal BE.I MUSIC (warm cream/orange/golden).
- Memilih beberapa file audio dari perangkat melalui Android file picker.
- Daftar lagu lokal.
- Pemutaran audio dasar dengan ExoPlayer.
- Panel untuk mengetik lirik (belum disimpan permanen).

## Arsitektur target untuk pilihan BOTH
- Local: file audio tetap berada di perangkat pengguna; metadata dan lirik akan disimpan di Room.
- Cloud: file dan metadata disinkronkan ke backend (misalnya Supabase Storage + database) pada tahap berikutnya.
- Offline: lagu yang sudah diunduh tetap dapat diputar tanpa internet.

## Cara build
1. Ekstrak ZIP.
2. Buka folder `BEI-MUSIC` di Android Studio.
3. Gunakan JDK 17 dan Android Gradle Plugin 8.7.3.
4. Tunggu Gradle Sync, lalu Run pada perangkat/emulator Android.

Catatan: proyek ini adalah starter source code, bukan APK yang sudah dikompilasi. Build APK memerlukan Android build environment. Untuk workflow HP saja, kita perlu gunakan IDE Android di HP yang mendukung proyek Gradle/Kotlin atau layanan build cloud.

## Tahap berikutnya
1. Tambahkan Room DAO/entity untuk lagu dan lirik permanen.
2. Tambahkan editor cover, artis, judul, dan file `.lrc` untuk lirik bertimestamp.
3. Tambahkan background playback + media notification + kontrol lock screen.
4. Hubungkan Supabase Auth, Database, dan Storage untuk sinkronisasi cloud.
