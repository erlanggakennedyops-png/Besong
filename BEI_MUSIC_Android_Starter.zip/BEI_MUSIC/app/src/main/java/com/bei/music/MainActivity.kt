package com.bei.music

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

private val Cream = Color(0xFFFFF8ED)
private val Orange = Color(0xFFE58B3A)
private val Ink = Color(0xFF33291F)

data class Track(val title: String, val uri: Uri, val lyrics: String = "")

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            var tracks by remember { mutableStateOf(listOf<Track>()) }
            var current by remember { mutableIntStateOf(-1) }
            var playing by remember { mutableStateOf(false) }
            var lyrics by remember { mutableStateOf("") }
            var showLyrics by remember { mutableStateOf(false) }

            val audioPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenMultipleDocuments()
            ) { uris ->
                val added = uris.map { uri ->
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                    Track(title = uri.lastPathSegment?.substringAfterLast('/') ?: "Untitled", uri = uri)
                }
                tracks = tracks + added
            }

            MaterialTheme(colorScheme = lightColorScheme(
                primary = Orange, background = Cream, surface = Cream,
                onBackground = Ink, onSurface = Ink
            )) {
                Surface(Modifier.fillMaxSize(), color = Cream) {
                    Column(Modifier.fillMaxSize().padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("BE.I MUSIC", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink)
                                Text("Your music. Your lyrics. Your world.", color = Color(0xFF8B7866), fontSize = 12.sp)
                            }
                            Icon(Icons.Default.Headphones, null, tint = Orange, modifier = Modifier.size(34.dp))
                        }
                        Spacer(Modifier.height(24.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE8CC)),
                            shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("YOUR LIBRARY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("${tracks.size} lagu tersimpan", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                                    Icon(Icons.Default.Upload, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Upload musik")
                                }
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("My Library", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("LOCAL", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        if (tracks.isEmpty()) {
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.LibraryMusic, null, tint = Orange, modifier = Modifier.size(48.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("Belum ada lagu", fontWeight = FontWeight.Bold)
                                    Text("Upload file MP3 atau audio dari HP kamu.", color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                        } else {
                            LazyColumn(Modifier.weight(1f)) {
                                items(tracks) { track ->
                                    ListItem(
                                        headlineContent = { Text(track.title, fontWeight = FontWeight.SemiBold) },
                                        supportingContent = { Text("Audio dari perangkat") },
                                        leadingContent = { Icon(Icons.Default.MusicNote, null, tint = Orange) },
                                        trailingContent = {
                                            IconButton(onClick = {
                                                current = tracks.indexOf(track)
                                                player.setMediaItem(MediaItem.fromUri(track.uri))
                                                player.prepare()
                                                player.play()
                                                playing = true
                                            }) { Icon(Icons.Default.PlayArrow, null, tint = Orange) }
                                        }
                                    )
                                    HorizontalDivider(color = Color(0xFFEFE2D2))
                                }
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF33291F)),
                            shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text(if (current in tracks.indices) tracks[current].title else "Pilih lagu untuk diputar",
                                    color = Color.White, fontWeight = FontWeight.Bold)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        if (current in tracks.indices) {
                                            if (player.isPlaying) { player.pause(); playing = false }
                                            else { player.play(); playing = true }
                                        }
                                    }) {
                                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            null, tint = Color.White)
                                    }
                                    Text(if (playing) "Sedang diputar" else "Player siap", color = Color(0xFFFFD7A8), modifier = Modifier.weight(1f))
                                    TextButton(onClick = { showLyrics = !showLyrics }) {
                                        Text("LYRICS", color = Color(0xFFFFD7A8))
                                    }
                                }
                                if (showLyrics) {
                                    OutlinedTextField(
                                        value = lyrics, onValueChange = { lyrics = it },
                                        modifier = Modifier.fillMaxWidth(),
                                        label = { Text("Tulis lirik lagu", color = Color.White) },
                                        minLines = 3,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                            focusedBorderColor = Orange, unfocusedBorderColor = Color.Gray,
                                            focusedLabelColor = Color(0xFFFFD7A8), unfocusedLabelColor = Color.LightGray
                                        )
                                    )
                                    Text("Tahap awal: lirik bisa ditulis di layar. Penyimpanan permanen lirik dan sinkronisasi cloud masuk tahap berikutnya.",
                                        color = Color.LightGray, fontSize = 10.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Tahap 1 • Pemilih file & pemutar lokal • Cloud sync menyusul",
                            color = Color(0xFF9B8977), fontSize = 10.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
