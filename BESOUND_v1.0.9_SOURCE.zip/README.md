# BESOUND v1.0.9

Android source project for package `com.bei.besound`.

## Version
- versionCode: 10
- versionName: 1.0.9
- Database: Room schema version 2 (unchanged; no destructive migration)

## Changes in 1.0.9
- Replace Android launcher icon density assets with the user-provided BESOUND headphone-face logo.
- Retain the v1.0.8 Media3/MediaSession artwork integration for track covers in media notifications and lock-screen metadata.
- Preserve applicationId `com.bei.besound`, Room database, and signing configuration.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change `applicationId` or release keystore for updates.
