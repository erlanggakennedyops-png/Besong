# BESOUND v1.1.9

Android source project for package `com.bei.besound`.

## Version
- versionCode: 15
- versionName: 1.1.4
- Room database schema: version 2 (unchanged; no destructive migration)

## Changes in 1.1.2
- Cache decoded cover artwork by its persisted private URI, avoiding repeated image decoding during playback updates.
- Read `file://` cover images directly from the app-private file path and continue supporting content URIs.
- Publish MediaSession artwork metadata only when track metadata or duration changes.
- Separate frequent playback-position/state updates from artwork metadata updates.
- Refresh active-track metadata after editing a song, including a newly selected cover.
- Keep Media3 ExoPlayer, PlayerNotificationManager, MediaSessionCompat, package ID, database, stored songs, launcher icon, and release signing configuration.

## Important verification note
The source archive and workflow include structural checks. A signed APK is only considered verified after GitHub Actions completes the Gradle build, signature check, and package/version check successfully.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change `applicationId` or release keystore for updates.

## Changes in 1.1.4
- Resolve the active track's selected cover from the Room database first for notification and lock-screen artwork.
- Treat a known track with an empty coverUri as intentionally having no custom cover, so BESOUND default artwork is used instead of stale player metadata.
- Refresh media artwork when Room emits updated song records and immediately after the active song is edited.
- Keep the existing database schema (version 2), package ID, and release signing configuration unchanged.

## Verification
- Source archive integrity and PNG artwork decoding were checked.
- Kotlin source changes were inspected, but a signed APK has not been built or device-tested yet. GitHub Actions must pass before installation.


## v1.1.8 — Home refresh

- Home now uses a dedicated **NOW** player card with shuffle, previous, play/pause, next, repeat, and seek controls.
- Added animated audio visualizer bars that animate during playback and settle when paused.
- Replaced the four small Home shortcuts with two large image cards: **BEI SONG** and **GLOBAL MUSIC**.
- BEI SONG uses the supplied masked-artist reference photo; GLOBAL MUSIC uses the approved cinematic city image.
- Removed the old Featured Today label and mood shelf from the Home layout.
- Recently Played is shown as compact vertical rows.
- Bottom navigation is now Home, Playlist, Library, Profile.
- BEI SONG and GLOBAL MUSIC are opened from their Home cards, not from bottom navigation.
- The mini-player is hidden on Home (NOW already has full controls) and appears on other app pages when a track is active.
- Package ID remains `com.bei.besound`; versionCode 20; versionName 1.1.9.

The Playlist destination is a placeholder screen because persistent playlist creation/storage is not part of this UI refresh. Existing Room library, player, notification, MediaSession, and artwork code are retained.


## v1.1.9 — Kotlin compile fixes
- Corrected AudioVisualizer animation spec to use an infinite Float animation and a paused visual height.
- Added the missing @Composable annotation to NowPlayingScreen.
- Removed the duplicate formatTime(Long) overload that caused conflicting overload resolution.
- Package ID, Room schema, existing player, notification, artwork and signing configuration are retained.
