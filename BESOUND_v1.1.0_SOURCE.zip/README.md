# BESOUND v1.1.0

Android source project for package `com.bei.besound`.

## Version
- versionCode: 11
- versionName: 1.1.0
- Database: Room schema version 2 (unchanged; no destructive migration)

## Changes in 1.1.0
- Copy selected track cover images into BESOUND private app storage, so covers do not depend on the original gallery file remaining available.
- Refresh the currently playing Media3 item after saving track metadata, including cover artwork.
- Refresh MediaSession metadata and invalidate the playback notification after a cover edit so Android notification and lock-screen surfaces receive the new image.
- Correct the in-app footer version label to 1.1.0.
- Preserve applicationId `com.bei.besound`, existing database, launcher icon, and release signing configuration.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change `applicationId` or release keystore for updates.
