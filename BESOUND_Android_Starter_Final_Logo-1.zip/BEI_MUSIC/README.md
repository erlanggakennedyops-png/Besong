# BESOUND v0.2 Android Native Starter

Kotlin + Jetpack Compose + Media3 + Room.

## v0.2
- Import multiple audio files using Android document picker.
- Read embedded audio title, artist and album metadata where available.
- Persist library metadata and lyrics locally with Room database.
- Edit title, artist, album and lyrics for each track.
- Basic ExoPlayer playback.

## Important
- This version stores song metadata and lyrics locally. It does not upload audio to cloud yet.
- The selected audio files remain in their original device/document-provider locations; persistable URI access is requested.
- Cloud sync, album artwork editing, timed LRC lyrics, background playback and media notification are future stages.

## Build
Open with Android Studio, JDK 17, Android Gradle Plugin 8.7.3. The GitHub Actions workflow in the repository builds a debug APK.


## BESOUND branding update
- App display name: BESOUND
- Launcher icon: custom smiling X-mask + headphones artwork
- Existing applicationId retained as `com.bei.music` to avoid changing app identity during this branding update.
