package com.bei.music

import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.launch

private val Cream = Color(0xFFFFF8ED)
private val Orange = Color(0xFFE58B3A)
private val Ink = Color(0xFF33291F)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        val dao = MusicDatabase.get(this).songDao()

        setContent {
            val scope = rememberCoroutineScope()
            val songs by dao.observeAll().collectAsState(initial = emptyList())
            var currentUri by remember { mutableStateOf<String?>(null) }
            var playing by remember { mutableStateOf(false) }
            var showEditor by remember { mutableStateOf(false) }
            var editingSong by remember { mutableStateOf<SongEntity?>(null) }
            var editTitle by remember { mutableStateOf("") }
            var editArtist by remember { mutableStateOf("") }
            var editAlbum by remember { mutableStateOf("") }
            var editLyrics by remember { mutableStateOf("") }

            val audioPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenMultipleDocuments()
            ) { uris ->
                uris.forEach { uri ->
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                    val metadata = readMetadata(uri)
                    scope.launch {
                        dao.upsert(
                            SongEntity(
                                uri = uri.toString(),
                                title = metadata.first.ifBlank { uri.lastPathSegment?.substringAfterLast('/') ?: "Untitled" },
                                artist = metadata.second.ifBlank { "Unknown artist" },
                                album = metadata.third.ifBlank { "Unknown album" }
                            )
                        )
                    }
                }
            }

            MaterialTheme(colorScheme = lightColorScheme(
                primary = Orange, background = Cream, surface = Cream,
                onBackground = Ink, onSurface = Ink
            )) {
                Surface(Modifier.fillMaxSize(), color = Cream) {
                    Column(Modifier.fillMaxSize().padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("BE.I MUSIC", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink)
                                Text("Your music. Your lyrics. Your world.", color = Color(0xFF8B7866), fontSize = 12.sp)
                            }
                            Icon(Icons.Default.Headphones, null, tint = Orange, modifier = Modifier.size(34.dp))
                        }
                        Spacer(Modifier.height(24.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE8CC)),
                            shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Text("YOUR LIBRARY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("${songs.size} lagu tersimpan", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Ink)
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Orange)) {
                                    Icon(Icons.Default.Upload, null)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Upload musik")
                                }
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("My Library", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("LOCAL", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        if (songs.isEmpty()) {
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Default.LibraryMusic, null, tint = Orange, modifier = Modifier.size(48.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("Belum ada lagu", fontWeight = FontWeight.Bold)
                                    Text("Upload file MP3 atau audio dari HP kamu.", color = Color.Gray, fontSize = 12.sp)
                                }
                            }
                        } else {
                            LazyColumn(Modifier.weight(1f)) {
                                items(songs, key = { it.uri }) { song ->
                                    ListItem(
                                        headlineContent = { Text(song.title, fontWeight = FontWeight.SemiBold) },
                                        supportingContent = { Text("${song.artist} • ${song.album}") },
                                        leadingContent = { Icon(Icons.Default.MusicNote, null, tint = Orange) },
                                        trailingContent = {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                IconButton(onClick = {
                                                    editingSong = song
                                                    editTitle = song.title
                                                    editArtist = song.artist
                                                    editAlbum = song.album
                                                    editLyrics = song.lyrics
                                                    showEditor = true
                                                }) { Icon(Icons.Default.Edit, "Edit info", tint = Ink) }
                                                IconButton(onClick = {
                                                    currentUri = song.uri
                                                    player.setMediaItem(MediaItem.fromUri(Uri.parse(song.uri)))
                                                    player.prepare()
                                                    player.play()
                                                    playing = true
                                                }) { Icon(Icons.Default.PlayArrow, "Play", tint = Orange) }
                                            }
                                        }
                                    )
                                    HorizontalDivider(color = Color(0xFFEFE2D2))
                                }
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Ink),
                            shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                val currentSong = songs.firstOrNull { it.uri == currentUri }
                                Text(currentSong?.title ?: "Pilih lagu untuk diputar",
                                    color = Color.White, fontWeight = FontWeight.Bold)
                                Text(currentSong?.artist ?: "BE.I MUSIC PLAYER", color = Color(0xFFFFD7A8), fontSize = 12.sp)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = {
                                        if (currentUri != null) {
                                            if (player.isPlaying) { player.pause(); playing = false }
                                            else { player.play(); playing = true }
                                        }
                                    }) {
                                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow,
                                            null, tint = Color.White)
                                    }
                                    Text(if (playing) "Sedang diputar" else "Player siap", color = Color(0xFFFFD7A8), modifier = Modifier.weight(1f))
                                    TextButton(onClick = {
                                        currentSong?.let {
                                            editingSong = it
                                            editTitle = it.title
                                            editArtist = it.artist
                                            editAlbum = it.album
                                            editLyrics = it.lyrics
                                            showEditor = true
                                        }
                                    }) { Text("LYRICS / EDIT", color = Color(0xFFFFD7A8)) }
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("v0.2 • Metadata & lirik tersimpan lokal", color = Color(0xFF9B8977), fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally))
                    }
                }
            }

            if (showEditor && editingSong != null) {
                AlertDialog(
                    onDismissRequest = { showEditor = false },
                    title = { Text("Edit lagu & lirik") },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(editTitle, { editTitle = it }, label = { Text("Judul lagu") }, singleLine = true)
                            OutlinedTextField(editArtist, { editArtist = it }, label = { Text("Artis") }, singleLine = true)
                            OutlinedTextField(editAlbum, { editAlbum = it }, label = { Text("Album") }, singleLine = true)
                            OutlinedTextField(editLyrics, { editLyrics = it }, label = { Text("Lirik lagu") }, minLines = 4)
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            editingSong?.let { old ->
                                scope.launch {
                                    dao.upsert(old.copy(
                                        title = editTitle.ifBlank { "Untitled" },
                                        artist = editArtist.ifBlank { "Unknown artist" },
                                        album = editAlbum.ifBlank { "Unknown album" },
                                        lyrics = editLyrics
                                    ))
                                }
                            }
                            showEditor = false
                        }) { Text("Simpan") }
                    },
                    dismissButton = { TextButton(onClick = { showEditor = false }) { Text("Batal") } }
                )
            }
        }
    }

    private fun readMetadata(uri: Uri): Triple<String, String, String> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            Triple(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
            )
        } catch (_: Exception) {
            Triple("", "", "")
        } finally {
            runCatching { retriever.release() }
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}
