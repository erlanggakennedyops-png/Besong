package com.bei.besound

import android.net.Uri
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.ResolvingDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Audius read-only catalog integration for Global Music. */
data class AudiusTrack(
    val id: String,
    val title: String,
    val artist: String,
    val artworkUrl: String?,
    val durationSeconds: Long,
    val permalink: String?
) {
    fun toSongEntity(): SongEntity = SongEntity(
        uri = AudiusApi.streamUrl(id), title = title, artist = artist,
        album = "GLOBAL MUSIC • Audius", coverUri = artworkUrl
    )
}

data class AudiusArtist(
    val id: String,
    val name: String,
    val handle: String,
    val artworkUrl: String?,
    val followerCount: Long
) {
    fun artworkSong(): SongEntity = SongEntity(
        uri = "audius-artist:$id", title = name, artist = "@$handle",
        album = "Audius Artist", coverUri = artworkUrl
    )
}

object AudiusApi {
    private const val BASE_URL = "https://api.audius.co/v1"

    private suspend fun getJson(path: String, apiKey: String): JSONObject = withContext(Dispatchers.IO) {
        val endpoint = URL("$BASE_URL$path")
        val connection = (endpoint.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("Accept", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("x-api-key", apiKey)
            setRequestProperty("User-Agent", "BESOUND-Android/1.6.4")
        }
        try {
            val status = connection.responseCode
            val body = (if (status in 200..299) connection.inputStream else connection.errorStream)
                ?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (status !in 200..299) {
                val message = runCatching { JSONObject(body).optString("message") }.getOrNull()
                throw IllegalStateException(message?.takeIf { it.isNotBlank() }
                    ?: "Audius gagal merespons (HTTP $status). Coba lagi nanti.")
            }
            JSONObject(body)
        } finally { connection.disconnect() }
    }

    private fun parseTracks(root: JSONObject): List<AudiusTrack> {
        val data = root.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (index in 0 until data.length()) {
                val item = data.optJSONObject(index) ?: continue
                val id = item.optString("id").takeIf { it.isNotBlank() && it != "null" } ?: continue
                val title = item.optString("title").takeIf { it.isNotBlank() && it != "null" } ?: "Untitled"
                val user = item.optJSONObject("user")
                val artist = user?.optString("name")?.takeIf { it.isNotBlank() && it != "null" } ?: "Unknown artist"
                if (!item.optBoolean("is_streamable", true) || item.optBoolean("is_stream_gated", false)) continue
                val artwork = item.optJSONObject("artwork")
                val image = artwork?.optString("480x480")?.takeIf { it.isNotBlank() && it != "null" }
                    ?: artwork?.optString("150x150")?.takeIf { it.isNotBlank() && it != "null" }
                add(AudiusTrack(id, title, artist, image, item.optLong("duration", 0L),
                    item.optString("permalink").takeIf { it.isNotBlank() && it != "null" }))
            }
        }
    }

    private fun parseArtists(root: JSONObject): List<AudiusArtist> {
        val data = root.optJSONArray("data") ?: return emptyList()
        return buildList {
            for (index in 0 until data.length()) {
                val item = data.optJSONObject(index) ?: continue
                val id = item.optString("id").takeIf { it.isNotBlank() && it != "null" } ?: continue
                val handle = item.optString("handle").takeIf { it.isNotBlank() && it != "null" } ?: continue
                val name = item.optString("name").takeIf { it.isNotBlank() && it != "null" } ?: handle
                val picture = item.optJSONObject("profile_picture")
                val image = picture?.optString("500x500")?.takeIf { it.isNotBlank() && it != "null" }
                    ?: picture?.optString("150x150")?.takeIf { it.isNotBlank() && it != "null" }
                add(AudiusArtist(id, name, handle, image, item.optLong("follower_count", 0L)))
            }
        }
    }

    suspend fun searchTracks(query: String, apiKey: String = "", offset: Int = 0, limit: Int = 30): List<AudiusTrack> {
        require(query.isNotBlank()) { "Masukkan judul lagu atau nama artis." }
        val q = URLEncoder.encode(query.trim(), "UTF-8")
        return parseTracks(getJson("/tracks/search?query=$q&limit=$limit&offset=$offset", apiKey))
    }

    suspend fun trendingTracks(apiKey: String = "", limit: Int = 20): List<AudiusTrack> =
        parseTracks(getJson("/tracks/trending?time=week&limit=$limit", apiKey))

    suspend fun latestTracks(apiKey: String = "", limit: Int = 20): List<AudiusTrack> =
        parseTracks(getJson("/tracks/latest?limit=$limit", apiKey))

    suspend fun topArtists(apiKey: String = "", limit: Int = 18): List<AudiusArtist> =
        parseArtists(getJson("/users/top?limit=$limit", apiKey))

    suspend fun artistTracks(artistId: String, apiKey: String = "", offset: Int = 0, limit: Int = 30): List<AudiusTrack> =
        parseTracks(getJson("/users/${Uri.encode(artistId)}/tracks?limit=$limit&offset=$offset&sort_method=plays&sort_direction=desc", apiKey))

    fun streamUrl(trackId: String): String = "$BASE_URL/tracks/${Uri.encode(trackId)}/stream"
}

/** Attach the API key only to Audius hosts, never to unrelated media URLs. */
@OptIn(androidx.media3.common.util.UnstableApi::class)
fun createAudiusDataSourceFactory(apiKey: String): ResolvingDataSource.Factory {
    val upstream = DefaultHttpDataSource.Factory()
    val resolver = object : ResolvingDataSource.Resolver {
        override fun resolveDataSpec(dataSpec: DataSpec): DataSpec {
            val host = dataSpec.uri.host.orEmpty().lowercase()
            return if (apiKey.isNotBlank() && (host == "audius.co" || host.endsWith(".audius.co")))
                dataSpec.withRequestHeaders(mapOf("x-api-key" to apiKey)) else dataSpec
        }
    }
    return ResolvingDataSource.Factory(upstream, resolver)
}
