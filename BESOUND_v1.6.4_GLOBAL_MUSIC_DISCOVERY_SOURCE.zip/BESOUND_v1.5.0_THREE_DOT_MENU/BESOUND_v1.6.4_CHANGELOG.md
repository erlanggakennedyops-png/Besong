# BESOUND v1.6.4 - Global Music Discovery & Scroll Fix

- Global Music now loads Audius top artists with profile artwork.
- Added trending tracks and latest releases sections.
- Added artist detail view with artist track catalog.
- Expanded track search to 30 results per page and added load-more pagination.
- Fixed Global Music content scrolling so results remain reachable above the mini-player and bottom navigation.
- Kept playback on the existing Media3 player, including queue, mini-player, notification and lock-screen integration.
- Audius read-only API key remains optional; a configured key is used only for Audius requests.
- Version code: 57; version name: 1.6.4.

Note: Catalog availability depends on Audius indexing and stream permissions. This does not add commercial catalogs that Audius does not host. Verify network search and playback on a physical device after installing the APK.
