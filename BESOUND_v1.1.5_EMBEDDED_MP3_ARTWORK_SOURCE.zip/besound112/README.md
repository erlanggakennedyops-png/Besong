# BESOUND v1.1.4

Android source project for package `com.bei.besound`.

## Version
- versionCode: 15
- versionName: 1.1.4
- Room database schema: version 2 (unchanged; no destructive migration)

## Changes in 1.1.2
- Cache decoded cover artwork by its persisted private URI, avoiding repeated image decoding during playback updates.
- Read `file://` cover images directly from the app-private file path and continue supporting content URIs.
- Publish MediaSession artwork metadata only when track metadata or duration changes.
- Separate frequent playback-position/state updates from artwork metadata updates.
- Refresh active-track metadata after editing a song, including a newly selected cover.
- Keep Media3 ExoPlayer, PlayerNotificationManager, MediaSessionCompat, package ID, database, stored songs, launcher icon, and release signing configuration.

## Important verification note
The source archive and workflow include structural checks. A signed APK is only considered verified after GitHub Actions completes the Gradle build, signature check, and package/version check successfully.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change `applicationId` or release keystore for updates.

## Changes in 1.1.4
- Resolve the active track's selected cover from the Room database first for notification and lock-screen artwork.
- Treat a known track with an empty coverUri as intentionally having no custom cover, so BESOUND default artwork is used instead of stale player metadata.
- Refresh media artwork when Room emits updated song records and immediately after the active song is edited.
- Keep the existing database schema (version 2), package ID, and release signing configuration unchanged.

## Verification
- Source archive integrity and PNG artwork decoding were checked.
- Kotlin source changes were inspected, but a signed APK has not been built or device-tested yet. GitHub Actions must pass before installation.
