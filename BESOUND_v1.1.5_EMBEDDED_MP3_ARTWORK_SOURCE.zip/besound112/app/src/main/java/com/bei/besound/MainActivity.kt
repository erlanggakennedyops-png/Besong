package com.bei.besound

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.media.MediaMetadataRetriever
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import java.io.File
import java.util.UUID
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContract
import androidx.core.content.ContextCompat
import androidx.media3.ui.PlayerNotificationManager
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.support.v4.media.MediaMetadataCompat
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private var Cream by mutableStateOf(Color(0xFF17120F))
private var CreamCard by mutableStateOf(Color(0xFF2A1C16))
private var Orange by mutableStateOf(Color(0xFFFF8A32))
private var Golden by mutableStateOf(Color(0xFFFFC15A))
private var Ink by mutableStateOf(Color(0xFFFFE8CE))
private var Muted by mutableStateOf(Color(0xFFB99B80))
private var NavSurface by mutableStateOf(Color(0xFF211711))
private var DividerTone by mutableStateOf(Color(0xFF493123))

private fun applyPalette(name: String) {
    when (name) {
        "Cream Light" -> {
            Cream = Color(0xFFFFF8ED); CreamCard = Color(0xFFFFE8CC)
            Orange = Color(0xFFE58B3A); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFF33291F); Muted = Color(0xFF8B7866)
            NavSurface = Color(0xFFFFF1DE); DividerTone = Color(0xFFEFE2D2)
        }
        "Midnight" -> {
            Cream = Color(0xFF10131B); CreamCard = Color(0xFF202633)
            Orange = Color(0xFFFF8B45); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFFF5F0E9); Muted = Color(0xFFA6A9B4)
            NavSurface = Color(0xFF191E29); DividerTone = Color(0xFF343B49)
        }
        else -> {
            Cream = Color(0xFF17120F); CreamCard = Color(0xFF2A1C16)
            Orange = Color(0xFFFF8A32); Golden = Color(0xFFFFC15A)
            Ink = Color(0xFFFFE8CE); Muted = Color(0xFFB99B80)
            NavSurface = Color(0xFF211711); DividerTone = Color(0xFF493123)
        }
    }
}



/**
 * Opens audio documents with read + write grants so BESOUND can update ID3 tags
 * (including embedded album artwork) in the selected MP3 file.
 */
private class OpenMultipleAudioDocuments : ActivityResultContract<Array<String>, List<Uri>>() {
    override fun createIntent(context: Context, input: Array<String>): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = input.firstOrNull() ?: "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
    }

    override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
        if (resultCode != android.app.Activity.RESULT_OK || intent == null) return emptyList()
        val result = mutableListOf<Uri>()
        intent.clipData?.let { clip ->
            for (index in 0 until clip.itemCount) {
                clip.getItemAt(index).uri?.let(result::add)
            }
        }
        intent.data?.let { if (it !in result) result.add(it) }
        return result.distinct()
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSessionCompat
    private lateinit var notificationManager: PlayerNotificationManager
    private val notificationChannelId = "besound_playback"
    private val notificationId = 4101
    // Cache artwork by its private persisted URI. Never decode a full cover on every UI tick.
    private var cachedArtworkUri: String? = null
    private var cachedArtworkBitmap: android.graphics.Bitmap? = null
    // Room is the source of truth for covers selected in the in-app editor.
    // A known track with a null cover must use the BESOUND fallback, not stale player metadata.
    @Volatile private var trackArtworkUris: Map<String, String?> = emptyMap()
    private var lastCompatMetadataKey: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
        }

        createPlaybackNotificationChannel()
        mediaSession = MediaSessionCompat(this, "BESOUND").apply {
            setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                    MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
            )
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { player.play() }
                override fun onPause() { player.pause() }
                override fun onSkipToNext() { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }
                override fun onSkipToPrevious() { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() }
                override fun onSeekTo(pos: Long) { player.seekTo(pos) }
                override fun onStop() { player.pause(); player.seekTo(0L) }
            })
            isActive = true
        }
        notificationManager = PlayerNotificationManager.Builder(
            this, notificationId, notificationChannelId
        )
            .setMediaDescriptionAdapter(object : PlayerNotificationManager.MediaDescriptionAdapter {
                override fun getCurrentContentTitle(player: Player): CharSequence {
                    return player.mediaMetadata.title ?: "BESOUND"
                }
                override fun createCurrentContentIntent(player: Player): PendingIntent? {
                    val intent = Intent(this@MainActivity, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    return PendingIntent.getActivity(
                        this@MainActivity, 0, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                }
                override fun getCurrentContentText(player: Player): CharSequence? {
                    return player.mediaMetadata.artist
                }
                override fun getCurrentLargeIcon(
                    player: Player,
                    callback: PlayerNotificationManager.BitmapCallback
                ): android.graphics.Bitmap? {
                    // Use each track's selected cover when available. If a track has
                    // no cover (or its file cannot be decoded), use BESOUND artwork.
                    val artworkUri = resolveCurrentArtworkUri(player)
                    return artworkUri?.let { loadArtworkBitmapCached(it) }
                        ?: loadDefaultArtworkBitmap()
                }
            })
            .setNotificationListener(object : PlayerNotificationManager.NotificationListener {})
            .build()
            .apply {
                setMediaSessionToken(mediaSession.sessionToken)
                setUseNextAction(true)
                setUsePreviousAction(true)
                setUsePlayPauseActions(true)
                setPlayer(player)
            }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4102)
        }

        val dao = MusicDatabase.get(this).songDao()

        setContent {
            val scope = rememberCoroutineScope()
            val songs by dao.observeAll().collectAsState(initial = emptyList())

            var currentUri by remember { mutableStateOf<String?>(null) }
            var isPlaying by remember { mutableStateOf(false) }
            var positionMs by remember { mutableLongStateOf(0L) }
            var durationMs by remember { mutableLongStateOf(0L) }
            var shuffleEnabled by remember { mutableStateOf(false) }
            var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
            var selectedTab by remember { mutableIntStateOf(0) }
            var searchText by remember { mutableStateOf("") }
            var showLyrics by remember { mutableStateOf(false) }
            var showEditor by remember { mutableStateOf(false) }
            var editingSong by remember { mutableStateOf<SongEntity?>(null) }
            var editTitle by remember { mutableStateOf("") }
            var editArtist by remember { mutableStateOf("") }
            var editAlbum by remember { mutableStateOf("") }
            var editLyrics by remember { mutableStateOf("") }
            var editCoverUri by remember { mutableStateOf<String?>(null) }
            var deletingSong by remember { mutableStateOf<SongEntity?>(null) }
            var themeName by remember { mutableStateOf(getPreferences(MODE_PRIVATE).getString("besound_theme", "Golden Dusk") ?: "Golden Dusk") }
            var showThemeMenu by remember { mutableStateOf(false) }
            SideEffect { applyPalette(themeName) }
            LaunchedEffect(themeName) { getPreferences(MODE_PRIVATE).edit().putString("besound_theme", themeName).apply() }

            val currentSong = songs.firstOrNull { it.uri == currentUri }

            // Keep notification/lock-screen artwork in sync with the cover saved in Room.
            // This also handles covers selected from the editor after playback has started.
            LaunchedEffect(songs) {
                trackArtworkUris = songs.associate { it.uri to it.coverUri }
                cachedArtworkUri = null
                cachedArtworkBitmap = null
                updateCompatMediaSession(forceMetadata = true)
                if (::notificationManager.isInitialized) notificationManager.invalidate()
            }

            // Repair legacy placeholder titles such as "msf:114295" using the actual file name.
            LaunchedEffect(songs) {
                songs.filter {
                    it.title.isBlank() || it.title.startsWith("msf:", ignoreCase = true) ||
                        it.title.equals("Untitled", ignoreCase = true)
                }.forEach { song ->
                    val recoveredTitle = displayNameFor(Uri.parse(song.uri))
                    if (recoveredTitle.isNotBlank() && recoveredTitle != song.title) {
                        dao.upsert(song.copy(title = recoveredTitle))
                    }
                }
            }

            val filteredSongs = remember(songs, searchText) {
                if (searchText.isBlank()) songs
                else songs.filter {
                    it.title.contains(searchText, true) ||
                        it.artist.contains(searchText, true) ||
                        it.album.contains(searchText, true)
                }
            }

            val coverPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    // Copy the selected image into BESOUND's private storage.
                    // The cover then survives deletion/moving of the original gallery file.
                    editCoverUri = persistArtwork(uri)?.toString()
                    if (editCoverUri == null) {
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "Cover gagal disimpan. Coba pilih foto lain.",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }

            val audioPicker = rememberLauncherForActivityResult(
                OpenMultipleAudioDocuments()
            ) { uris ->
                uris.forEach { uri ->
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                    }.onFailure {
                        // Some document providers grant read access only. Playback remains
                        // available, but embedded-tag editing will report a clear write error.
                        runCatching {
                            contentResolver.takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        }
                    }
                    val metadata = readMetadata(uri)
                    val fallbackTitle = displayNameFor(uri)
                    scope.launch {
                        // Re-selecting an already imported MP3 can refresh its persisted
                        // read/write document grant. Keep its lyrics and selected cover intact.
                        val existing = dao.getByUri(uri.toString())
                        if (existing != null) {
                            dao.upsert(existing)
                        } else {
                            dao.upsert(
                                SongEntity(
                                    uri = uri.toString(),
                                    title = metadata.first.ifBlank { fallbackTitle },
                                    artist = metadata.second.ifBlank { "Unknown artist" },
                                    album = metadata.third.ifBlank { "Unknown album" }
                                )
                            )
                        }
                    }
                }
            }

            fun playSong(song: SongEntity) {
                val index = songs.indexOfFirst { it.uri == song.uri }
                if (index >= 0) {
                    currentUri = song.uri
                    player.setMediaItems(songs.map { song ->
                        MediaItem.Builder()
                            .setMediaId(song.uri)
                            .setUri(Uri.parse(song.uri))
                            .setMediaMetadata(
                                androidx.media3.common.MediaMetadata.Builder()
                                    .setTitle(song.title)
                                    .setArtist(song.artist)
                                    .setAlbumTitle(song.album)
                                    .apply {
                                        song.coverUri?.takeIf { it.isNotBlank() }?.let {
                                            setArtworkUri(Uri.parse(it))
                                        }
                                    }
                                    .build()
                            )
                            .build()
                    }, index, 0L)
                    player.prepare()
                    player.play()
                    isPlaying = true
                    selectedTab = 5
                }
            }

            fun openEditor(song: SongEntity) {
                editingSong = song
                editTitle = song.title
                editArtist = song.artist
                editAlbum = song.album
                editLyrics = song.lyrics
                editCoverUri = song.coverUri
                showEditor = true
            }

            LaunchedEffect(Unit) {
                while (true) {
                    isPlaying = player.isPlaying
                    positionMs = player.currentPosition.coerceAtLeast(0L)
                    durationMs = player.duration.takeIf { it > 0L } ?: 0L
                    updateCompatPlaybackState()
                    // Do not infer a selected track from ExoPlayer's default index (0).
                    // A track is selected only when the player actually has a media item.
                    val activeItem = player.currentMediaItem
                    val activeUri = activeItem?.mediaId?.takeIf { id -> songs.any { it.uri == id } }
                    currentUri = activeUri
                    delay(400)
                }
            }

            DisposableEffect(player) {
                val listener = object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) {
                        isPlaying = playing
                        updateCompatMediaSession()
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        currentUri = mediaItem?.mediaId?.takeIf { id -> songs.any { it.uri == id } }
                        // Media3 does not guarantee that a notification rebuilds its large icon
                        // just because a MediaItem's artwork metadata changed.
                        updateCompatMediaSession(forceMetadata = true)
                        if (::notificationManager.isInitialized) notificationManager.invalidate()
                    }
                    override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
                        updateCompatMediaSession(forceMetadata = true)
                        if (::notificationManager.isInitialized) notificationManager.invalidate()
                    }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        durationMs = player.duration.takeIf { it > 0L } ?: 0L
                        updateCompatMediaSession()
                    }
                    override fun onPositionDiscontinuity(
                        oldPosition: Player.PositionInfo,
                        newPosition: Player.PositionInfo,
                        reason: Int
                    ) {
                        updateCompatPlaybackState()
                    }
                }
                player.addListener(listener)
                onDispose { player.removeListener(listener) }
            }

            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Orange,
                    onPrimary = Color.White,
                    secondary = Golden,
                    background = Cream,
                    surface = Cream,
                    onBackground = Ink,
                    onSurface = Ink,
                    onSurfaceVariant = Muted,
                    surfaceVariant = CreamCard,
                    secondaryContainer = CreamCard,
                    onSecondaryContainer = Ink
                )
            ) {
                Scaffold(
                    containerColor = Cream,
                    bottomBar = {
                        if (!showLyrics) NavigationBar(containerColor = NavSurface) {
                            val navItems = listOf(
                                Triple("Home", Icons.Default.Home, 0),
                                Triple("Bei Song", Icons.Default.MusicNote, 1),
                                Triple("Global Music", Icons.Default.Public, 2),
                                Triple("Library", Icons.Default.LibraryMusic, 3),
                                Triple("Profile", Icons.Default.Person, 4)
                            )
                            navItems.forEach { item ->
                                NavigationBarItem(
                                    selected = selectedTab == item.third,
                                    onClick = { selectedTab = item.third },
                                    icon = { Icon(item.second, contentDescription = item.first) },
                                    label = { Text(item.first, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Orange,
                                        selectedTextColor = Ink,
                                        indicatorColor = CreamCard,
                                        unselectedIconColor = Muted,
                                        unselectedTextColor = Muted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    Column(
                        Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                    ) {
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "BESOUND",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Ink,
                                    letterSpacing = (-0.8).sp
                                )
                                Text(
                                    "Your music. Your lyrics. Your world.",
                                    color = Muted,
                                    fontSize = 12.sp
                                )
                            }
                            Box {
                                IconButton(onClick = { showThemeMenu = true }) {
                                    Icon(Icons.Default.Palette, "Ganti tema", tint = Orange, modifier = Modifier.size(30.dp))
                                }
                                DropdownMenu(
                                    expanded = showThemeMenu,
                                    onDismissRequest = { showThemeMenu = false },
                                    containerColor = CreamCard,
                                    tonalElevation = 8.dp,
                                    shadowElevation = 8.dp
                                ) {
                                    listOf("Golden Dusk", "Cream Light", "Midnight").forEach { option ->
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(
                                                        option,
                                                        color = Ink,
                                                        fontWeight = if (themeName == option) FontWeight.Bold else FontWeight.Normal
                                                    )
                                                    if (themeName == option) {
                                                        Spacer(Modifier.width(12.dp))
                                                        Icon(Icons.Default.Check, contentDescription = "Tema aktif", tint = Orange)
                                                    }
                                                }
                                            },
                                            onClick = { themeName = option; showThemeMenu = false }
                                        )
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))

                        if (selectedTab == 0) {
                            Text("DISCOVER", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Find your sound.", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink)
                            Text("Your music. Your lyrics. Your world.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(18.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().clickable { selectedTab = 1 }) {
                                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Orange, Golden))), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) { Text("BEI SONG", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text("Original music by Bei", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Katalog resmi karya kamu", color = Muted, fontSize = 12.sp) }
                                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth().clickable { selectedTab = 2 }) {
                                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(54.dp).clip(RoundedCornerShape(16.dp)).background(Brush.linearGradient(listOf(Golden, Orange))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Public, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) { Text("EXPLORE THE WORLD", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold); Text("Global Music", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("Discover artists around the world", color = Muted, fontSize = 12.sp) }
                                    Icon(Icons.Default.ChevronRight, null, tint = Muted)
                                }
                            }
                            Spacer(Modifier.height(14.dp))
                            Text("Your local collection", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("${songs.size} lagu di Library", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(8.dp))
                            OutlinedButton(onClick = { selectedTab = 3 }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Icon(Icons.Default.LibraryMusic, null); Spacer(Modifier.width(8.dp)); Text("Buka Library") }
                        } else if (selectedTab == 1 || selectedTab == 2) {
                            val isBeiSong = selectedTab == 1
                            Text(if (isBeiSong) "BEI SONG" else "GLOBAL MUSIC", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(if (isBeiSong) "Music by Bei" else "Music from around the world", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(18.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Icon(if (isBeiSong) Icons.Default.MusicNote else Icons.Default.Public, null, tint = Orange, modifier = Modifier.size(36.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text(if (isBeiSong) "Katalog Bei Song" else "Global Music", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                    Text(if (isBeiSong) "Lagu resmi karya Bei akan ditampilkan di sini dan dapat didengarkan semua pengguna setelah layanan cloud diaktifkan." else "Katalog musik global akan terhubung melalui sumber musik yang memiliki izin distribusi.", color = Muted, fontSize = 13.sp)
                                    Spacer(Modifier.height(10.dp))
                                    Text("COMING IN CLOUD RELEASE", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else if (selectedTab == 4) {
                            Text("PROFILE", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Your BESOUND account", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(16.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp)) {
                                    Icon(Icons.Default.AccountCircle, null, tint = Orange, modifier = Modifier.size(48.dp))
                                    Spacer(Modifier.height(8.dp))
                                    Text("Guest user", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text("Login dan sinkronisasi akun akan hadir saat backend cloud tersedia.", color = Muted, fontSize = 13.sp)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = { showThemeMenu = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Palette, null); Spacer(Modifier.width(8.dp)); Text("Ganti tema") }
                        } else if (selectedTab == 3) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = CreamCard),
                                shape = RoundedCornerShape(24.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(18.dp)) {
                                    Text("YOUR LIBRARY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("${songs.size} lagu tersimpan", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Ink)
                                    Spacer(Modifier.height(12.dp))
                                    Button(
                                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                        colors = ButtonDefaults.buttonColors(containerColor = Orange),
                                        shape = RoundedCornerShape(28.dp)
                                    ) {
                                        Icon(Icons.Default.Upload, null)
                                        Spacer(Modifier.width(8.dp))
                                        Text("Upload musik")
                                    }
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            OutlinedTextField(
                                value = searchText,
                                onValueChange = { searchText = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                placeholder = { Text("Cari lagu, artis, atau album...") },
                                leadingIcon = { Icon(Icons.Default.Search, null, tint = Orange) },
                                shape = RoundedCornerShape(18.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Ink,
                                    unfocusedTextColor = Ink,
                                    cursorColor = Orange,
                                    focusedPlaceholderColor = Muted,
                                    unfocusedPlaceholderColor = Muted,
                                    focusedLeadingIconColor = Orange,
                                    unfocusedLeadingIconColor = Orange,
                                    focusedBorderColor = Orange,
                                    unfocusedBorderColor = DividerTone,
                                    focusedContainerColor = Cream,
                                    unfocusedContainerColor = Cream
                                )
                            )
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("My Library", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                                Text("LOCAL", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            if (filteredSongs.isEmpty()) {
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.LibraryMusic, null, tint = Orange, modifier = Modifier.size(48.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text(if (songs.isEmpty()) "Belum ada lagu" else "Lagu tidak ditemukan", fontWeight = FontWeight.Bold, color = Ink)
                                        Text("Upload MP3 atau audio dari HP kamu.", color = Muted, fontSize = 12.sp)
                                    }
                                }
                            } else {
                                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 112.dp)) {
                                    items(filteredSongs, key = { it.uri }) { song ->
                                        ListItem(
                                            modifier = Modifier.clickable { playSong(song) },
                                            headlineContent = {
                                                Text(
                                                    song.title,
                                                    fontWeight = FontWeight.SemiBold,
                                                    softWrap = true
                                                )
                                            },
                                            supportingContent = {
                                                Text("${song.artist} • ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted)
                                            },
                                            leadingContent = {
                                                SongArtwork(song = song, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)))
                                            },
                                            trailingContent = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    IconButton(
                                                        onClick = { openEditor(song) },
                                                        modifier = Modifier.size(36.dp)
                                                    ) {
                                                        Icon(Icons.Default.Edit, "Edit lagu", tint = Ink, modifier = Modifier.size(20.dp))
                                                    }
                                                    IconButton(
                                                        onClick = { deletingSong = song },
                                                        modifier = Modifier.size(36.dp)
                                                    ) {
                                                        Icon(Icons.Default.DeleteOutline, "Hapus dari Library", tint = Muted, modifier = Modifier.size(20.dp))
                                                    }
                                                    val isThisSongPlaying = currentUri == song.uri && isPlaying
                                                    IconButton(
                                                        onClick = {
                                                            if (currentUri == song.uri && player.currentMediaItem != null) {
                                                                if (player.isPlaying) player.pause() else player.play()
                                                            } else {
                                                                playSong(song)
                                                            }
                                                        },
                                                        modifier = Modifier.size(36.dp)
                                                    ) {
                                                        Icon(
                                                            if (isThisSongPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                                            if (isThisSongPlaying) "Jeda lagu" else "Putar lagu",
                                                            tint = Orange,
                                                            modifier = Modifier.size(22.dp)
                                                        )
                                                    }
                                                }
                                            },
                                            colors = ListItemDefaults.colors(containerColor = Cream)
                                        )
                                        HorizontalDivider(color = DividerTone)
                                    }
                                }
                            }
                        } else {
                            if (showLyrics) {
                                FullscreenLyricsScreen(
                                    song = currentSong,
                                    onClose = { showLyrics = false }
                                )
                            } else NowPlayingScreen(
                                song = currentSong,
                                isPlaying = isPlaying,
                                positionMs = positionMs,
                                durationMs = durationMs,
                                shuffleEnabled = shuffleEnabled,
                                repeatMode = repeatMode,
                                onPlayPause = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.currentMediaItem != null) player.play()
                                    isPlaying = player.isPlaying
                                },
                                onPrevious = {
                                    if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                    else if (player.currentMediaItem != null) player.seekTo(0)
                                },
                                onNext = {
                                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                },
                                onSeek = { player.seekTo(it) },
                                onLyrics = { showLyrics = true },
                                onShuffle = {
                                    shuffleEnabled = !shuffleEnabled
                                    player.shuffleModeEnabled = shuffleEnabled
                                },
                                onRepeat = {
                                    repeatMode = when (repeatMode) {
                                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                        else -> Player.REPEAT_MODE_OFF
                                    }
                                    player.repeatMode = repeatMode
                                }
                            )
                        }

                        // Hide the mini-player until the user has selected a track.
                        if (selectedTab != 5 && player.currentMediaItem != null && currentSong != null) {
                            MiniPlayer(
                                song = currentSong,
                                isPlaying = isPlaying,
                                onPlayPause = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.currentMediaItem != null) player.play()
                                },
                                onPrevious = {
                                    if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                    else if (player.currentMediaItem != null) player.seekTo(0)
                                },
                                onNext = {
                                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                },
                                onOpen = { selectedTab = 5 }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "v1.1.5 • Embedded MP3 Artwork",
                            color = Muted,
                            fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp)
                        )
                    }
                }
            }

            if (deletingSong != null) {
                AlertDialog(
                    onDismissRequest = { deletingSong = null },
                    title = { Text("Hapus lagu dari Library?") },
                    text = {
                        Text("${deletingSong?.title.orEmpty()} akan dihapus dari daftar BESOUND. File audio asli di HP tidak akan dihapus.")
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val target = deletingSong
                            deletingSong = null
                            if (target != null) {
                                val playerIndex = (0 until player.mediaItemCount).firstOrNull { index ->
                                    player.getMediaItemAt(index).mediaId == target.uri
                                }
                                if (currentUri == target.uri) {
                                    player.stop()
                                    player.clearMediaItems()
                                    currentUri = null
                                    isPlaying = false
                                    positionMs = 0L
                                    durationMs = 0L
                                } else if (playerIndex != null) {
                                    player.removeMediaItem(playerIndex)
                                }
                                scope.launch { dao.delete(target.uri) }
                            }
                        }) { Text("Hapus", color = Color(0xFFE05A45)) }
                    },
                    dismissButton = {
                        TextButton(onClick = { deletingSong = null }) { Text("Batal") }
                    }
                )
            }

            if (showEditor && editingSong != null) {
                AlertDialog(
                    onDismissRequest = { showEditor = false; showLyrics = false },
                    title = { Text(if (showLyrics) "Lyrics Studio" else "Edit lagu & lirik") },
                    text = {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!showLyrics) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    SongArtwork(
                                        song = editingSong?.copy(coverUri = editCoverUri),
                                        modifier = Modifier.size(76.dp).clip(RoundedCornerShape(14.dp))
                                    )
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Cover lagu", color = Ink, fontWeight = FontWeight.SemiBold)
                                        TextButton(onClick = { coverPicker.launch(arrayOf("image/*")) }) {
                                            Icon(Icons.Default.Image, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("Pilih dari galeri")
                                        }
                                        if (editCoverUri != null) {
                                            TextButton(onClick = { editCoverUri = null }) {
                                                Text("Hapus cover", color = Muted)
                                            }
                                        }
                                    }
                                }
                                OutlinedTextField(editTitle, { editTitle = it }, label = { Text("Judul lagu") }, singleLine = true)
                                OutlinedTextField(editArtist, { editArtist = it }, label = { Text("Artis") }, singleLine = true)
                                OutlinedTextField(editAlbum, { editAlbum = it }, label = { Text("Album") }, singleLine = true)
                            }
                            OutlinedTextField(
                                editLyrics,
                                { editLyrics = it },
                                label = { Text("Lirik lagu") },
                                minLines = 5,
                                maxLines = 9
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val old = editingSong
                            if (old != null) {
                                scope.launch {
                                    try {
                                        val updated = old.copy(
                                            title = editTitle.trim().ifBlank { "Untitled" },
                                            artist = editArtist.trim().ifBlank { "Unknown artist" },
                                            album = editAlbum.trim().ifBlank { "Unknown album" },
                                            lyrics = editLyrics,
                                            coverUri = editCoverUri
                                        )

                                        val coverChanged = editCoverUri != old.coverUri
                                        val resumeAfterSave =
                                            coverChanged &&
                                                player.currentMediaItem?.mediaId == old.uri &&
                                                player.isPlaying
                                        if (resumeAfterSave) player.pause()

                                        try {
                                            // When the cover changes, write it into the actual MP3
                                            // as an ID3v2 APIC picture frame. The picker requests
                                            // writable document access for this operation.
                                            if (coverChanged) {
                                                withContext(Dispatchers.IO) {
                                                    Mp3ArtworkWriter.embed(
                                                        context = this@MainActivity,
                                                        audioUri = Uri.parse(old.uri),
                                                        coverUri = editCoverUri?.let { Uri.parse(it) },
                                                        title = updated.title,
                                                        artist = updated.artist,
                                                        album = updated.album
                                                    )
                                                }
                                            }

                                            // Only update Room after the MP3 tag write succeeds.
                                            dao.upsert(updated)
                                            val saved = dao.getByUri(old.uri)
                                            check(saved == updated) { "Data lagu belum tersimpan dengan benar." }
                                            // Refresh Media3 and Android media surfaces immediately.
                                            refreshPlayingTrackMetadata(saved!!)
                                            if (resumeAfterSave) player.play()
                                        } catch (saveError: Exception) {
                                            if (resumeAfterSave) player.play()
                                            throw saveError
                                        }
                                        editingSong = saved
                                        showEditor = false
                                        showLyrics = false
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            if (coverChanged) {
                                                "Cover berhasil ditanam ke metadata MP3."
                                            } else {
                                                "Perubahan lagu berhasil disimpan."
                                            },
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } catch (error: Exception) {
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            "Gagal menyimpan: ${error.message ?: "coba lagi"}",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            }
                        }) { Text("Simpan") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditor = false; showLyrics = false }) { Text("Tutup") }
                    }
                )
            }
        }
    }

    private fun displayNameFor(uri: Uri): String {
        var displayName = ""
        runCatching {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (column >= 0) displayName = cursor.getString(column).orEmpty()
                }
            }
        }
        if (displayName.isBlank()) {
            displayName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':').orEmpty()
        }
        val withoutExtension = displayName.substringBeforeLast('.', displayName).trim()
        return withoutExtension.ifBlank { "Untitled" }
    }

    private fun readMetadata(uri: Uri): Triple<String, String, String> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            Triple(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
            )
        } catch (_: Exception) {
            Triple("", "", "")
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Store selected artwork inside app-private storage and return a stable file URI. */
    private fun persistArtwork(source: Uri): Uri? = runCatching {
        val directory = File(filesDir, "track_covers").apply { mkdirs() }
        val mime = contentResolver.getType(source).orEmpty()
        val extension = when {
            mime.contains("png", ignoreCase = true) -> "png"
            mime.contains("webp", ignoreCase = true) -> "webp"
            else -> "jpg"
        }
        val destination = File(directory, "cover_${UUID.randomUUID()}.$extension")
        contentResolver.openInputStream(source)?.use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Tidak bisa membaca foto yang dipilih")
        check(destination.length() > 0L) { "File cover kosong" }
        Uri.fromFile(destination)
    }.getOrNull()

    /** Replace the active media item's metadata so Android refreshes all media surfaces. */
    private fun refreshPlayingTrackMetadata(song: SongEntity) {
        if (!::player.isInitialized) return
        val index = player.currentMediaItemIndex
        val current = player.currentMediaItem ?: return
        if (current.mediaId != song.uri) return
        trackArtworkUris = trackArtworkUris + (song.uri to song.coverUri)
        val metadata = androidx.media3.common.MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
            .apply {
                song.coverUri?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) }
            }
            .build()
        val refreshed = MediaItem.Builder()
            .setMediaId(song.uri)
            .setUri(Uri.parse(song.uri))
            .setMediaMetadata(metadata)
            .build()
        player.replaceMediaItem(index, refreshed)
        // Refresh both media surfaces explicitly: legacy MediaSession metadata for the
        // lock screen and the Media3 notification's cached large icon.
        cachedArtworkUri = null
        cachedArtworkBitmap = null
        updateCompatMediaSession(forceMetadata = true)
        if (::notificationManager.isInitialized) notificationManager.invalidate()
    }

    /**
     * Resolve the selected cover from Room first. The app editor stores gallery images
     * as private file:// URIs in SongEntity.coverUri; ExoPlayer metadata is not the
     * authoritative store and can be empty or stale after metadata replacement.
     */
    private fun resolveCurrentArtworkUri(mediaPlayer: Player): Uri? {
        val item = mediaPlayer.currentMediaItem
        val mediaId = item?.mediaId
        if (!mediaId.isNullOrBlank() && trackArtworkUris.containsKey(mediaId)) {
            return trackArtworkUris[mediaId]
                ?.takeIf { it.isNotBlank() }
                ?.let(Uri::parse)
        }
        return mediaPlayer.mediaMetadata.artworkUri ?: item?.mediaMetadata?.artworkUri
    }

    /**
     * Decode user-selected cover art at notification-friendly dimensions.
     * Downsampling avoids putting full-resolution phone photos into Android's
     * notification and lock-screen metadata.
     */
    private fun loadArtworkBitmapCached(uri: Uri): android.graphics.Bitmap? {
        val key = uri.toString()
        if (cachedArtworkUri == key) return cachedArtworkBitmap
        val bitmap = loadArtworkBitmap(uri)
        cachedArtworkUri = key
        cachedArtworkBitmap = bitmap
        return bitmap
    }

    /** Shared default artwork for tracks without their own cover. */
    private var defaultArtworkBitmap: android.graphics.Bitmap? = null

    private fun loadDefaultArtworkBitmap(): android.graphics.Bitmap? {
        if (defaultArtworkBitmap == null) {
            defaultArtworkBitmap = android.graphics.BitmapFactory.decodeResource(
                resources, R.drawable.besound_default_artwork
            )
        }
        return defaultArtworkBitmap
    }

    private fun loadArtworkBitmap(uri: Uri): android.graphics.Bitmap? {
        return runCatching {
            fun openStream() = if (uri.scheme == "file") {
                File(requireNotNull(uri.path)).inputStream()
            } else {
                contentResolver.openInputStream(uri)
            }

            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            openStream()?.use { stream -> android.graphics.BitmapFactory.decodeStream(stream, null, bounds) }
                ?: return null
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val maxDimension = 512
            var sampleSize = 1
            while (bounds.outWidth / sampleSize > maxDimension ||
                bounds.outHeight / sampleSize > maxDimension
            ) sampleSize *= 2

            val options = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
            }
            openStream()?.use { stream -> android.graphics.BitmapFactory.decodeStream(stream, null, options) }
        }.getOrNull()
    }

    /** Publish artwork/title metadata only when the active track metadata actually changes. */
    private fun updateCompatMediaSession(forceMetadata: Boolean = false) {
        if (!::mediaSession.isInitialized || !::player.isInitialized) return
        val item = player.currentMediaItem
        val artworkUri = resolveCurrentArtworkUri(player)
        val duration = player.duration.takeIf { it > 0L } ?: 0L
        val title = item?.mediaMetadata?.title?.toString() ?: "BESOUND"
        val artist = item?.mediaMetadata?.artist?.toString().orEmpty()
        val album = item?.mediaMetadata?.albumTitle?.toString().orEmpty()
        val metadataKey = listOf(title, artist, album, duration.toString(), artworkUri?.toString().orEmpty())
            .joinToString("\u001f")

        if (forceMetadata || metadataKey != lastCompatMetadataKey) {
            val metadata = MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, album)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, duration)
                .apply {
                    val artwork = artworkUri?.let { loadArtworkBitmapCached(it) }
                        ?: loadDefaultArtworkBitmap()
                    if (artwork != null) {
                        putBitmap(MediaMetadataCompat.METADATA_KEY_ART, artwork)
                        putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, artwork)
                        putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, artwork)
                        artworkUri?.toString()?.let { uri ->
                            putString(MediaMetadataCompat.METADATA_KEY_ART_URI, uri)
                            putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, uri)
                            putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON_URI, uri)
                        }
                    }
                }
                .build()
            mediaSession.setMetadata(metadata)
            lastCompatMetadataKey = metadataKey
        }
    }

    /** Playback position/state changes frequently; keep these separate from expensive artwork metadata. */
    private fun updateCompatPlaybackState() {
        if (!::mediaSession.isInitialized || !::player.isInitialized) return
        val actions = PlaybackStateCompat.ACTION_PLAY or
            PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or
            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
            PlaybackStateCompat.ACTION_SEEK_TO or
            PlaybackStateCompat.ACTION_STOP
        val state = when {
            player.isPlaying -> PlaybackStateCompat.STATE_PLAYING
            player.playbackState == Player.STATE_BUFFERING -> PlaybackStateCompat.STATE_BUFFERING
            player.playbackState == Player.STATE_ENDED -> PlaybackStateCompat.STATE_STOPPED
            player.currentMediaItem != null -> PlaybackStateCompat.STATE_PAUSED
            else -> PlaybackStateCompat.STATE_NONE
        }
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, player.currentPosition.coerceAtLeast(0L), if (player.isPlaying) 1f else 0f)
                .build()
        )
    }

    private fun createPlaybackNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                notificationChannelId,
                "BESOUND playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Kontrol pemutaran musik BESOUND"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        if (::notificationManager.isInitialized) notificationManager.setPlayer(null)
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

/**
 * Detect vertical swipes in the Initial pointer pass only on dedicated hint zones.
 * The cover, transport controls, and lyrics scrolling area do not own navigation gestures.
 * Horizontal gestures are deliberately ignored.
 */
private fun Modifier.verticalSwipeGesture(
    onSwipeDown: () -> Unit,
    onSwipeUp: () -> Unit
): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(
            requireUnconsumed = false,
            pass = PointerEventPass.Initial
        )
        var previousY = down.position.y
        var totalY = 0f
        var completed = false
        val threshold = viewConfiguration.touchSlop * 1.5f

        while (!completed) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val change = event.changes.firstOrNull { it.id == down.id }
            if (change == null || !change.pressed) {
                completed = true
            } else {
                val deltaY = change.position.y - previousY
                val deltaX = change.position.x - down.position.x
                previousY = change.position.y
                totalY = change.position.y - down.position.y
                if (abs(totalY) >= threshold && abs(totalY) > abs(deltaX) * 1.2f) {
                    change.consume()
                    // Finger moving down is a swipe-down; finger moving up is a swipe-up.
                    if (totalY > 0f) onSwipeDown() else onSwipeUp()
                    completed = true
                }
            }
        }
    }
}

@Composable
private fun SongArtwork(
    song: SongEntity?,
    modifier: Modifier = Modifier,
    largeFallback: Boolean = false
) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, song?.coverUri) {
        value = null
        val cover = song?.coverUri
        if (!cover.isNullOrBlank()) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    context.contentResolver.openInputStream(Uri.parse(cover))?.use { stream ->
                        val bytes = stream.readBytes()
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                        val sample = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 1200)
                        val options = BitmapFactory.Options().apply { inSampleSize = sample }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                    }
                }.getOrNull()
            }
        }
    }
    Box(
        modifier = modifier.background(
            Brush.linearGradient(listOf(Orange, Golden, Color(0xFFFFE2B7)))
        ),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = "Cover ${song?.title.orEmpty()}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (largeFallback) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Headphones, null, tint = Color.White, modifier = Modifier.size(84.dp))
                Text("BESOUND", color = Color.White, fontSize = 22.sp,
                    fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            }
        } else {
            Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun ColumnScope.NowPlayingScreen(
    song: SongEntity?, isPlaying: Boolean, positionMs: Long, durationMs: Long,
    shuffleEnabled: Boolean, repeatMode: Int, onPlayPause: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit,
    onShuffle: () -> Unit, onRepeat: () -> Unit, onLyrics: () -> Unit
) {
    BoxWithConstraints(
        Modifier.fillMaxWidth().weight(1f)
    ) {
        val coverSize = minOf(maxWidth * 0.84f, maxHeight * 0.40f, 320.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly) {
            Text("NOW PLAYING", color = Orange, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            SongArtwork(
                song = song,
                modifier = Modifier.size(coverSize).clip(RoundedCornerShape(26.dp)),
                largeFallback = true
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(song?.title ?: "Belum ada lagu dipilih", color = Ink, fontSize = 21.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artist ?: "Pilih lagu dari Library", color = Muted, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Slider(value = positionMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1L).toFloat()),
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(), enabled = durationMs > 0L,
                colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange,
                    inactiveTrackColor = DividerTone))
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(positionMs), color = Muted, fontSize = 11.sp)
                Text(formatTime(durationMs), color = Muted, fontSize = 11.sp)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton(onClick = onShuffle, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffleEnabled) Orange else Muted,
                        modifier = Modifier.size(26.dp))
                }
                IconButton(onClick = onPrevious, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = Ink, modifier = Modifier.size(35.dp))
                }
                FilledIconButton(onClick = onPlayPause, enabled = song != null,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Orange,
                        contentColor = Color.White, disabledContainerColor = DividerTone,
                        disabledContentColor = Muted)) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play atau pause", modifier = Modifier.size(42.dp))
                }
                IconButton(onClick = onNext, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = Ink, modifier = Modifier.size(35.dp))
                }
                IconButton(onClick = onRepeat, modifier = Modifier.size(48.dp)) {
                    Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "Repeat", tint = if (repeatMode == Player.REPEAT_MODE_OFF) Muted else Orange,
                        modifier = Modifier.size(26.dp))
                }
            }
            Text(
                "SWIPE UP FOR LYRICS",
                color = Orange,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.8.sp,
                modifier = Modifier
                    .padding(top = 8.dp, bottom = 8.dp)
                    .fillMaxWidth()
                    .verticalSwipeGesture(onSwipeDown = {}, onSwipeUp = onLyrics)
            )
        }
    }
}

@Composable
private fun FullscreenLyricsScreen(song: SongEntity?, onClose: () -> Unit) {
    // Keep the lyrics area dedicated to vertical scrolling. Only the bottom hint
    // region handles the upward navigation gesture, so reading lyrics cannot
    // accidentally close the fullscreen lyrics screen.
    Column(Modifier.fillMaxWidth().fillMaxHeight()
        .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.SpaceBetween) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("LYRICS", color = Orange, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        val lines = song?.lyrics.orEmpty().lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Belum ada lirik untuk lagu ini", color = Muted, fontSize = 18.sp)
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center) {
                lines.forEachIndexed { index, line ->
                    Text(line, color = if (index == 0) Ink else Muted,
                        fontSize = if (index == 0) 25.sp else 20.sp,
                        fontWeight = if (index == 0) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(vertical = 12.dp))
                }
            }
        }
        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)
            .verticalSwipeGesture(onSwipeDown = {}, onSwipeUp = onClose),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(song?.title ?: "BESOUND", color = Ink, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song?.artist ?: "", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                "SWIPE UP TO PLAYER",
                color = Orange,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.8.sp
            )
        }
    }
}

@Composable
private fun MusicVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = Orange,
    barCount: Int = 7,
    maxBarHeight: androidx.compose.ui.unit.Dp = 30.dp
) {
    val transition = rememberInfiniteTransition(label = "besound_equalizer")
    Row(
        modifier = modifier.height(maxBarHeight),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(barCount) { index ->
            val animatedHeight by transition.animateFloat(
                initialValue = 0.18f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 360 + (index % 4) * 115,
                        delayMillis = index * 65,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "equalizer_bar_$index"
            )
            val barFraction = if (isPlaying) animatedHeight else 0.18f
            Box(
                Modifier
                    .width(4.dp)
                    .height(maxBarHeight * barFraction.coerceIn(0.12f, 1f))
                    .clip(CircleShape)
                    .background(barColor)
            )
        }
    }
}

@Composable
private fun MiniPlayer(
    song: SongEntity?,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onOpen: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CreamCard),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(enabled = song != null) { onOpen() }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SongArtwork(song = song, modifier = Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)))
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song?.title ?: "Belum ada lagu diputar",
                    color = Ink,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    song?.artist ?: "Pilih lagu dari Library",
                    color = Muted,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            if (song != null) {
                IconButton(onClick = onPrevious, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Lagu sebelumnya", tint = Ink, modifier = Modifier.size(25.dp))
                }
                IconButton(onClick = onPlayPause, modifier = Modifier.size(42.dp)) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play atau pause", tint = Orange, modifier = Modifier.size(30.dp)
                    )
                }
                IconButton(onClick = onNext, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Default.SkipNext, "Lagu berikutnya", tint = Ink, modifier = Modifier.size(25.dp))
                }
            } else {
                Text("Pilih lagu", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms.coerceAtLeast(0L) / 1000L)
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    return "%d:%02d".format(minutes, seconds)
}
