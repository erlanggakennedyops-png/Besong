# BESOUND v1.1.2

Android source project for package `com.bei.besound`.

## Version
- versionCode: 13
- versionName: 1.1.2
- Room database schema: version 2 (unchanged; no destructive migration)

## Changes in 1.1.2
- Cache decoded cover artwork by its persisted private URI, avoiding repeated image decoding during playback updates.
- Read `file://` cover images directly from the app-private file path and continue supporting content URIs.
- Publish MediaSession artwork metadata only when track metadata or duration changes.
- Separate frequent playback-position/state updates from artwork metadata updates.
- Refresh active-track metadata after editing a song, including a newly selected cover.
- Keep Media3 ExoPlayer, PlayerNotificationManager, MediaSessionCompat, package ID, database, stored songs, launcher icon, and release signing configuration.

## Important verification note
The source archive and workflow include structural checks. A signed APK is only considered verified after GitHub Actions completes the Gradle build, signature check, and package/version check successfully.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change `applicationId` or release keystore for updates.
