# BESOUND v0.8.1 – Golden Dusk

Player/Lyrics gesture hint update.

- Now Playing displays the non-clickable hint: SWIPE DOWN FOR LYRICS.
- Fullscreen Lyrics displays the non-clickable hint: SWIPE UP TO PLAYER.
- Removed arrow icon controls from the Lyrics screen; navigation remains gesture-only.
- Version: 0.8.1 (versionCode 15).

Build using GitHub Actions workflow at `.github/workflows/android.yml`. APK build and on-device gesture behavior must be verified in GitHub Actions and on an Android device.
