# BESOUND v0.7.9 - Gesture compile fix

Changes:
- Added the missing Compose `awaitPointerEvent` import required by the vertical swipe detector.
- Updated the visible in-app version label to 0.7.9.
- Updated Android versionName/versionCode and GitHub Actions artifact name.
- Kept swipe-down from Now Playing to fullscreen Lyrics and swipe-up from Lyrics back to Now Playing.
- Kept the duplicate `BEI_MUSIC` source tree synchronized with the repository root.

Build status: source package only. APK compilation and on-device gesture behavior must be verified by GitHub Actions and a real Android device.
