# BESOUND v1.0.3 — Golden Dusk

Package: `com.bei.besound` (unchanged; intended as an in-place update).
Version code: 4. Version name: 1.0.3.

Changes from v1.0.2:
- Hide the mini-player until a track has been selected (`currentSong != null`).
- Keep the mini-player hidden on first launch when no track is selected.
- Update the visible footer version to 1.0.3.
- Preserve the existing player, media notification, Room database, upload flow, package ID and signing configuration.

This is a focused UI visibility fix. It does not change the media playback architecture. Build and install-test through the existing GitHub Actions workflow before installing. Keep the same release keystore for in-place updates.
