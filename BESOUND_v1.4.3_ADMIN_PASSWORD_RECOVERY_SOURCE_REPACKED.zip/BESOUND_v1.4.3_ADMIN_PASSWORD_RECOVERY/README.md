# BESOUND v1.4.1 — Home & Search Refresh

Android source project for package `com.bei.besound`.

## Version
- versionCode: 42
- versionName: 1.4.1

## UI changes
- Replaced the old Home hero banner with the BESOUND robot mascot and speech bubble.
- Added BESOUND wordmark and animated equalizer in the Home header.
- Removed the small NOW badge from the Home player.
- Added a full-width animated orange waveform below the song title and artist.
- Removed waveform and play affordances from the BEI SONG and GLOBAL MUSIC destination cards.
- Added a dedicated Search screen opened from the Home search icon.
- Search filters are limited to All Song, Be.i Song, and Global. Popular Search and Playlist filter are not included.
- Search results use local Room song data and support matching title, artist, and album.
- Search screen has a back action and hides bottom navigation while open.

## Preserved
- Package ID `com.bei.besound`
- Room database and existing song records
- ExoPlayer playback and MediaSession / notification implementation
- Existing artwork assets, offline-copy logic, and signing configuration

## Build status
Source ZIP integrity checked. Android Gradle compilation has not been run in this environment.

## BESOUND 1.4.3 - Admin password recovery

- Added `Lupa password?` to the BEI SONG admin login dialog.
- Sends a Supabase Auth recovery email to the admin account.
- Handles the Android deep link `besound://auth/reset-password` and recovery access token.
- Adds a new-password confirmation dialog and updates the password through Supabase Auth.
- Android package ID remains `com.bei.besound`.
- Version: 1.4.3 (versionCode 44).

Supabase Dashboard requirement: Authentication -> URL Configuration -> Redirect URLs must include exactly:
`besound://auth/reset-password`

The existing Reset Password email template can continue using `{{ .ConfirmationURL }}`. The recovery email must be newly requested after adding the redirect URL; old links should not be reused.
