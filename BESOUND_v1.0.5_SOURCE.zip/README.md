# BESOUND v1.0.5

Android source project for package `com.bei.besound`.

## Version
- versionCode: 6
- versionName: 1.0.5
- Database: Room schema version 2

## Changes in 1.0.5
- Add song deletion from My Library. Deleting a library entry does not delete the original audio file from the phone.
- Add cover-art selection from the Android document picker. Persistable URI permission is requested so the selected image remains available after restart.
- Store cover URI in Room using a non-destructive migration from schema version 1 to 2. Existing songs and metadata are retained.
- Show selected cover art in Library rows, Now Playing, Mini Player, and edit dialog.
- Keep title, artist, album, and lyrics editing.

## Build
Use the repository's Android GitHub Actions workflow and existing signing secrets. Do not change applicationId or release keystore for updates.
