# BESOUND Android v0.4.0

Android music player project built with Kotlin, Jetpack Compose, Media3 ExoPlayer and Room.

## Features
- Golden Dusk default palette with manual Cream Light and Midnight theme selection.
- Local audio library and playback controls.
- Media3 playback engine.
- Local metadata and lyrics editing.
- Updated Golden Dusk BESOUND launcher and in-app logo.

## Build with GitHub Actions from an Android phone
1. Extract this ZIP on your phone.
2. Upload the **contents** of this folder to the root of your GitHub repository (not the ZIP file itself).
3. Commit to the `main` branch.
4. Open the repository's **Actions** tab and run the `Build BESOUND Android APK` workflow, or let it start on push.
5. When the workflow succeeds, download the `BESOUND-v0.4-APK` artifact.

Package: `com.bei.music`  
Version: `0.4.0`
