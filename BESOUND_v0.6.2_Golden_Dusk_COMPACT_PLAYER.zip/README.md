# BESOUND v0.6.2 – Golden Dusk Compact Player

Perubahan dari v0.6.1:
- Ukuran cover Now Playing dibuat responsif terhadap lebar dan tinggi area player (maksimum 228dp, 30% tinggi area).
- Memperbaiki urutan modifier cover yang sebelumnya membuat cover melebar memenuhi layar.
- Ruang vertikal dirapikan agar kontrol player lebih mudah terlihat pada layar ponsel.
- Nomor versi Android diperbarui menjadi 0.6.2 (versionCode 8).
- Nama artifact GitHub Actions diperbarui menjadi BESOUND-v0.6.2-APK.

Build APK belum dijalankan di lingkungan ini. Jalankan workflow GitHub Actions untuk verifikasi build akhir.
