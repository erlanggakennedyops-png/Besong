# BESOUND v0.6.0 – Golden Dusk

Pembaruan ini melanjutkan navigasi v0.5.x dan memoles pengalaman pemutar.

## Perubahan v0.6.0
- Mini player kini memiliki tombol Previous, Play/Pause, Next, dan Lyrics saat ada lagu aktif.
- Mini player menampilkan keadaan kosong yang lebih jelas ketika belum ada lagu dipilih.
- Tombol navigasi mini player menjalankan kontrol pada antrean ExoPlayer yang sama.
- Cover placeholder Now Playing diperkecil agar kontrol lebih mudah dijangkau di layar HP.
- Nomor versi aplikasi dan nama artifact diperbarui ke 0.6.0.
- Database Room dan koleksi musik lokal tetap dipertahankan.

## Yang belum aktif
- Bei Song masih belum menerbitkan lagu ke pengguna lain.
- Global Music masih berupa halaman awal, belum memiliki katalog streaming.
- Login, cloud upload, hak admin, lisensi katalog global, dan premium/offline belum dibuat. Fitur tersebut membutuhkan backend dan sumber musik yang sah; jangan menganggap placeholder sebagai layanan aktif.

## Upload ke GitHub
1. Ekstrak ZIP.
2. Upload isi folder project root (folder yang berisi `app`, `gradle.properties`, `settings.gradle.kts`, dan `.github`) ke repository.
3. Timpa file lama jika diminta, lalu commit.
4. Buka Actions dan jalankan **Build BESOUND Android APK**.
5. Jika berhasil, unduh artifact `BESOUND-v0.6.0-APK`.

Build APK belum dijalankan di lingkungan pembuatan ZIP ini. Jalankan workflow GitHub untuk verifikasi build.
