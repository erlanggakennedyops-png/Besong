package com.bei.besound

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.Context
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.media.MediaMetadataRetriever
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import java.io.File
import java.util.UUID
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.contract.ActivityResultContract
import androidx.core.content.ContextCompat
import androidx.media3.ui.PlayerNotificationManager
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.support.v4.media.MediaMetadataCompat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

var Cream by mutableStateOf(Color(0xFF17120F))
var CreamCard by mutableStateOf(Color(0xFF2A1C16))
var Orange by mutableStateOf(Color(0xFFFF8A32))
var Golden by mutableStateOf(Color(0xFFFFC15A))
var Ink by mutableStateOf(Color(0xFFFFE8CE))
var Muted by mutableStateOf(Color(0xFFB99B80))
private var NavSurface by mutableStateOf(Color(0xFF211711))
private var DividerTone by mutableStateOf(Color(0xFF493123))

private fun applyPalette(name: String) {
    when (name) {
        "Cream Light" -> {
            Cream = Color(0xFFFFF8ED); CreamCard = Color(0xFFFFE8CC)
            Orange = Color(0xFFE58B3A); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFF33291F); Muted = Color(0xFF8B7866)
            NavSurface = Color(0xFFFFF1DE); DividerTone = Color(0xFFEFE2D2)
        }
        "Midnight" -> {
            Cream = Color(0xFF10131B); CreamCard = Color(0xFF202633)
            Orange = Color(0xFFFF8B45); Golden = Color(0xFFFFC56E)
            Ink = Color(0xFFF5F0E9); Muted = Color(0xFFA6A9B4)
            NavSurface = Color(0xFF191E29); DividerTone = Color(0xFF343B49)
        }
        else -> {
            Cream = Color(0xFF17120F); CreamCard = Color(0xFF2A1C16)
            Orange = Color(0xFFFF8A32); Golden = Color(0xFFFFC15A)
            Ink = Color(0xFFFFE8CE); Muted = Color(0xFFB99B80)
            NavSurface = Color(0xFF211711); DividerTone = Color(0xFF493123)
        }
    }
}



/**
 * Opens audio documents with read + write grants so BESOUND can update ID3 tags
 * (including embedded album artwork) in the selected MP3 file.
 */
private class OpenMultipleAudioDocuments : ActivityResultContract<Array<String>, List<Uri>>() {
    override fun createIntent(context: Context, input: Array<String>): Intent {
        return Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = input.firstOrNull() ?: "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
    }

    override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> {
        if (resultCode != android.app.Activity.RESULT_OK || intent == null) return emptyList()
        val result = mutableListOf<Uri>()
        intent.clipData?.let { clip ->
            for (index in 0 until clip.itemCount) {
                clip.getItemAt(index).uri?.let(result::add)
            }
        }
        intent.data?.let { if (it !in result) result.add(it) }
        return result.distinct()
    }
}

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var mediaSession: MediaSessionCompat
    private lateinit var notificationManager: PlayerNotificationManager
    private val notificationChannelId = "besound_playback"
    private val notificationId = 4101
    // Cache artwork by its private persisted URI. Never decode a full cover on every UI tick.
    private var cachedArtworkUri: String? = null
    private var cachedArtworkBitmap: android.graphics.Bitmap? = null
    // Cache artwork embedded in the active MP3 for Android media surfaces.
    private var cachedEmbeddedArtworkKey: String? = null
    private var cachedEmbeddedArtworkBitmap: android.graphics.Bitmap? = null
    // Room is the source of truth for covers selected in the in-app editor.
    // A known track with a null cover must use the BESOUND fallback, not stale player metadata.
    @Volatile private var trackArtworkUris: Map<String, String?> = emptyMap()
    private var lastCompatMetadataKey: String? = null

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        BeiSongCloud.handleRecoveryIntent(intent)
        PlaylistCloud.handleShareIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        BeiSongCloud.handleRecoveryIntent(intent)
        PlaylistCloud.handleShareIntent(intent)

        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true
            )
        }

        createPlaybackNotificationChannel()
        mediaSession = MediaSessionCompat(this, "BESOUND").apply {
            setFlags(
                MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or
                    MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS
            )
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { player.play() }
                override fun onPause() { player.pause() }
                override fun onSkipToNext() { if (player.hasNextMediaItem()) player.seekToNextMediaItem() }
                override fun onSkipToPrevious() { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() }
                override fun onSeekTo(pos: Long) { player.seekTo(pos) }
                override fun onStop() { player.pause(); player.seekTo(0L) }
            })
            isActive = true
        }
        notificationManager = PlayerNotificationManager.Builder(
            this, notificationId, notificationChannelId
        )
            .setMediaDescriptionAdapter(object : PlayerNotificationManager.MediaDescriptionAdapter {
                override fun getCurrentContentTitle(player: Player): CharSequence {
                    return player.mediaMetadata.title ?: "BESOUND"
                }
                override fun createCurrentContentIntent(player: Player): PendingIntent? {
                    val intent = Intent(this@MainActivity, MainActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                    }
                    return PendingIntent.getActivity(
                        this@MainActivity, 0, intent,
                        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                    )
                }
                override fun getCurrentContentText(player: Player): CharSequence? {
                    return player.mediaMetadata.artist
                }
                override fun getCurrentLargeIcon(
                    player: Player,
                    callback: PlayerNotificationManager.BitmapCallback
                ): android.graphics.Bitmap? {
                    // Use each track's selected cover when available. If a track has
                    // no cover (or its file cannot be decoded), use BESOUND artwork.
                    return loadEmbeddedArtworkBitmap(player)
                        ?: resolveCurrentArtworkUri(player)?.let { loadArtworkBitmapCached(it) }
                        ?: loadDefaultArtworkBitmap()
                }
            })
            .setNotificationListener(object : PlayerNotificationManager.NotificationListener {})
            .build()
            .apply {
                setMediaSessionToken(mediaSession.sessionToken)
                setUseNextAction(true)
                setUsePreviousAction(true)
                setUsePlayPauseActions(true)
                setPlayer(player)
            }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 4102)
        }

        val dao = MusicDatabase.get(this).songDao()

        setContent {
            val scope = rememberCoroutineScope()
            val songs by dao.observeAll().collectAsState(initial = emptyList())

            var currentUri by remember { mutableStateOf<String?>(null) }
            var externalSong by remember { mutableStateOf<SongEntity?>(null) }
            var isPlaying by remember { mutableStateOf(false) }
            var positionMs by remember { mutableLongStateOf(0L) }
            var durationMs by remember { mutableLongStateOf(0L) }
            var shuffleEnabled by remember { mutableStateOf(false) }
            var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
            var selectedTab by remember { mutableIntStateOf(if (BeiSongCloud.recoveryToken != null) 1 else if (PlaylistCloud.sharedToken != null) 6 else 0) }
            LaunchedEffect(BeiSongCloud.recoveryToken) {
                if (BeiSongCloud.recoveryToken != null) selectedTab = 1
            }
            LaunchedEffect(PlaylistCloud.sharedToken) {
                if (PlaylistCloud.sharedToken != null) selectedTab = 6
            }
            var previousTab by remember { mutableIntStateOf(0) }
            var showExitDialog by remember { mutableStateOf(false) }
            var searchText by remember { mutableStateOf("") }
            var searchCategory by remember { mutableStateOf("All Song") }
            var libraryFilter by remember { mutableStateOf("All Songs") }
            var downloadedFiles by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
            var downloadingUri by remember { mutableStateOf<String?>(null) }
            var showLyrics by remember { mutableStateOf(false) }
            var showEditor by remember { mutableStateOf(false) }
            var editingSong by remember { mutableStateOf<SongEntity?>(null) }
            var editTitle by remember { mutableStateOf("") }
            var editArtist by remember { mutableStateOf("") }
            var editAlbum by remember { mutableStateOf("") }
            var editLyrics by remember { mutableStateOf("") }
            var editCoverUri by remember { mutableStateOf<String?>(null) }
            var deletingSong by remember { mutableStateOf<SongEntity?>(null) }
            var themeName by remember { mutableStateOf(getPreferences(MODE_PRIVATE).getString("besound_theme", "Golden Dusk") ?: "Golden Dusk") }
            var showThemeMenu by remember { mutableStateOf(false) }
            var showNowOptions by remember { mutableStateOf(false) }
            SideEffect { applyPalette(themeName) }
            LaunchedEffect(themeName) { getPreferences(MODE_PRIVATE).edit().putString("besound_theme", themeName).apply() }

            val currentSong = songs.firstOrNull { it.uri == currentUri } ?: externalSong?.takeIf { it.uri == currentUri }
            var recentPlayedUris by remember {
                mutableStateOf(
                    getSharedPreferences("besound_recently_played", MODE_PRIVATE)
                        .getString("uris", "")
                        .orEmpty()
                        .split("\n")
                        .filter { it.isNotBlank() }
                        .take(10)
                )
            }

            fun recordRecentlyPlayed(uri: String) {
                val updated = (listOf(uri) + recentPlayedUris.filterNot { it == uri }).take(10)
                recentPlayedUris = updated
                getSharedPreferences("besound_recently_played", MODE_PRIVATE)
                    .edit().putString("uris", updated.joinToString("\n")).apply()
            }

            val recentSongs = recentPlayedUris.mapNotNull { uri -> songs.firstOrNull { it.uri == uri } }

            // Public offline copies are indexed in shared Internal Storage/Music/BESOUND. Room stays unchanged.
            LaunchedEffect(songs) {
                val prefs = getSharedPreferences("besound_offline", MODE_PRIVATE)
                val restored = prefs.all.mapNotNull { (key, value) ->
                    val originalUri = key.removePrefix("offline:")
                    val savedLocation = value as? String
                    val exists = if (savedLocation.isNullOrBlank()) false else runCatching {
                        val savedUri = Uri.parse(savedLocation)
                        if (savedUri.scheme == "content") contentResolver.query(savedUri, arrayOf(MediaStore.Audio.Media._ID), null, null, null)?.use { it.moveToFirst() } == true
                        else File(savedLocation).exists()
                    }.getOrDefault(false)
                    if (key.startsWith("offline:") && exists) originalUri to savedLocation!! else null
                }.toMap()
                downloadedFiles = restored
                prefs.edit().apply {
                    prefs.all.keys.filter { it.startsWith("offline:") && it.removePrefix("offline:") !in restored.keys }.forEach { remove(it) }
                }.apply()
            }

            // Keep notification/lock-screen artwork in sync with the cover saved in Room.
            // This also handles covers selected from the editor after playback has started.
            LaunchedEffect(songs) {
                trackArtworkUris = songs.associate { it.uri to it.coverUri }
                cachedArtworkUri = null
                cachedArtworkBitmap = null
                updateCompatMediaSession(forceMetadata = true)
                if (::notificationManager.isInitialized) notificationManager.invalidate()
            }

            // Repair legacy placeholder titles such as "msf:114295" using the actual file name.
            LaunchedEffect(songs) {
                songs.filter {
                    it.title.isBlank() || it.title.startsWith("msf:", ignoreCase = true) ||
                        it.title.equals("Untitled", ignoreCase = true)
                }.forEach { song ->
                    val recoveredTitle = displayNameFor(Uri.parse(song.uri))
                    if (recoveredTitle.isNotBlank() && recoveredTitle != song.title) {
                        dao.upsert(song.copy(title = recoveredTitle))
                    }
                }
            }

            val filteredSongs = remember(songs, searchText, libraryFilter, downloadedFiles) {
                val base = if (libraryFilter == "Downloaded") songs.filter { downloadedFiles.containsKey(it.uri) } else songs
                if (searchText.isBlank()) base
                else base.filter {
                    it.title.contains(searchText, true) ||
                        it.artist.contains(searchText, true) ||
                        it.album.contains(searchText, true)
                }
            }

            fun saveSongOffline(song: SongEntity) {
                if (downloadedFiles.containsKey(song.uri) || downloadingUri == song.uri) return
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q &&
                    ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 5201)
                    android.widget.Toast.makeText(this@MainActivity, "Izinkan akses penyimpanan, lalu tekan Download lagi.", android.widget.Toast.LENGTH_LONG).show()
                    return
                }
                downloadingUri = song.uri
                scope.launch {
                    val result = runCatching {
                        withContext(Dispatchers.IO) {
                            val sourceUri = Uri.parse(song.uri)
                            val sourceName = displayNameFor(sourceUri).ifBlank { song.title }
                            val extension = sourceName.substringAfterLast('.', "mp3").lowercase().let { if (it.matches(Regex("[a-z0-9]{2,5}"))) it else "mp3" }
                            val safeName = song.title.replace(Regex("[^A-Za-z0-9._-]"), "_").trim('_').take(64).ifBlank { "BESOUND_Track" }
                            val displayName = "${safeName}.${extension}"
                            val input = if (sourceUri.scheme == "file") File(requireNotNull(sourceUri.path)).inputStream()
                                else contentResolver.openInputStream(sourceUri) ?: error("File sumber tidak bisa dibaca")
                            input.use { source ->
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                                    val values = ContentValues().apply {
                                        put(MediaStore.Audio.Media.DISPLAY_NAME, displayName)
                                        put(MediaStore.Audio.Media.MIME_TYPE, when (extension) { "m4a" -> "audio/mp4"; "wav" -> "audio/wav"; "flac" -> "audio/flac"; "ogg" -> "audio/ogg"; else -> "audio/mpeg" })
                                        put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/BESOUND")
                                        put(MediaStore.Audio.Media.IS_PENDING, 1)
                                    }
                                    val destination = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
                                        ?: error("Tidak bisa membuat file di Music/BESOUND")
                                    try {
                                        contentResolver.openOutputStream(destination, "w")?.use { output -> source.copyTo(output) }
                                            ?: error("Tidak bisa menulis file unduhan")
                                        val ready = ContentValues().apply { put(MediaStore.Audio.Media.IS_PENDING, 0) }
                                        contentResolver.update(destination, ready, null, null)
                                        destination.toString()
                                    } catch (e: Exception) {
                                        contentResolver.delete(destination, null, null)
                                        throw e
                                    }
                                } else {
                                    val musicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC), "BESOUND")
                                    if (!musicDir.exists() && !musicDir.mkdirs()) error("Folder Music/BESOUND tidak bisa dibuat")
                                    val destination = File(musicDir, displayName)
                                    source.use { inputStream -> destination.outputStream().use { output -> inputStream.copyTo(output) } }
                                    destination.absolutePath
                                }
                            }
                        }
                    }
                    result.onSuccess { savedLocation ->
                        getSharedPreferences("besound_offline", MODE_PRIVATE).edit().putString("offline:${song.uri}", savedLocation).apply()
                        downloadedFiles = downloadedFiles + (song.uri to savedLocation)
                        android.widget.Toast.makeText(this@MainActivity, "Tersimpan di Music/BESOUND", android.widget.Toast.LENGTH_SHORT).show()
                    }.onFailure { error ->
                        android.widget.Toast.makeText(this@MainActivity, "Download gagal: ${error.message ?: "file tidak dapat disimpan"}", android.widget.Toast.LENGTH_LONG).show()
                    }
                    downloadingUri = null
                }
            }

            fun removeOfflineCopy(song: SongEntity) {
                downloadedFiles[song.uri]?.let { savedLocation ->
                    runCatching {
                        val savedUri = Uri.parse(savedLocation)
                        if (savedUri.scheme == "content") contentResolver.delete(savedUri, null, null)
                        else File(savedLocation).delete()
                    }
                }
                getSharedPreferences("besound_offline", MODE_PRIVATE).edit().remove("offline:${song.uri}").apply()
                downloadedFiles = downloadedFiles - song.uri
                android.widget.Toast.makeText(this@MainActivity, "Unduhan ${song.title} dihapus. Lagu asli tetap aman.", android.widget.Toast.LENGTH_SHORT).show()
            }

            val coverPicker = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    // Copy the selected image into BESOUND's private storage.
                    // The cover then survives deletion/moving of the original gallery file.
                    editCoverUri = persistArtwork(uri)?.toString()
                    if (editCoverUri == null) {
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "Cover gagal disimpan. Coba pilih foto lain.",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }

            val audioPicker = rememberLauncherForActivityResult(
                OpenMultipleAudioDocuments()
            ) { uris ->
                uris.forEach { uri ->
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                                Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        )
                    }.onFailure {
                        // Some document providers grant read access only. Playback remains
                        // available, but embedded-tag editing will report a clear write error.
                        runCatching {
                            contentResolver.takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        }
                    }
                    val metadata = readMetadata(uri)
                    val fallbackTitle = displayNameFor(uri)
                    scope.launch {
                        // Re-selecting an already imported MP3 can refresh its persisted
                        // read/write document grant. Keep its lyrics and selected cover intact.
                        val existing = dao.getByUri(uri.toString())
                        if (existing != null) {
                            dao.upsert(existing)
                        } else {
                            dao.upsert(
                                SongEntity(
                                    uri = uri.toString(),
                                    title = metadata.first.ifBlank { fallbackTitle },
                                    artist = metadata.second.ifBlank { "Unknown artist" },
                                    album = metadata.third.ifBlank { "Unknown album" }
                                )
                            )
                        }
                    }
                }
            }

            fun playSong(song: SongEntity, openPlayer: Boolean = true) {
                val index = songs.indexOfFirst { it.uri == song.uri }
                currentUri = song.uri
                if (index >= 0) {
                    externalSong = null
                    recordRecentlyPlayed(song.uri)
                    player.setMediaItems(songs.map { item ->
                        MediaItem.Builder()
                            .setMediaId(item.uri)
                            .setUri(downloadedFiles[item.uri]?.let { Uri.parse(it) } ?: Uri.parse(item.uri))
                            .setMediaMetadata(
                                androidx.media3.common.MediaMetadata.Builder()
                                    .setTitle(item.title)
                                    .setArtist(item.artist)
                                    .setAlbumTitle(item.album)
                                    .apply { item.coverUri?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) } }
                                    .build()
                            ).build()
                    }, index, 0L)
                } else {
                    externalSong = song
                    player.setMediaItem(
                        MediaItem.Builder().setMediaId(song.uri).setUri(Uri.parse(song.uri))
                            .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                                .setTitle(song.title).setArtist(song.artist).setAlbumTitle(song.album)
                                .apply { song.coverUri?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) } }
                                .build()).build()
                    )
                }
                player.prepare()
                player.play()
                isPlaying = true
                if (openPlayer) { previousTab = selectedTab; selectedTab = 5 }
            }

            fun playPlaylistQueue(queue: List<PlaylistCloud.Track>, startIndex: Int) {
                if (queue.isEmpty()) return
                val safeIndex = startIndex.coerceIn(0, queue.lastIndex)
                val mediaItems = queue.map { track ->
                    MediaItem.Builder()
                        .setMediaId(track.audioUrl)
                        .setUri(Uri.parse(track.audioUrl))
                        .setMediaMetadata(androidx.media3.common.MediaMetadata.Builder()
                            .setTitle(track.title)
                            .setArtist(track.artist)
                            .setAlbumTitle("BESOUND Playlist")
                            .apply { track.coverUrl?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) } }
                            .build())
                        .build()
                }
                val track = queue[safeIndex]
                currentUri = track.audioUrl
                externalSong = SongEntity(uri = track.audioUrl, title = track.title, artist = track.artist, album = "BESOUND Playlist", lyrics = "", coverUri = track.coverUrl)
                recordRecentlyPlayed(track.audioUrl)
                player.setMediaItems(mediaItems, safeIndex, 0L)
                player.prepare()
                player.play()
                isPlaying = true
                previousTab = selectedTab
                selectedTab = 5
            }

            fun openEditor(song: SongEntity) {
                editingSong = song
                editTitle = song.title
                editArtist = song.artist
                editAlbum = song.album
                editLyrics = song.lyrics
                editCoverUri = song.coverUri
                showEditor = true
            }

            LaunchedEffect(Unit) {
                while (true) {
                    isPlaying = player.isPlaying
                    positionMs = player.currentPosition.coerceAtLeast(0L)
                    durationMs = player.duration.takeIf { it > 0L } ?: 0L
                    updateCompatPlaybackState()
                    // Do not infer a selected track from ExoPlayer's default index (0).
                    // A track is selected only when the player actually has a media item.
                    val activeItem = player.currentMediaItem
                    currentUri = activeItem?.mediaId
                    if (activeItem != null && songs.none { it.uri == activeItem.mediaId }) {
                        val metadata = activeItem.mediaMetadata
                        externalSong = SongEntity(
                            uri = activeItem.mediaId,
                            title = metadata.title?.toString().orEmpty(),
                            artist = metadata.artist?.toString().orEmpty(),
                            album = metadata.albumTitle?.toString().orEmpty(),
                            lyrics = "",
                            coverUri = metadata.artworkUri?.toString()
                        )
                    }
                    delay(400)
                }
            }

            DisposableEffect(player) {
                val listener = object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) {
                        isPlaying = playing
                        updateCompatMediaSession()
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        currentUri = mediaItem?.mediaId
                        if (mediaItem != null && songs.none { it.uri == mediaItem.mediaId }) {
                            val metadata = mediaItem.mediaMetadata
                            externalSong = SongEntity(
                                uri = mediaItem.mediaId,
                                title = metadata.title?.toString().orEmpty(),
                                artist = metadata.artist?.toString().orEmpty(),
                                album = metadata.albumTitle?.toString().orEmpty(),
                                lyrics = "",
                                coverUri = metadata.artworkUri?.toString()
                            )
                        }
                        mediaItem?.mediaId?.let { recordRecentlyPlayed(it) }
                        // Media3 does not guarantee that a notification rebuilds its large icon
                        // just because a MediaItem's artwork metadata changed.
                        updateCompatMediaSession(forceMetadata = true)
                        if (::notificationManager.isInitialized) notificationManager.invalidate()
                    }
                    override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
                        updateCompatMediaSession(forceMetadata = true)
                        if (::notificationManager.isInitialized) notificationManager.invalidate()
                    }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        durationMs = player.duration.takeIf { it > 0L } ?: 0L
                        updateCompatMediaSession()
                    }
                    override fun onPositionDiscontinuity(
                        oldPosition: Player.PositionInfo,
                        newPosition: Player.PositionInfo,
                        reason: Int
                    ) {
                        updateCompatPlaybackState()
                    }
                }
                player.addListener(listener)
                onDispose { player.removeListener(listener) }
            }

            BackHandler(enabled = true) {
                when {
                    showLyrics -> showLyrics = false
                    selectedTab == 5 -> selectedTab = previousTab.coerceIn(0, 6)
                    selectedTab == 7 || selectedTab == 8 -> selectedTab = 0
                    selectedTab != 0 -> selectedTab = 0
                    else -> showExitDialog = true
                }
            }

            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Orange,
                    onPrimary = Color.White,
                    secondary = Golden,
                    background = Cream,
                    surface = Cream,
                    onBackground = Ink,
                    onSurface = Ink,
                    onSurfaceVariant = Muted,
                    surfaceVariant = CreamCard,
                    secondaryContainer = CreamCard,
                    onSecondaryContainer = Ink
                )
            ) {
                Scaffold(
                    containerColor = Cream,
                    bottomBar = {
                        if (!showLyrics && selectedTab != 8) NavigationBar(containerColor = NavSurface) {
                            val navItems = listOf(
                                Triple("Home", Icons.Default.Home, 0),
                                Triple("Playlist", Icons.Default.QueueMusic, 6),
                                Triple("Library", Icons.Default.LibraryMusic, 3),
                                Triple("Profile", Icons.Default.Person, 4)
                            )
                            navItems.forEach { item ->
                                NavigationBarItem(
                                    selected = selectedTab == item.third || (selectedTab == 5 && item.third == 0),
                                    onClick = { selectedTab = item.third },
                                    icon = { Icon(item.second, contentDescription = item.first) },
                                    label = { Text(item.first, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Orange,
                                        selectedTextColor = Ink,
                                        indicatorColor = CreamCard,
                                        unselectedIconColor = Muted,
                                        unselectedTextColor = Muted
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    Column(
                        Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)
                    ) {
                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (selectedTab == 0) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("BESOUND", fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink, letterSpacing = (-0.8).sp)
                                    Spacer(Modifier.width(7.dp))
                                    AudioVisualizer(isPlaying = isPlaying, barColor = Orange, modifier = Modifier.height(25.dp))
                                }
                            } else {
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        if (selectedTab == 8) "Search" else "BESOUND",
                                        fontSize = 28.sp,
                                        fontWeight = FontWeight.Black,
                                        color = Ink,
                                        letterSpacing = (-0.8).sp
                                    )
                                    if (selectedTab != 8) Text(
                                        "Your music. Your lyrics. Your world.",
                                        color = Muted,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                            if (selectedTab == 5) {
                                Box {
                                    IconButton(onClick = { showNowOptions = true }) {
                                        Icon(Icons.Default.MoreVert, "Menu lainnya", tint = Orange, modifier = Modifier.size(29.dp))
                                    }
                                    DropdownMenu(
                                        expanded = showNowOptions,
                                        onDismissRequest = { showNowOptions = false },
                                        containerColor = CreamCard,
                                        tonalElevation = 8.dp,
                                        shadowElevation = 8.dp
                                    ) {
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Share, null, tint = Orange)
                                                    Spacer(Modifier.width(12.dp))
                                                    Text("Share", color = Ink)
                                                }
                                            },
                                            onClick = {
                                                showNowOptions = false
                                                currentSong?.let { song ->
                                                    val shareText = "Dengarkan ${song.title} - ${song.artist} di BESOUND."
                                                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                                        type = "text/plain"
                                                        putExtra(Intent.EXTRA_TEXT, shareText)
                                                    }
                                                    startActivity(Intent.createChooser(sendIntent, "Bagikan lagu"))
                                                }
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.PlaylistAdd, null, tint = Orange)
                                                    Spacer(Modifier.width(12.dp))
                                                    Text("Add to Playlist", color = Ink)
                                                }
                                            },
                                            onClick = {
                                                showNowOptions = false
                                                selectedTab = 6
                                            }
                                        )
                                    }
                                }
                            } else {
                                if (selectedTab == 8) {
                                    IconButton(onClick = { selectedTab = 0 }) {
                                        Icon(Icons.Default.ArrowBack, "Kembali", tint = Ink, modifier = Modifier.size(25.dp))
                                    }
                                } else {
                                    IconButton(onClick = { searchText = ""; searchCategory = "All Song"; selectedTab = 8 }) {
                                        Icon(Icons.Default.Search, "Cari musik", tint = Ink, modifier = Modifier.size(25.dp))
                                    }
                                }
                                Box {
                                    IconButton(onClick = { showThemeMenu = true }) {
                                        Icon(Icons.Default.Palette, "Ganti tema", tint = Orange, modifier = Modifier.size(30.dp))
                                    }
                                    DropdownMenu(
                                        expanded = showThemeMenu,
                                        onDismissRequest = { showThemeMenu = false },
                                        containerColor = CreamCard,
                                        tonalElevation = 8.dp,
                                        shadowElevation = 8.dp
                                    ) {
                                        listOf("Golden Dusk", "Cream Light", "Midnight").forEach { option ->
                                            DropdownMenuItem(
                                                text = {
                                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                                        Text(
                                                            option,
                                                            color = Ink,
                                                            fontWeight = if (themeName == option) FontWeight.Bold else FontWeight.Normal
                                                        )
                                                        if (themeName == option) {
                                                            Spacer(Modifier.width(12.dp))
                                                            Icon(Icons.Default.Check, contentDescription = "Tema aktif", tint = Orange)
                                                        }
                                                    }
                                                },
                                                onClick = { themeName = option; showThemeMenu = false }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))

                        if (selectedTab == 0) {
                            val nowSong = currentSong ?: songs.firstOrNull()
                            var lastBubbleSongUri by remember { mutableStateOf<String?>(null) }
                            var showNewTrackGreeting by remember { mutableStateOf(false) }
                            LaunchedEffect(currentSong?.uri) {
                                val latestUri = currentSong?.uri
                                if (latestUri != null && lastBubbleSongUri != null && latestUri != lastBubbleSongUri) {
                                    showNewTrackGreeting = true
                                    delay(2800)
                                    showNewTrackGreeting = false
                                }
                                lastBubbleSongUri = latestUri
                            }
                            val beiBubbleTitle = when {
                                showNewTrackGreeting -> "Lagu baru!"
                                currentSong == null -> "Hei, kamu!"
                                durationMs > 0L && positionMs >= durationMs -> "Satu cerita selesai!"
                                isPlaying -> "Asyik!"
                                else -> "Istirahat sebentar?"
                            }
                            val beiBubbleMessage = when {
                                showNewTrackGreeting -> "Wah, lagu baru! Gimana, suka? 🎵"
                                currentSong == null -> "Dunia boleh berisik, tapi di sini kita punya musik. 🎧"
                                durationMs > 0L && positionMs >= durationMs -> "Mau lanjut ke cerita berikutnya?"
                                isPlaying -> "Nikmati lagunya, aku temenin. 🎧"
                                else -> "Aku tunggu di sini. Putar lagi kapan pun kamu mau."
                            }
                            val homeContext = LocalContext.current
                            val extractedCoverColor by produceState(
                                initialValue = Color(0xFF75432E),
                                key1 = nowSong?.coverUri
                            ) {
                                value = withContext(Dispatchers.IO) {
                                    runCatching {
                                        val cover = nowSong?.coverUri
                                        if (cover.isNullOrBlank()) return@runCatching Color(0xFF75432E)
                                        val bitmap = homeContext.contentResolver.openInputStream(Uri.parse(cover))?.use { stream ->
                                            val bytes = stream.readBytes()
                                            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                                            val sample = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 48)
                                            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
                                        } ?: return@runCatching Color(0xFF75432E)
                                        var red = 0L; var green = 0L; var blue = 0L; var count = 0L
                                        val stepX = maxOf(1, bitmap.width / 18)
                                        val stepY = maxOf(1, bitmap.height / 18)
                                        for (y in 0 until bitmap.height step stepY) {
                                            for (x in 0 until bitmap.width step stepX) {
                                                val pixel = bitmap.getPixel(x, y)
                                                val alpha = android.graphics.Color.alpha(pixel)
                                                if (alpha > 180) {
                                                    red += android.graphics.Color.red(pixel)
                                                    green += android.graphics.Color.green(pixel)
                                                    blue += android.graphics.Color.blue(pixel)
                                                    count++
                                                }
                                            }
                                        }
                                        bitmap.recycle()
                                        if (count == 0L) Color(0xFF75432E) else {
                                            val r = (red / count).toInt()
                                            val g = (green / count).toInt()
                                            val b = (blue / count).toInt()
                                            // Lift dark averages slightly so the glow remains visible but subdued.
                                            Color(android.graphics.Color.rgb(maxOf(42, r), maxOf(30, g), maxOf(28, b)))
                                        }
                                    }.getOrDefault(Color(0xFF75432E))
                                }
                            }
                            val animatedCoverGlow by animateColorAsState(
                                targetValue = extractedCoverColor,
                                animationSpec = tween(900, easing = FastOutSlowInEasing),
                                label = "nowCoverGlow"
                            )
                            val glowTransition = rememberInfiniteTransition(label = "homeGlow")
                            val glowAlpha by glowTransition.animateFloat(
                                initialValue = 0.10f,
                                targetValue = 0.30f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(2800, easing = FastOutSlowInEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "glowAlpha"
                            )

                            Box(Modifier.fillMaxSize()) {
                                Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF1A100C), Color(0xFF21120C), Color(0xFF130E0B), Color(0xFF1B100B)))))
                                Box(Modifier.offset(x = (-105).dp, y = 12.dp).size(270.dp).background(Brush.radialGradient(listOf(Color(0x35FF7A24), Color(0x12D85A18), Color.Transparent)), CircleShape))
                                Box(Modifier.align(Alignment.TopEnd).offset(x = 125.dp, y = 265.dp).size(300.dp).background(Brush.radialGradient(listOf(Color(0x28FF9A36), Color(0x0EDB681F), Color.Transparent)), CircleShape))
                                Box(Modifier.align(Alignment.BottomStart).offset(x = (-125).dp, y = 100.dp).size(280.dp).background(Brush.radialGradient(listOf(Color(0x20C85A20), Color.Transparent)), CircleShape))
                                Column(
                                    Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 1.dp),
                                    verticalArrangement = Arrangement.spacedBy(15.dp)
                                ) {
                                // BESOUND mascot and speech bubble. The old YOUR DAILY SOUND banner is removed.
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 1.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Image(
                                        painter = painterResource(R.drawable.bei_mascot_robot),
                                        contentDescription = "BESOUND mascot",
                                        modifier = Modifier.weight(0.82f).height(132.dp),
                                        contentScale = ContentScale.Fit
                                    )
                                    Card(
                                        modifier = Modifier.weight(1.35f),
                                        shape = RoundedCornerShape(22.dp),
                                        colors = CardDefaults.cardColors(containerColor = Color(0xFF382016)),
                                        border = androidx.compose.foundation.BorderStroke(1.4.dp, Orange.copy(alpha = 0.9f)),
                                        elevation = CardDefaults.cardElevation(defaultElevation = 7.dp)
                                    ) {
                                        Column(
                                            Modifier.background(Brush.linearGradient(listOf(Color(0xFF542A18), Color(0xFF281710))))
                                                .padding(horizontal = 13.dp, vertical = 12.dp),
                                            verticalArrangement = Arrangement.spacedBy(5.dp)
                                        ) {
                                            Text(beiBubbleTitle, color = Golden, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            Text(beiBubbleMessage, color = Ink, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }

                                Card(
                                    modifier = Modifier.fillMaxWidth().clickable { selectedTab = 5 },
                                    shape = RoundedCornerShape(26.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF241812)),
                                    elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, animatedCoverGlow.copy(alpha = 0.42f))
                                ) {
                                    Column(
                                        Modifier.fillMaxWidth()
                                            .background(
                                                Brush.radialGradient(
                                                    colors = listOf(animatedCoverGlow.copy(alpha = 0.46f), Color(0xFF241710), Color(0xFF241710)),
                                                    radius = 760f
                                                )
                                            )
                                            .background(Brush.horizontalGradient(listOf(animatedCoverGlow.copy(alpha = 0.28f), Color(0xFF241710))))
                                            .padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 14.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            if (nowSong != null) {
                                                SongArtwork(nowSong, Modifier.size(104.dp).clip(RoundedCornerShape(17.dp)), largeFallback = true)
                                            } else {
                                                Box(Modifier.size(104.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Orange, Golden))), contentAlignment = Alignment.Center) {
                                                    Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(42.dp))
                                                }
                                            }
                                            Spacer(Modifier.width(13.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(nowSong?.title ?: "Belum ada lagu diputar", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Text(nowSong?.artist ?: "Tambahkan musik ke Library", color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                Spacer(Modifier.height(5.dp))
                                                AudioVisualizer(isPlaying = isPlaying, barColor = Orange, modifier = Modifier.fillMaxWidth().height(30.dp), fillBars = true)
                                                Spacer(Modifier.height(1.dp))
                                                Slider(
                                                    value = if (durationMs > 0L && currentSong != null) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f,
                                                    onValueChange = { fraction -> if (durationMs > 0L) player.seekTo((durationMs * fraction).toLong()) },
                                                    enabled = player.currentMediaItem != null && durationMs > 0L,
                                                    modifier = Modifier.fillMaxWidth().height(24.dp),
                                                    colors = SliderDefaults.colors(thumbColor = Golden, activeTrackColor = Orange, inactiveTrackColor = DividerTone)
                                                )
                                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                    Text(formatTime(positionMs), color = Muted, fontSize = 9.sp)
                                                    Text(formatTime(durationMs), color = Muted, fontSize = 9.sp)
                                                }
                                            }
                                        }
                                        Spacer(Modifier.height(5.dp))
                                        Row(
                                            Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceEvenly,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            IconButton(onClick = {
                                                shuffleEnabled = !shuffleEnabled
                                                player.shuffleModeEnabled = shuffleEnabled
                                            }) { Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffleEnabled) Golden else Ink) }
                                            IconButton(onClick = {
                                                if (player.currentMediaItem == null && nowSong != null) playSong(nowSong, false)
                                                else if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                                else if (player.currentMediaItem != null) player.seekTo(0L)
                                            }) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Ink, modifier = Modifier.size(27.dp)) }
                                            Box(
                                                Modifier.size(52.dp).clip(CircleShape)
                                                    .background(Brush.linearGradient(listOf(Orange, Golden)))
                                                    .clickable {
                                                        if (nowSong != null) {
                                                            if (currentSong?.uri == nowSong.uri && player.currentMediaItem != null) {
                                                                if (player.isPlaying) player.pause() else player.play()
                                                            } else playSong(nowSong, false)
                                                        }
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pause" else "Play", tint = Color.White, modifier = Modifier.size(30.dp))
                                            }
                                            IconButton(onClick = {
                                                if (player.currentMediaItem == null && nowSong != null) playSong(nowSong, false)
                                                else if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                            }) { Icon(Icons.Default.SkipNext, "Next", tint = Ink, modifier = Modifier.size(27.dp)) }
                                            IconButton(onClick = {
                                                repeatMode = when (repeatMode) {
                                                    Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                                    Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                                    else -> Player.REPEAT_MODE_OFF
                                                }
                                                player.repeatMode = repeatMode
                                            }) { Icon(Icons.Default.Repeat, "Repeat", tint = if (repeatMode != Player.REPEAT_MODE_OFF) Golden else Ink) }
                                        }
                                    }
                                }

                                // Two large destinations replace the old four shortcut buttons.
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Card(
                                        modifier = Modifier.weight(1f).height(174.dp).clickable { selectedTab = 1 },
                                        shape = RoundedCornerShape(21.dp),
                                        colors = CardDefaults.cardColors(containerColor = CreamCard),
                                        border = androidx.compose.foundation.BorderStroke(1.25.dp, Orange.copy(alpha = 0.9f))
                                    ) {
                                        Box(Modifier.fillMaxSize()) {
                                            Image(painterResource(R.drawable.bei_song_mask), "Bei Song masked artist", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE1C100B)))))
                                            Column(Modifier.align(Alignment.BottomStart).padding(11.dp)) {
                                                Text("BEI SONG", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                                                Text("Karya Original Be.i", color = Color(0xFFFFD8B5), fontSize = 10.sp)
                                            }
                                        }
                                    }
                                    Card(
                                        modifier = Modifier.weight(1f).height(174.dp).clickable { selectedTab = 2 },
                                        shape = RoundedCornerShape(21.dp),
                                        colors = CardDefaults.cardColors(containerColor = CreamCard),
                                        border = androidx.compose.foundation.BorderStroke(1.25.dp, Orange.copy(alpha = 0.9f))
                                    ) {
                                        Box(Modifier.fillMaxSize()) {
                                            Image(painterResource(R.drawable.global_music_city), "Global Music city at night", Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                                            Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xEE1C100B)))))
                                            Column(Modifier.align(Alignment.BottomStart).padding(11.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(Icons.Default.Public, null, tint = Golden, modifier = Modifier.size(21.dp))
                                                    Spacer(Modifier.width(6.dp))
                                                    Text("GLOBAL MUSIC", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                                }
                                                Text("Jelajahi Musik Dunia", color = Color(0xFFFFD8B5), fontSize = 10.sp)
                                            }
                                        }
                                    }
                                }

                                // Recently Played: compact vertical rows, matching the approved Home layout.
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Recently Played", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    TextButton(onClick = { selectedTab = 7 }) { Text("Lihat Semua  ›", color = Orange, fontSize = 12.sp) }
                                }
                                if (recentSongs.isEmpty()) {
                                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp)) {
                                        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.MusicNote, null, tint = Golden, modifier = Modifier.size(30.dp))
                                            Spacer(Modifier.width(10.dp))
                                            Column {
                                                Text("Belum ada lagu", color = Ink, fontWeight = FontWeight.Bold)
                                                Text("Tambahkan musik ke Library untuk memulai.", color = Muted, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                        recentSongs.forEach { song ->
                                            Row(
                                                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CreamCard)
                                                    .clickable { playSong(song, false) }.padding(8.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                SongArtwork(song, Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)))
                                                Spacer(Modifier.width(11.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Text(song.title, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text(song.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                                val isThisRecentPlaying = currentUri == song.uri && isPlaying
                                                IconButton(onClick = {
                                                    if (currentUri == song.uri && player.currentMediaItem != null) {
                                                        if (player.isPlaying) player.pause() else player.play()
                                                    } else {
                                                        playSong(song, false)
                                                    }
                                                }) {
                                                    Icon(
                                                        if (isThisRecentPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                                        if (isThisRecentPlaying) "Jeda ${song.title}" else "Putar ${song.title}",
                                                        tint = Orange,
                                                        modifier = Modifier.size(27.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                }
                            }
                        } else if (selectedTab == 1 || selectedTab == 2) {
                            val isBeiSong = selectedTab == 1
                            if (isBeiSong) {
                                BeiSongCloudScreen(onPlaySong = { cloudSong ->
                                    scope.launch {
                                        val localTrack = SongEntity(
                                            uri = cloudSong.audioUrl,
                                            title = cloudSong.title,
                                            artist = cloudSong.artist,
                                            album = "BEI SONG",
                                            lyrics = cloudSong.lyrics.orEmpty(),
                                            coverUri = cloudSong.coverUrl
                                        )
                                        dao.upsert(localTrack)
                                        recordRecentlyPlayed(cloudSong.audioUrl)
                                        previousTab = 1
                                        currentUri = cloudSong.audioUrl
                                        player.setMediaItem(
                                            MediaItem.Builder()
                                                .setMediaId(cloudSong.audioUrl)
                                                .setUri(Uri.parse(cloudSong.audioUrl))
                                                .setMediaMetadata(
                                                    androidx.media3.common.MediaMetadata.Builder()
                                                        .setTitle(cloudSong.title)
                                                        .setArtist(cloudSong.artist)
                                                        .setAlbumTitle("BEI SONG")
                                                        .apply { cloudSong.coverUrl?.let { setArtworkUri(Uri.parse(it)) } }
                                                        .build()
                                                ).build()
                                        )
                                        player.prepare()
                                        player.play()
                                        isPlaying = true
                                        selectedTab = 5
                                    }
                                })
                            } else {
                                Text("GLOBAL MUSIC", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("Music from around the world", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(18.dp))
                                Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                    Column(Modifier.padding(18.dp)) {
                                        Icon(Icons.Default.Public, null, tint = Orange, modifier = Modifier.size(36.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text("Global Music", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                                        Text("Katalog musik global akan terhubung melalui sumber musik yang memiliki izin distribusi.", color = Muted, fontSize = 13.sp)
                                    }
                                }
                            }
                        } else if (selectedTab == 7) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { selectedTab = 0 }) {
                                    Icon(Icons.Default.ArrowBack, "Kembali", tint = Orange)
                                }
                                Column(Modifier.weight(1f)) {
                                    Text("HISTORY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("Recently Played", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("10 lagu terakhir yang kamu dengarkan", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            if (recentSongs.isEmpty()) {
                                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(18.dp)) {
                                    Text("Belum ada riwayat pemutaran.", color = Muted, modifier = Modifier.padding(18.dp))
                                }
                            } else {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    recentSongs.forEachIndexed { index, song ->
                                        Row(
                                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CreamCard)
                                                .clickable { playSong(song, false) }.padding(10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("${index + 1}", color = Muted, fontSize = 12.sp, modifier = Modifier.width(22.dp))
                                            SongArtwork(song, Modifier.size(52.dp).clip(RoundedCornerShape(11.dp)))
                                            Spacer(Modifier.width(10.dp))
                                            Column(Modifier.weight(1f)) {
                                                Text(song.title, color = Ink, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                                Text(song.artist, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                            }
                                            val isThisRecentPlaying = currentUri == song.uri && isPlaying
                                            IconButton(onClick = {
                                                if (currentUri == song.uri && player.currentMediaItem != null) {
                                                    if (player.isPlaying) player.pause() else player.play()
                                                } else playSong(song, false)
                                            }) {
                                                Icon(
                                                    if (isThisRecentPlaying) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                                    if (isThisRecentPlaying) "Jeda ${song.title}" else "Putar ${song.title}",
                                                    tint = Orange,
                                                    modifier = Modifier.size(27.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (selectedTab == 6) {
                            PlaylistCloudScreen(
                                onPlay = { queue, index -> playPlaylistQueue(queue, index) },
                                onRequestLogin = { selectedTab = 4 }
                            )
                        } else if (selectedTab == 4) {
                            var profileEmail by remember { mutableStateOf(PlaylistCloud.cachedSession(this@MainActivity)?.email.orEmpty()) }
                            var profilePassword by remember { mutableStateOf("") }
                            var profileConfirm by remember { mutableStateOf("") }
                            var profileSignup by remember { mutableStateOf(false) }
                            var profileBusy by remember { mutableStateOf(false) }
                            var profileMessage by remember { mutableStateOf("") }
                            val profileSession = PlaylistCloud.cachedSession(this@MainActivity)
                            Text("PROFILE", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("Your BESOUND account", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(16.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = CreamCard), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Icon(Icons.Default.AccountCircle, null, tint = Orange, modifier = Modifier.size(48.dp))
                                    Text(profileSession?.email ?: "Guest user", color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(if (profileSession == null) "Login atau buat akun untuk menyimpan playlist privat dan menyinkronkannya ke HP lain." else "Akun aktif. Playlist privatmu tersinkron melalui Supabase.", color = Muted, fontSize = 13.sp)
                                    if (profileSession == null) {
                                        OutlinedTextField(profileEmail, { profileEmail = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(profilePassword, { profilePassword = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        if (profileSignup) OutlinedTextField(profileConfirm, { profileConfirm = it }, label = { Text("Ulangi password") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        Button(onClick = {
                                            scope.launch {
                                                profileBusy = true
                                                profileMessage = ""
                                                try {
                                                    if (profileSignup) {
                                                        require(profilePassword.length >= 8) { "Password minimal 8 karakter." }
                                                        require(profilePassword == profileConfirm) { "Konfirmasi password tidak sama." }
                                                        val created = PlaylistCloud.signUp(this@MainActivity, profileEmail, profilePassword)
                                                        if (created) profileMessage = "Akun berhasil dibuat dan login." else profileMessage = "Akun dibuat. Periksa email untuk verifikasi, lalu login."
                                                    } else {
                                                        PlaylistCloud.signIn(this@MainActivity, profileEmail, profilePassword)
                                                        profileMessage = "Login berhasil. Playlist cloud siap disinkronkan."
                                                    }
                                                } catch (e: Exception) { profileMessage = e.message ?: "Autentikasi gagal." }
                                                profileBusy = false
                                            }
                                        }, enabled = !profileBusy && profileEmail.contains("@") && profilePassword.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                                            Text(if (profileSignup) "Buat Akun" else "Login")
                                        }
                                        TextButton(onClick = { profileSignup = !profileSignup; profileMessage = "" }) {
                                            Text(if (profileSignup) "Sudah punya akun? Login" else "Belum punya akun? Buat akun", color = Orange)
                                        }
                                    } else {
                                        Button(onClick = { selectedTab = 6 }, modifier = Modifier.fillMaxWidth()) { Text("Buka Playlist Cloud") }
                                        TextButton(onClick = {
                                            PlaylistCloud.clearSession(this@MainActivity)
                                            profilePassword = ""
                                            profileMessage = "Kamu sudah logout."
                                        }) { Text("Keluar", color = Orange) }
                                    }
                                    Divider(color = Muted.copy(alpha = 0.25f))
                                    Text("ADMIN BEI SONG", color = Orange, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    var adminEmail by remember { mutableStateOf(BeiSongCloud.ADMIN_EMAIL) }
                                    var adminPassword by remember { mutableStateOf("") }
                                    var adminBusy by remember { mutableStateOf(false) }
                                    var adminMessage by remember { mutableStateOf("") }
                                    if (BeiSongCloud.savedAdminToken(this@MainActivity) == null) {
                                        OutlinedTextField(adminEmail, { adminEmail = it }, label = { Text("Email admin") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                        OutlinedTextField(adminPassword, { adminPassword = it }, label = { Text("Password admin") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                                        OutlinedButton(onClick = {
                                            scope.launch {
                                                adminBusy = true
                                                try {
                                                    val token = BeiSongCloud.login(adminEmail.trim(), adminPassword)
                                                    BeiSongCloud.saveAdminToken(this@MainActivity, token)
                                                    adminPassword = ""
                                                    adminMessage = "Akses admin aktif. Buka tab BEI SONG untuk mengelola katalog."
                                                } catch (e: Exception) { adminMessage = e.message ?: "Login admin gagal." }
                                                adminBusy = false
                                            }
                                        }, enabled = !adminBusy && adminEmail.contains("@") && adminPassword.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (adminBusy) "Memproses..." else "Login Admin BEI SONG") }
                                    } else {
                                        Text("Akses admin aktif di perangkat ini.", color = Muted, fontSize = 12.sp)
                                        TextButton(onClick = { BeiSongCloud.clearAdminToken(this@MainActivity); adminMessage = "Akses admin dinonaktifkan." }) { Text("Keluar dari Admin", color = Orange) }
                                    }
                                    if (adminMessage.isNotBlank()) Text(adminMessage, color = Golden, fontSize = 12.sp)
                                    if (profileMessage.isNotBlank()) Text(profileMessage, color = Golden, fontSize = 12.sp)
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            OutlinedButton(onClick = { showThemeMenu = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Palette, null); Spacer(Modifier.width(8.dp)); Text("Ganti tema") }
                        } else if (selectedTab == 8) {
                            val searchResults = remember(songs, searchText, searchCategory) {
                                val categorySongs = when (searchCategory) {
                                    "Be.i Song" -> songs.filter { it.album.contains("BEI SONG", ignoreCase = true) || it.artist.contains("Be.i", ignoreCase = true) }
                                    "Global" -> songs.filter { it.album.contains("GLOBAL", ignoreCase = true) }
                                    else -> songs
                                }
                                if (searchText.isBlank()) categorySongs else categorySongs.filter {
                                    it.title.contains(searchText, true) || it.artist.contains(searchText, true) || it.album.contains(searchText, true)
                                }
                            }
                            Column(
                                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 12.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                OutlinedTextField(
                                    value = searchText,
                                    onValueChange = { searchText = it },
                                    modifier = Modifier.fillMaxWidth(),
                                    singleLine = true,
                                    placeholder = { Text("Search all song...", color = Muted) },
                                    leadingIcon = { Icon(Icons.Default.Search, null, tint = Orange) },
                                    shape = RoundedCornerShape(28.dp),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = Ink,
                                        unfocusedTextColor = Ink,
                                        cursorColor = Orange,
                                        focusedBorderColor = Orange,
                                        unfocusedBorderColor = Orange.copy(alpha = 0.65f),
                                        focusedContainerColor = Color(0xFF2B1A12),
                                        unfocusedContainerColor = Color(0xFF2B1A12)
                                    )
                                )
                                Row(
                                    Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    listOf("All Song", "Be.i Song", "Global").forEach { category ->
                                        val active = searchCategory == category
                                        TextButton(
                                            onClick = { searchCategory = category },
                                            modifier = Modifier.weight(1f),
                                            shape = RoundedCornerShape(22.dp),
                                            colors = ButtonDefaults.textButtonColors(
                                                containerColor = if (active) Orange else Color(0xFF2B1A12),
                                                contentColor = if (active) Color.White else Ink
                                            )
                                        ) {
                                            Text(category, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                        }
                                    }
                                }
                                Text("Results", color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                                if (searchResults.isEmpty()) {
                                    Text(
                                        if (searchCategory == "Global") "Belum ada katalog Global Music yang terhubung." else "Lagu tidak ditemukan.",
                                        color = Muted,
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(vertical = 20.dp)
                                    )
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                                        searchResults.forEach { song ->
                                            Row(
                                                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp))
                                                    .background(Color(0xFF2B1A12))
                                                    .clickable { playSong(song, false) }
                                                    .padding(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                SongArtwork(song, Modifier.size(54.dp).clip(RoundedCornerShape(12.dp)))
                                                Spacer(Modifier.width(11.dp))
                                                Column(Modifier.weight(1f)) {
                                                    Text(song.title, color = Ink, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                    Text(song.artist, color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                                }
                                                val activeSearchSong = currentUri == song.uri && isPlaying
                                                IconButton(onClick = {
                                                    if (currentUri == song.uri && player.currentMediaItem != null) {
                                                        if (player.isPlaying) player.pause() else player.play()
                                                    } else playSong(song, false)
                                                }) {
                                                    Icon(
                                                        if (activeSearchSong) Icons.Default.PauseCircleFilled else Icons.Default.PlayCircleFilled,
                                                        if (activeSearchSong) "Jeda ${song.title}" else "Putar ${song.title}",
                                                        tint = Golden,
                                                        modifier = Modifier.size(29.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        } else if (selectedTab == 3) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text("YOUR LIBRARY", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("${songs.size} lagu tersimpan", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink)
                                }
                                TextButton(
                                    onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Upload, null, tint = Orange, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(5.dp))
                                    Text("Upload", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(
                                    onClick = { audioPicker.launch(arrayOf("audio/*")) },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
                                ) {
                                    Icon(Icons.Default.Upload, null, tint = Orange, modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Upload Music", color = Orange, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(CreamCard).padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                listOf("All Songs", "Downloaded").forEach { filter ->
                                    val selected = libraryFilter == filter
                                    TextButton(
                                        onClick = { libraryFilter = filter },
                                        modifier = Modifier.weight(1f),
                                        colors = ButtonDefaults.textButtonColors(
                                            containerColor = if (selected) Orange.copy(alpha = 0.20f) else Color.Transparent,
                                            contentColor = if (selected) Orange else Muted
                                        ),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Icon(if (filter == "Downloaded") Icons.Default.DownloadDone else Icons.Default.LibraryMusic, null, modifier = Modifier.size(17.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(if (filter == "Downloaded") "Downloaded (${downloadedFiles.size})" else "All Songs (${songs.size})", fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
                                    }
                                }
                            }
                            Spacer(Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (libraryFilter == "Downloaded") "Offline Library" else "My Library", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = Ink, modifier = Modifier.weight(1f))
                                Text("LOCAL", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            if (filteredSongs.isEmpty()) {
                                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.LibraryMusic, null, tint = Orange, modifier = Modifier.size(48.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text(
                                            when {
                                                libraryFilter == "Downloaded" -> "Belum ada lagu offline"
                                                songs.isEmpty() -> "Belum ada lagu"
                                                else -> "Lagu tidak ditemukan"
                                            }, fontWeight = FontWeight.Bold, color = Ink
                                        )
                                        Text(
                                            if (libraryFilter == "Downloaded") "Simpan lagu dengan ikon download agar bisa diputar tanpa internet."
                                            else "Upload MP3 atau audio dari HP kamu.",
                                            color = Muted, fontSize = 12.sp
                                        )
                                    }
                                }
                            } else {
                                LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 112.dp)) {
                                    items(filteredSongs, key = { it.uri }) { song ->
                                        ListItem(
                                            modifier = Modifier.clickable { playSong(song) },
                                            headlineContent = {
                                                Text(
                                                    song.title,
                                                    fontWeight = FontWeight.SemiBold,
                                                    softWrap = true
                                                )
                                            },
                                            supportingContent = {
                                                Text("${song.artist} • ${song.album}", maxLines = 1, overflow = TextOverflow.Ellipsis, color = Muted)
                                            },
                                            leadingContent = {
                                                SongArtwork(song = song, modifier = Modifier.size(48.dp).clip(RoundedCornerShape(13.dp)))
                                            },
                                            trailingContent = {
                                                var showSongMenu by remember(song.uri) { mutableStateOf(false) }
                                                Box {
                                                    if (downloadingUri == song.uri) {
                                                        CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Orange, strokeWidth = 2.dp)
                                                    } else {
                                                        IconButton(onClick = { showSongMenu = true }) {
                                                            Icon(Icons.Default.MoreVert, "Opsi ${song.title}", tint = Muted)
                                                        }
                                                    }
                                                    DropdownMenu(
                                                        expanded = showSongMenu,
                                                        onDismissRequest = { showSongMenu = false }
                                                    ) {
                                                        DropdownMenuItem(
                                                            text = { Text(if (downloadedFiles.containsKey(song.uri)) "Hapus unduhan" else "Download") },
                                                            leadingIcon = { Icon(if (downloadedFiles.containsKey(song.uri)) Icons.Default.DownloadDone else Icons.Default.Download, null) },
                                                            onClick = {
                                                                showSongMenu = false
                                                                if (downloadedFiles.containsKey(song.uri)) removeOfflineCopy(song)
                                                                else saveSongOffline(song)
                                                            }
                                                        )
                                                        DropdownMenuItem(
                                                            text = { Text("Edit informasi") },
                                                            leadingIcon = { Icon(Icons.Default.Edit, null) },
                                                            onClick = { showSongMenu = false; openEditor(song) }
                                                        )
                                                        DropdownMenuItem(
                                                            text = { Text("Hapus lagu") },
                                                            leadingIcon = { Icon(Icons.Default.DeleteOutline, null) },
                                                            onClick = { showSongMenu = false; deletingSong = song }
                                                        )
                                                    }
                                                }
                                            },
                                            colors = ListItemDefaults.colors(containerColor = Cream)
                                        )
                                        HorizontalDivider(color = DividerTone)
                                    }
                                }
                            }
                        } else {
                            if (showLyrics) {
                                FullscreenLyricsScreen(
                                    song = currentSong,
                                    onClose = { showLyrics = false }
                                )
                            } else NowPlayingScreen(
                                song = currentSong,
                                isPlaying = isPlaying,
                                positionMs = positionMs,
                                durationMs = durationMs,
                                shuffleEnabled = shuffleEnabled,
                                repeatMode = repeatMode,
                                onPlayPause = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.currentMediaItem != null) player.play()
                                    isPlaying = player.isPlaying
                                },
                                onPrevious = {
                                    if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                    else if (player.currentMediaItem != null) player.seekTo(0)
                                },
                                onNext = {
                                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                },
                                onSeek = { player.seekTo(it) },
                                onLyrics = { showLyrics = true },
                                onShuffle = {
                                    shuffleEnabled = !shuffleEnabled
                                    player.shuffleModeEnabled = shuffleEnabled
                                },
                                onRepeat = {
                                    repeatMode = when (repeatMode) {
                                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                                        else -> Player.REPEAT_MODE_OFF
                                    }
                                    player.repeatMode = repeatMode
                                }
                            )
                        }

                        // Hide the mini-player until the user has selected a track.
                        if (selectedTab != 0 && selectedTab != 5 && player.currentMediaItem != null && currentSong != null) {
                            MiniPlayer(
                                song = currentSong,
                                isPlaying = isPlaying,
                                positionMs = positionMs,
                                durationMs = durationMs,
                                onPlayPause = {
                                    if (player.isPlaying) player.pause()
                                    else if (player.currentMediaItem != null) player.play()
                                },
                                onPrevious = {
                                    if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem()
                                    else if (player.currentMediaItem != null) player.seekTo(0)
                                },
                                onNext = {
                                    if (player.hasNextMediaItem()) player.seekToNextMediaItem()
                                },
                                onOpen = { selectedTab = 5 }
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "v1.4.5 • BESOUND BEI SONG CLOUD",
                            color = Muted,
                            fontSize = 10.sp,
                            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp)
                        )
                    }
                }
            }

            if (showExitDialog) {
                AlertDialog(
                    onDismissRequest = { showExitDialog = false },
                    title = { Text("Keluar dari BESOUND?") },
                    text = { Text("Musik yang sedang diputar akan tetap berjalan jika kamu kembali ke aplikasi.") },
                    confirmButton = {
                        TextButton(onClick = { showExitDialog = false; this@MainActivity.finish() }) {
                            Text("Keluar", color = Orange)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showExitDialog = false }) { Text("Tetap di aplikasi") }
                    },
                    containerColor = CreamCard,
                    titleContentColor = Ink,
                    textContentColor = Muted
                )
            }

            if (deletingSong != null) {
                AlertDialog(
                    onDismissRequest = { deletingSong = null },
                    title = { Text("Hapus lagu dari Library?") },
                    text = {
                        Text("${deletingSong?.title.orEmpty()} akan dihapus dari daftar BESOUND. File audio asli di HP tidak akan dihapus.")
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val target = deletingSong
                            deletingSong = null
                            if (target != null) {
                                val playerIndex = (0 until player.mediaItemCount).firstOrNull { index ->
                                    player.getMediaItemAt(index).mediaId == target.uri
                                }
                                if (currentUri == target.uri) {
                                    player.stop()
                                    player.clearMediaItems()
                                    currentUri = null
                                    isPlaying = false
                                    positionMs = 0L
                                    durationMs = 0L
                                } else if (playerIndex != null) {
                                    player.removeMediaItem(playerIndex)
                                }
                                removeOfflineCopy(target)
                                scope.launch { dao.delete(target.uri) }
                            }
                        }) { Text("Hapus", color = Color(0xFFE05A45)) }
                    },
                    dismissButton = {
                        TextButton(onClick = { deletingSong = null }) { Text("Batal") }
                    }
                )
            }

            if (showEditor && editingSong != null) {
                AlertDialog(
                    onDismissRequest = { showEditor = false; showLyrics = false },
                    title = { Text(if (showLyrics) "Lyrics Studio" else "Edit lagu & lirik") },
                    text = {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!showLyrics) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    SongArtwork(
                                        song = editingSong?.copy(coverUri = editCoverUri),
                                        modifier = Modifier.size(76.dp).clip(RoundedCornerShape(14.dp))
                                    )
                                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text("Cover lagu", color = Ink, fontWeight = FontWeight.SemiBold)
                                        TextButton(onClick = { coverPicker.launch(arrayOf("image/*")) }) {
                                            Icon(Icons.Default.Image, null)
                                            Spacer(Modifier.width(6.dp))
                                            Text("Pilih dari galeri")
                                        }
                                        if (editCoverUri != null) {
                                            TextButton(onClick = { editCoverUri = null }) {
                                                Text("Hapus cover", color = Muted)
                                            }
                                        }
                                    }
                                }
                                OutlinedTextField(editTitle, { editTitle = it }, label = { Text("Judul lagu") }, singleLine = true)
                                OutlinedTextField(editArtist, { editArtist = it }, label = { Text("Artis") }, singleLine = true)
                                OutlinedTextField(editAlbum, { editAlbum = it }, label = { Text("Album") }, singleLine = true)
                            }
                            OutlinedTextField(
                                editLyrics,
                                { editLyrics = it },
                                label = { Text("Lirik lagu") },
                                minLines = 5,
                                maxLines = 9
                            )
                        }
                    },
                    confirmButton = {
                        TextButton(onClick = {
                            val old = editingSong
                            if (old != null) {
                                scope.launch {
                                    try {
                                        val updated = old.copy(
                                            title = editTitle.trim().ifBlank { "Untitled" },
                                            artist = editArtist.trim().ifBlank { "Unknown artist" },
                                            album = editAlbum.trim().ifBlank { "Unknown album" },
                                            lyrics = editLyrics,
                                            coverUri = editCoverUri
                                        )

                                        val coverChanged = editCoverUri != old.coverUri
                                        val resumeAfterSave =
                                            coverChanged &&
                                                player.currentMediaItem?.mediaId == old.uri &&
                                                player.isPlaying
                                        if (resumeAfterSave) player.pause()

                                        try {
                                            // When the cover changes, write it into the actual MP3
                                            // as an ID3v2 APIC picture frame. The picker requests
                                            // writable document access for this operation.
                                            if (coverChanged) {
                                                withContext(Dispatchers.IO) {
                                                    Mp3ArtworkWriter.embed(
                                                        context = this@MainActivity,
                                                        audioUri = Uri.parse(old.uri),
                                                        coverUri = editCoverUri?.let { Uri.parse(it) },
                                                        title = updated.title,
                                                        artist = updated.artist,
                                                        album = updated.album
                                                    )
                                                }
                                            }

                                            // Only update Room after the MP3 tag write succeeds.
                                            dao.upsert(updated)
                                            val saved = dao.getByUri(old.uri)
                                            check(saved == updated) { "Data lagu belum tersimpan dengan benar." }
                                            // Refresh Media3 and Android media surfaces immediately.
                                            refreshPlayingTrackMetadata(saved!!)
                                            if (resumeAfterSave) player.play()
                                        } catch (saveError: Exception) {
                                            if (resumeAfterSave) player.play()
                                            throw saveError
                                        }
                                        editingSong = dao.getByUri(old.uri) ?: old
                                        showEditor = false
                                        showLyrics = false
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            if (coverChanged) {
                                                "Cover berhasil ditanam ke metadata MP3."
                                            } else {
                                                "Perubahan lagu berhasil disimpan."
                                            },
                                            android.widget.Toast.LENGTH_SHORT
                                        ).show()
                                    } catch (error: Exception) {
                                        android.widget.Toast.makeText(
                                            this@MainActivity,
                                            "Gagal menyimpan: ${error.message ?: "coba lagi"}",
                                            android.widget.Toast.LENGTH_LONG
                                        ).show()
                                    }
                                }
                            }
                        }) { Text("Simpan") }
                    },
                    dismissButton = {
                        TextButton(onClick = { showEditor = false; showLyrics = false }) { Text("Tutup") }
                    }
                )
            }
        }
    }

    private fun displayNameFor(uri: Uri): String {
        var displayName = ""
        runCatching {
            contentResolver.query(
                uri,
                arrayOf(OpenableColumns.DISPLAY_NAME),
                null,
                null,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val column = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (column >= 0) displayName = cursor.getString(column).orEmpty()
                }
            }
        }
        if (displayName.isBlank()) {
            displayName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':').orEmpty()
        }
        val withoutExtension = displayName.substringBeforeLast('.', displayName).trim()
        return withoutExtension.ifBlank { "Untitled" }
    }

    private fun readMetadata(uri: Uri): Triple<String, String, String> {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(this, uri)
            Triple(
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST).orEmpty(),
                retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM).orEmpty()
            )
        } catch (_: Exception) {
            Triple("", "", "")
        } finally {
            runCatching { retriever.release() }
        }
    }

    /** Store selected artwork inside app-private storage and return a stable file URI. */
    private fun persistArtwork(source: Uri): Uri? = runCatching {
        val directory = File(filesDir, "track_covers").apply { mkdirs() }
        val mime = contentResolver.getType(source).orEmpty()
        val extension = when {
            mime.contains("png", ignoreCase = true) -> "png"
            mime.contains("webp", ignoreCase = true) -> "webp"
            else -> "jpg"
        }
        val destination = File(directory, "cover_${UUID.randomUUID()}.$extension")
        contentResolver.openInputStream(source)?.use { input ->
            destination.outputStream().use { output -> input.copyTo(output) }
        } ?: error("Tidak bisa membaca foto yang dipilih")
        check(destination.length() > 0L) { "File cover kosong" }
        Uri.fromFile(destination)
    }.getOrNull()

    /** Replace the active media item's metadata so Android refreshes all media surfaces. */
    private fun refreshPlayingTrackMetadata(song: SongEntity) {
        if (!::player.isInitialized) return
        val index = player.currentMediaItemIndex
        val current = player.currentMediaItem ?: return
        if (current.mediaId != song.uri) return
        trackArtworkUris = trackArtworkUris + (song.uri to song.coverUri)
        val metadata = androidx.media3.common.MediaMetadata.Builder()
            .setTitle(song.title)
            .setArtist(song.artist)
            .setAlbumTitle(song.album)
            .apply {
                song.coverUri?.takeIf { it.isNotBlank() }?.let { setArtworkUri(Uri.parse(it)) }
            }
            .build()
        val refreshed = MediaItem.Builder()
            .setMediaId(song.uri)
            .setUri(Uri.parse(song.uri))
            .setMediaMetadata(metadata)
            .build()
        player.replaceMediaItem(index, refreshed)
        // Refresh both media surfaces explicitly: legacy MediaSession metadata for the
        // lock screen and the Media3 notification's cached large icon.
        cachedArtworkUri = null
        cachedArtworkBitmap = null
        cachedEmbeddedArtworkKey = null
        cachedEmbeddedArtworkBitmap = null
        updateCompatMediaSession(forceMetadata = true)
        if (::notificationManager.isInitialized) notificationManager.invalidate()
    }

    /**
     * Resolve the selected cover from Room first. The app editor stores gallery images
     * as private file:// URIs in SongEntity.coverUri; ExoPlayer metadata is not the
     * authoritative store and can be empty or stale after metadata replacement.
     */
    private fun resolveCurrentArtworkUri(mediaPlayer: Player): Uri? {
        val item = mediaPlayer.currentMediaItem
        val mediaId = item?.mediaId
        if (!mediaId.isNullOrBlank() && trackArtworkUris.containsKey(mediaId)) {
            return trackArtworkUris[mediaId]
                ?.takeIf { it.isNotBlank() }
                ?.let(Uri::parse)
        }
        return mediaPlayer.mediaMetadata.artworkUri ?: item?.mediaMetadata?.artworkUri
    }

    /**
     * Decode user-selected cover art at notification-friendly dimensions.
     * Downsampling avoids putting full-resolution phone photos into Android's
     * notification and lock-screen metadata.
     */
    private fun loadArtworkBitmapCached(uri: Uri): android.graphics.Bitmap? {
        val key = uri.toString()
        if (cachedArtworkUri == key) return cachedArtworkBitmap
        val bitmap = loadArtworkBitmap(uri)
        cachedArtworkUri = key
        cachedArtworkBitmap = bitmap
        return bitmap
    }

    /**
     * Read the embedded ID3 album picture directly from the active MP3.
     * This is preferred for notifications and lock-screen metadata, so the
     * Android media surfaces use the artwork that is actually inside the file.
     */
    private fun loadEmbeddedArtworkBitmap(mediaPlayer: Player): android.graphics.Bitmap? {
        val item = mediaPlayer.currentMediaItem ?: return null
        val audioUri = item.localConfiguration?.uri ?: Uri.parse(item.mediaId)
        val key = audioUri.toString()
        if (cachedEmbeddedArtworkKey == key) return cachedEmbeddedArtworkBitmap

        val bitmap = runCatching {
            val retriever = MediaMetadataRetriever()
            try {
                if (audioUri.scheme == "file") {
                    retriever.setDataSource(requireNotNull(audioUri.path))
                } else {
                    retriever.setDataSource(this@MainActivity, audioUri)
                }
                val picture = retriever.embeddedPicture ?: return@runCatching null
                val bounds = android.graphics.BitmapFactory.Options().apply {
                    inJustDecodeBounds = true
                }
                android.graphics.BitmapFactory.decodeByteArray(picture, 0, picture.size, bounds)
                if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return@runCatching null

                var sampleSize = 1
                val maxDimension = 512
                while (bounds.outWidth / sampleSize > maxDimension ||
                    bounds.outHeight / sampleSize > maxDimension
                ) sampleSize *= 2

                val options = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = sampleSize
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                android.graphics.BitmapFactory.decodeByteArray(picture, 0, picture.size, options)
            } finally {
                retriever.release()
            }
        }.getOrNull()

        cachedEmbeddedArtworkKey = key
        cachedEmbeddedArtworkBitmap = bitmap
        return bitmap
    }

    /** Shared default artwork for tracks without their own cover. */
    private var defaultArtworkBitmap: android.graphics.Bitmap? = null

    private fun loadDefaultArtworkBitmap(): android.graphics.Bitmap? {
        if (defaultArtworkBitmap == null) {
            defaultArtworkBitmap = android.graphics.BitmapFactory.decodeResource(
                resources, R.drawable.besound_default_artwork
            )
        }
        return defaultArtworkBitmap
    }

    private fun loadArtworkBitmap(uri: Uri): android.graphics.Bitmap? {
        return runCatching {
            fun openStream() = when (uri.scheme) {
                "file" -> File(requireNotNull(uri.path)).inputStream()
                "http", "https" -> java.net.URL(uri.toString()).openConnection().apply {
                    connectTimeout = 12000
                    readTimeout = 15000
                }.getInputStream()
                else -> contentResolver.openInputStream(uri)
            }

            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            openStream()?.use { stream -> android.graphics.BitmapFactory.decodeStream(stream, null, bounds) }
                ?: return null
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            val maxDimension = 512
            var sampleSize = 1
            while (bounds.outWidth / sampleSize > maxDimension ||
                bounds.outHeight / sampleSize > maxDimension
            ) sampleSize *= 2

            val options = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
            }
            openStream()?.use { stream -> android.graphics.BitmapFactory.decodeStream(stream, null, options) }
        }.getOrNull()
    }

    /** Publish artwork/title metadata only when the active track metadata actually changes. */
    private fun updateCompatMediaSession(forceMetadata: Boolean = false) {
        if (!::mediaSession.isInitialized || !::player.isInitialized) return
        val item = player.currentMediaItem
        val artworkUri = resolveCurrentArtworkUri(player)
        val duration = player.duration.takeIf { it > 0L } ?: 0L
        val title = item?.mediaMetadata?.title?.toString() ?: "BESOUND"
        val artist = item?.mediaMetadata?.artist?.toString().orEmpty()
        val album = item?.mediaMetadata?.albumTitle?.toString().orEmpty()
        val mediaId = item?.mediaId.orEmpty()
        val metadataKey = listOf(
            mediaId, title, artist, album, duration.toString(), artworkUri?.toString().orEmpty()
        ).joinToString("\\u001f")

        if (forceMetadata || metadataKey != lastCompatMetadataKey) {
            val metadata = MediaMetadataCompat.Builder()
                .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
                .putString(MediaMetadataCompat.METADATA_KEY_ARTIST, artist)
                .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, album)
                .putLong(MediaMetadataCompat.METADATA_KEY_DURATION, duration)
                .apply {
                    val artwork = loadEmbeddedArtworkBitmap(player)
                        ?: artworkUri?.let { loadArtworkBitmapCached(it) }
                        ?: loadDefaultArtworkBitmap()
                    if (artwork != null) {
                        putBitmap(MediaMetadataCompat.METADATA_KEY_ART, artwork)
                        putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, artwork)
                        putBitmap(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON, artwork)
                        artworkUri?.toString()?.let { uri ->
                            putString(MediaMetadataCompat.METADATA_KEY_ART_URI, uri)
                            putString(MediaMetadataCompat.METADATA_KEY_ALBUM_ART_URI, uri)
                            putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_ICON_URI, uri)
                        }
                    }
                }
                .build()
            mediaSession.setMetadata(metadata)
            lastCompatMetadataKey = metadataKey
        }
    }

    /** Playback position/state changes frequently; keep these separate from expensive artwork metadata. */
    private fun updateCompatPlaybackState() {
        if (!::mediaSession.isInitialized || !::player.isInitialized) return
        val actions = PlaybackStateCompat.ACTION_PLAY or
            PlaybackStateCompat.ACTION_PAUSE or
            PlaybackStateCompat.ACTION_PLAY_PAUSE or
            PlaybackStateCompat.ACTION_SKIP_TO_NEXT or
            PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or
            PlaybackStateCompat.ACTION_SEEK_TO or
            PlaybackStateCompat.ACTION_STOP
        val state = when {
            player.isPlaying -> PlaybackStateCompat.STATE_PLAYING
            player.playbackState == Player.STATE_BUFFERING -> PlaybackStateCompat.STATE_BUFFERING
            player.playbackState == Player.STATE_ENDED -> PlaybackStateCompat.STATE_STOPPED
            player.currentMediaItem != null -> PlaybackStateCompat.STATE_PAUSED
            else -> PlaybackStateCompat.STATE_NONE
        }
        mediaSession.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(actions)
                .setState(state, player.currentPosition.coerceAtLeast(0L), if (player.isPlaying) 1f else 0f)
                .build()
        )
    }

    private fun createPlaybackNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                notificationChannelId,
                "BESOUND playback",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Kontrol pemutaran musik BESOUND"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        if (::notificationManager.isInitialized) notificationManager.setPlayer(null)
        if (::mediaSession.isInitialized) {
            mediaSession.isActive = false
            mediaSession.release()
        }
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

/**
 * Detect vertical swipes in the Initial pointer pass only on dedicated hint zones.
 * The cover, transport controls, and lyrics scrolling area do not own navigation gestures.
 * Horizontal gestures are deliberately ignored.
 */
private fun Modifier.verticalSwipeGesture(
    onSwipeDown: () -> Unit,
    onSwipeUp: () -> Unit
): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val down = awaitFirstDown(
            requireUnconsumed = false,
            pass = PointerEventPass.Initial
        )
        var previousY = down.position.y
        var totalY = 0f
        var completed = false
        val threshold = viewConfiguration.touchSlop * 1.5f

        while (!completed) {
            val event = awaitPointerEvent(PointerEventPass.Initial)
            val change = event.changes.firstOrNull { it.id == down.id }
            if (change == null || !change.pressed) {
                completed = true
            } else {
                val deltaY = change.position.y - previousY
                val deltaX = change.position.x - down.position.x
                previousY = change.position.y
                totalY = change.position.y - down.position.y
                if (abs(totalY) >= threshold && abs(totalY) > abs(deltaX) * 1.2f) {
                    change.consume()
                    // Finger moving down is a swipe-down; finger moving up is a swipe-up.
                    if (totalY > 0f) onSwipeDown() else onSwipeUp()
                    completed = true
                }
            }
        }
    }
}

@Composable
private fun SongArtwork(
    song: SongEntity?,
    modifier: Modifier = Modifier,
    largeFallback: Boolean = false
) {
    val context = LocalContext.current
    val bitmap by produceState<android.graphics.Bitmap?>(initialValue = null, song?.coverUri) {
        value = null
        val cover = song?.coverUri
        if (!cover.isNullOrBlank()) {
            value = withContext(Dispatchers.IO) {
                runCatching {
                    val coverUri = Uri.parse(cover)
                    val stream = when (coverUri.scheme) {
                        "http", "https" -> java.net.URL(cover).openConnection().apply {
                            connectTimeout = 12000
                            readTimeout = 15000
                        }.getInputStream()
                        else -> context.contentResolver.openInputStream(coverUri)
                    }
                    stream?.use { input ->
                        val bytes = input.readBytes()
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                        val sample = maxOf(1, maxOf(bounds.outWidth, bounds.outHeight) / 1200)
                        val options = BitmapFactory.Options().apply { inSampleSize = sample }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                    }
                }.getOrNull()
            }
        }
    }
    Box(
        modifier = modifier.background(
            Brush.linearGradient(listOf(Orange, Golden, Color(0xFFFFE2B7)))
        ),
        contentAlignment = Alignment.Center
    ) {
        if (bitmap != null) {
            Image(
                bitmap = bitmap!!.asImageBitmap(),
                contentDescription = "Cover ${song?.title.orEmpty()}",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        } else if (largeFallback) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Headphones, null, tint = Color.White, modifier = Modifier.size(84.dp))
                Text("BESOUND", color = Color.White, fontSize = 22.sp,
                    fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            }
        } else {
            Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun AudioVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = Orange,
    fillBars: Boolean = false
) {
    val transition = rememberInfiniteTransition(label = "audioVisualizer")
    val heights = if (fillBars) {
        listOf(5f, 8f, 12f, 17f, 23f, 28f, 21f, 15f, 10f, 7f, 12f, 18f, 25f, 20f, 14f, 9f,
            6f, 11f, 17f, 24f, 29f, 22f, 16f, 11f, 7f, 13f, 19f, 25f, 18f, 12f, 8f, 5f)
    } else {
        listOf(10f, 19f, 27f, 15f, 24f, 12f, 21f)
    }
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(if (fillBars) 2.dp else 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        heights.forEachIndexed { index, target ->
            val animatedHeight by transition.animateFloat(
                initialValue = 5f,
                targetValue = target,
                animationSpec = infiniteRepeatable(
                    animation = tween(durationMillis = 300 + (index % 7) * 48, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "visualizerBar$index"
            )
            val visibleHeight = if (isPlaying) animatedHeight else 4f
            Box(
                Modifier
                    .then(if (fillBars) Modifier.weight(1f) else Modifier.width(3.dp))
                    .height(visibleHeight.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                if (fillBars) Golden else barColor,
                                barColor,
                                Color(0xFFB84A12)
                            )
                        )
                    )
            )
        }
    }
}

private fun formatTime(milliseconds: Long): String {
    val totalSeconds = (milliseconds.coerceAtLeast(0L) / 1000L).toInt()
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

@Composable
private fun ColumnScope.NowPlayingScreen(
    song: SongEntity?, isPlaying: Boolean, positionMs: Long, durationMs: Long,
    shuffleEnabled: Boolean, repeatMode: Int, onPlayPause: () -> Unit,
    onPrevious: () -> Unit, onNext: () -> Unit, onSeek: (Long) -> Unit,
    onShuffle: () -> Unit, onRepeat: () -> Unit, onLyrics: () -> Unit
) {
    BoxWithConstraints(
        Modifier.fillMaxWidth().weight(1f)
    ) {
        val coverSize = minOf(maxWidth * 0.96f, maxHeight * 0.50f, 380.dp)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly) {
            Text("NOW PLAYING", color = Orange, fontSize = 11.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            SongArtwork(
                song = song,
                modifier = Modifier.size(coverSize).clip(RoundedCornerShape(26.dp)),
                largeFallback = true
            )
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(song?.title ?: "Belum ada lagu dipilih", color = Ink, fontSize = 21.sp,
                    fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(song?.artist ?: "Pilih lagu dari Library", color = Muted, fontSize = 14.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Slider(value = positionMs.toFloat().coerceIn(0f, durationMs.coerceAtLeast(1L).toFloat()),
                onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..durationMs.coerceAtLeast(1L).toFloat(), enabled = durationMs > 0L,
                colors = SliderDefaults.colors(thumbColor = Orange, activeTrackColor = Orange,
                    inactiveTrackColor = DividerTone))
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime(positionMs), color = Muted, fontSize = 11.sp)
                Text(formatTime(durationMs), color = Muted, fontSize = 11.sp)
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly) {
                IconButton(onClick = onShuffle, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Default.Shuffle, "Shuffle", tint = if (shuffleEnabled) Orange else Muted,
                        modifier = Modifier.size(26.dp))
                }
                IconButton(onClick = onPrevious, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Previous", tint = Ink, modifier = Modifier.size(35.dp))
                }
                FilledIconButton(onClick = onPlayPause, enabled = song != null,
                    modifier = Modifier.size(72.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(containerColor = Orange,
                        contentColor = Color.White, disabledContainerColor = DividerTone,
                        disabledContentColor = Muted)) {
                    Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play atau pause", modifier = Modifier.size(42.dp))
                }
                IconButton(onClick = onNext, modifier = Modifier.size(52.dp)) {
                    Icon(Icons.Default.SkipNext, "Next", tint = Ink, modifier = Modifier.size(35.dp))
                }
                IconButton(onClick = onRepeat, modifier = Modifier.size(48.dp)) {
                    Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Default.RepeatOne else Icons.Default.Repeat,
                        "Repeat", tint = if (repeatMode == Player.REPEAT_MODE_OFF) Muted else Orange,
                        modifier = Modifier.size(26.dp))
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 6.dp)
                    .verticalSwipeGesture(onSwipeDown = {}, onSwipeUp = onLyrics),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Default.KeyboardArrowUp,
                    contentDescription = "Geser ke atas untuk membuka lirik",
                    tint = Orange,
                    modifier = Modifier.size(34.dp)
                )
                Text(
                    "SWIPE UP FOR LYRICS",
                    color = Orange,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.8.sp
                )
                Text(
                    "Geser ke atas untuk membuka lirik",
                    color = Muted,
                    fontSize = 10.sp
                )
            }
        }
    }
}

@Composable
private fun FullscreenLyricsScreen(song: SongEntity?, onClose: () -> Unit) {
    // Keep the lyrics area dedicated to vertical scrolling. Only the bottom hint
    // region handles the upward navigation gesture, so reading lyrics cannot
    // accidentally close the fullscreen lyrics screen.
    Column(Modifier.fillMaxWidth().fillMaxHeight()
        .padding(horizontal = 24.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.SpaceBetween) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("LYRICS", color = Orange, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
        }
        val lines = song?.lyrics.orEmpty().lines().filter { it.isNotBlank() }
        if (lines.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("Belum ada lirik untuk lagu ini", color = Muted, fontSize = 18.sp)
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.Center) {
                lines.forEachIndexed { index, line ->
                    Text(line, color = if (index == 0) Ink else Muted,
                        fontSize = if (index == 0) 25.sp else 20.sp,
                        fontWeight = if (index == 0) FontWeight.Bold else FontWeight.Medium,
                        modifier = Modifier.padding(vertical = 12.dp))
                }
            }
        }
        Column(Modifier.fillMaxWidth().padding(bottom = 12.dp)
            .verticalSwipeGesture(onSwipeDown = {}, onSwipeUp = onClose),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(song?.title ?: "BESOUND", color = Ink, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song?.artist ?: "", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                "SWIPE UP TO PLAYER",
                color = Orange,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.8.sp
            )
        }
    }
}

@Composable
private fun MusicVisualizer(
    isPlaying: Boolean,
    modifier: Modifier = Modifier,
    barColor: Color = Orange,
    barCount: Int = 7,
    maxBarHeight: androidx.compose.ui.unit.Dp = 30.dp
) {
    val transition = rememberInfiniteTransition(label = "besound_equalizer")
    Row(
        modifier = modifier.height(maxBarHeight),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(barCount) { index ->
            val animatedHeight by transition.animateFloat(
                initialValue = 0.18f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(
                        durationMillis = 360 + (index % 4) * 115,
                        delayMillis = index * 65,
                        easing = FastOutSlowInEasing
                    ),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "equalizer_bar_$index"
            )
            val barFraction = if (isPlaying) animatedHeight else 0.18f
            Box(
                Modifier
                    .width(4.dp)
                    .height(maxBarHeight * barFraction.coerceIn(0.12f, 1f))
                    .clip(CircleShape)
                    .background(barColor)
            )
        }
    }
}

@Composable
private fun MiniPlayer(
    song: SongEntity?,
    isPlaying: Boolean,
    positionMs: Long,
    durationMs: Long,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onOpen: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CreamCard),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable(enabled = song != null) { onOpen() }
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SongArtwork(song = song, modifier = Modifier.size(46.dp).clip(RoundedCornerShape(13.dp)))
            Spacer(Modifier.width(9.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song?.title ?: "Belum ada lagu diputar",
                    color = Ink,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    song?.artist ?: "Pilih lagu dari Library",
                    color = Muted,
                    fontSize = 10.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(5.dp))
                val progress = if (durationMs > 0L) {
                    (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                } else 0f
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF5A4538))
                ) {
                    Box(
                        Modifier
                            .fillMaxWidth(progress)
                            .height(3.dp)
                            .clip(CircleShape)
                            .background(Orange)
                    )
                }
            }
            if (song != null) {
                IconButton(onClick = onPrevious, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Default.SkipPrevious, "Lagu sebelumnya", tint = Ink, modifier = Modifier.size(25.dp))
                }
                IconButton(onClick = onPlayPause, modifier = Modifier.size(42.dp)) {
                    Icon(
                        if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play atau pause", tint = Orange, modifier = Modifier.size(30.dp)
                    )
                }
                IconButton(onClick = onNext, modifier = Modifier.size(38.dp)) {
                    Icon(Icons.Default.SkipNext, "Lagu berikutnya", tint = Ink, modifier = Modifier.size(25.dp))
                }
            } else {
                Text("Pilih lagu", color = Orange, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}


