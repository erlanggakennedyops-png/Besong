# BESOUND v1.5.0 - Three Dot Menu

Android project for `com.bei.besound`.

## Release identity
- `versionName`: `1.5.0`
- `versionCode`: `51`
- `minSdk`: 26
- `targetSdk`: 35

## Build with GitHub Actions
1. Upload `BESOUND_v1.5.0_THREE_DOT_MENU_SOURCE.zip` to the repository root.
2. Put the workflow file at `.github/workflows/android.yml`.
3. Configure the Android signing secrets used by the workflow.
4. Run **Build BESOUND Android APK** from the Actions tab, or push a change to either the source ZIP or workflow on `main`.
5. Download the `BESOUND-v1.5.0-Release` artifact after a successful run.

The workflow checks the ZIP structure, application ID, version code/name, and APK signature before uploading the release artifact.

## Signing secrets
The workflow accepts `BESOUND_KEYSTORE_BASE64` (or the supported legacy aliases), `BESOUND_KEY_ALIAS`, `BESOUND_STORE_PASSWORD`, and `BESOUND_KEY_PASSWORD`. Keep these values in GitHub Actions Secrets; never put keystores or passwords in the repository.

## Validation note
The source ZIP structure and workflow configuration were checked when this package was prepared. A full Android build still needs to run in GitHub Actions, where the Android SDK and signing secrets are available.
