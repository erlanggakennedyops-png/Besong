# BESOUND v1.0.0 — Golden Dusk

New app identity: `com.bei.besound` (keeps the old `com.bei.music` app installed separately).

Based on the supplied v0.8.3 Unified Swipe Up source.

- Keeps the existing Golden Dusk UI and player implementation.
- Keeps manual song upload and existing player/library features from the supplied source.
- Uses the unified upward-swipe lyrics navigation already present in v0.8.3.
- Fresh application identity and fresh app storage. The old app's private database is not migrated.
- Version code 1, version name 1.0.0.

Signing is configured in the GitHub Actions workflow using repository secrets. Never commit a keystore or its passwords to this repository.
