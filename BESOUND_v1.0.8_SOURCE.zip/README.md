# BESOUND v1.0.8

Android source project for package `com.bei.besound`.

## Version
- versionCode: 9
- versionName: 1.0.8
- Database: Room schema version 2 (unchanged; no destructive migration)

## Changes in 1.0.8
- Pass each selected track cover URI into Media3 media metadata.
- Display selected cover art in PlayerNotificationManager notifications.
- Publish the selected cover bitmap through MediaSessionCompat metadata for Android lock-screen artwork.
- Downsample cover images to a maximum 512 px dimension for notification/lock-screen memory safety.
- Preserve package ID, Room database, signing identity, and existing library data.

## Build
Use the repository Android GitHub Actions workflow and existing signing secrets. Do not change `applicationId` or release keystore for updates.
